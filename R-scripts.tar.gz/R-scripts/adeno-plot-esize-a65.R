#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="esize-flat-all-w-3d-K2-dist-atrend.Rdata")
f.3d.w <- sf

load(file="esize-flat-all-m-3d-K2-dist-atrend.Rdata")
f.3d.m <- sf

load(file="esize-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.2d.w <- sf

load(file="esize-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.2d.m <- sf

load(file="esize-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
p.2d.w <- sf

load(file="esize-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
p.2d.m <- sf

# count uncertainties
load(file="esize-unc-ylo-flat-all-w-3d-K2-dist-atrend.Rdata")
f.unc.w <- sf.unc

load(file="esize-unc-ylo-flat-all-m-3d-K2-dist-atrend.Rdata")
f.unc.m <- sf.unc

load(file="esize-unc-ylo-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.unc.w <- sf.unc

load(file="esize-unc-ylo-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.unc.m <- sf.unc

load(file="esize-unc-ylo-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
p.unc.w <- sf.unc

load(file="esize-unc-ylo-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
p.unc.m <- sf.unc

setwd(statdir)
setwd("sizeexp")

headline <- c("Shape","Sex","refage","age","sizecm")
p.a65.m <- read.csv(file = "esize-peduncular-pref-age-m.csv")
p.a65.m <- data.frame("peduncular","men",65,p.a65.m$age,p.a65.m$sizecm)
names(p.a65.m) <- headline
p.a65.w <- read.csv(file = "esize-peduncular-pref-age-f.csv")
p.a65.w <- data.frame("peduncular","women",65,p.a65.w$age,p.a65.w$sizecm)
names(p.a65.w) <- headline

f.a65.m <- read.csv(file = "esize-flat-pref-age-m.csv")
f.a65.m <- data.frame("flat","men",65,f.a65.m$age,f.a65.m$sizecm)
names(f.a65.m) <- headline
f.a65.w <- read.csv(file = "esize-flat-pref-age-f.csv")
f.a65.w <- data.frame("flat","women",65,f.a65.w$age,f.a65.w$sizecm)
names(f.a65.w) <- headline

f2d.a65.m <- read.csv(file = "esize-flat-2d-age-m.csv")
f2d.a65.m <- data.frame("flat,2d","men",65,f2d.a65.m$age,f2d.a65.m$sizecm)
names(f2d.a65.m) <- headline
f2d.a65.w <- read.csv(file = "esize-flat-2d-age-w.csv")
f2d.a65.w <- data.frame("flat,2d","women",65,f2d.a65.w$age,f2d.a65.w$sizecm)
names(f2d.a65.w) <- headline

s.a65.m <- read.csv(file = "esize-sessile-pref-age-m.csv")
s.a65.m <- data.frame("sessile","men",65,s.a65.m$age,s.a65.m$sizecm)
names(s.a65.m) <- headline
s.a65.w <- read.csv(file = "esize-sessile-pref-age-f.csv")
s.a65.w <- data.frame("sessile","women",65,s.a65.w$age,s.a65.w$sizecm)
names(s.a65.w) <- headline


# build and adjust pf
pf <- rbind(f.3d.w,f.3d.m,s.2d.w,s.2d.m,p.2d.w,p.2d.m)
pf <- subset(pf,Source == "M")
pf <- droplevels(pf)
pf$Source <- fct_rev(pf$Source)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("peduncular","flat","flat,2d","sessile"))
summary(pf)
str(pf)

# build and adjust pf.unc
pf.unc <- rbind(f.unc.w,f.unc.m,s.unc.w,s.unc.m,p.unc.w,p.unc.m)
pf.unc$Sex <- fct_rev(pf.unc$Sex)
pf.unc$Shape <- fct_relevel(pf.unc$Shape,c("peduncular","flat","sessile"))

setwd(plotdir)

pd <- position_dodge(width = 0.2)
fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_point(data = pf, aes(x=AgeGroup, y=sizecm, color = Shape, shape = Source), size = 4) +
  geom_point(data = pf.unc, aes(x=AgeGroup, y=sizecm, color = Shape, shape = Source), size = 4) +
  #geom_errorbar(data = pf.unc, aes(x = AgeGroup, ymax =sizecm.hi, ymin = sizecm.lo, color = Shape), width=.1) +
  geom_linerange(data = pf.unc, aes(x = AgeGroup, y=sizecm, ymax =sizecm.hi, ymin = sizecm.lo), size = .75) +
  #geom_pointrange(data = pf.unc, aes(x = AgeGroup, y=sizecm, ymax =sizecm.hi, ymin = sizecm.lo), size = 0.1) +
  xlab("Age group (yr)") +
  #facet_wrap(Shape ~ Sex, scales = "free_y", ncol = 3) + 
  facet_grid(Sex ~ .) + 
  #scale_x_discrete(limits = levels(pf$Size), breaks = levels(pf$Size)) +
  scale_y_continuous(name="Mean adenoma size (cm)") +
  scale_color_manual(values=cbPalette[c(7,2,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(16, 21)) +
  guides(shape="none",color="none") + 
  theme(text = element_text(size=15),legend.position = c(.65,0.49)) 
#  + theme_bw()  # use a white background
print(fp.1)

#-------------------------------------
# plot with age extrapolation marked
#--------------------------------------
pf.2 <- rbind(f.a65.w,f.a65.m,f2d.a65.w,f2d.a65.m,s.a65.w,s.a65.m,p.a65.w,p.a65.m)
pf.early <- subset(pf.2, age < 55)
pf.early <- data.frame(pf.early,"early")
names(pf.early)[6] <- "Period"
pf.late <- subset(pf.2, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[6] <- "Period"

pf.2 <- rbind(pf.early,pf.late)
pf.2$Sex <- fct_rev(pf.2$Sex)
#pf.2$Shape <- fct_relevel(pf.2$Shape,c("peduncular","flat","sessile"))
pf.2$Shape <- fct_relevel(pf.2$Shape,c("peduncular","flat","flat,2d","sessile"))
summary(pf.2)

# build and adjust pf.unc
#pf.unc <- rbind(f.unc.w,f.unc.m,s.unc.w,s.unc.m,p.unc.w,p.unc.m)
#pf.unc$Sex <- fct_rev(pf.unc$Sex)
#pf.unc$Shape <- fct_relevel(pf.unc$Shape,c("peduncular","flat","sessile"))

pf.2 <- subset(pf.2, Shape != "flat,2d")
fp.2 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_point(data = pf.unc, aes(x=age, y=sizecm, color = Shape, shape = Source), size = 4) +
  #geom_errorbar(data = pf.unc, aes(x = age, ymax =sizecm.hi, ymin = sizecm.lo), width=.5) +
  geom_linerange(data = pf.unc, aes(x = age, y=sizecm, ymax =sizecm.hi, ymin = sizecm.lo), size = .75) +
  geom_line(data = pf.2, aes(x=age, y=sizecm, color = Shape, linetype = Period), size = 1) +
  #facet_wrap(Shape ~ Sex, scales = "free_y", ncol = 3) + 
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name="Mean adenoma size (cm)", limits = c(0.4,1.3), breaks = seq(0.4,1.2,0.2)) +
  scale_color_manual(values=cbPalette[c(7,2,4)]) +
  #scale_color_manual(values=cbPalette[c(2,3,7,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape="none", linetype = "none") + 
  theme(text = element_text(size=15),legend.position = c(.15,0.42)) 
#  + theme_bw()  # use a white background
print(fp.2)

