#----------------------------------------------
# adeno OE analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
library(ggplot2)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
setwd(datdir)

df0 <- read.csv(file = "intervariab.csv",sep = ",", header = T)
str(df0)
meanlog <- df0$meanlog[1]
#meanlog <- 0
sdlog <- df0$sdlog[1]
#sdlog <- .5

x <- seq(0.0001,0.1,0.0001)
plot(x, dlnorm(x,meanlog,sdlog))

mua <- exp(meanlog + 0.5*sdlog^2)
mug <- exp(meanlog)
mum <- exp(meanlog-sdlog^2)
sig <- exp(sdlog)
sia <- sqrt(exp(2*meanlog+sdlog^2)*(exp(sdlog^2)-1))


cat(sprintf("mum, mug, mua, meanlog: %g, %g, %g, %g\n", mum, mug, mua, meanlog))
(mum*mua*mua)^(1/3)
log(sqrt(mua^4/(mua^2+sia^2)))
mua/mug
exp(0.5*sdlog^2)

cat(sprintf("sig, sia, sdlog: %g, %g, %g\n", sig, sia, sdlog))
