#----------------------------------------------
# adeno OE analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-------------------------------------------
# directory structure
#-------------------------------------------

shp <- character()
#shp <- "all"
#shp <- "flat"
shp <- "sessile"
#shp <- "peduncular"

noad <- character()
noad <- "wN0"
#noad <- "noN0"

loca <- character()
loca <- "all"

sexc <- character()
#sexc <- "m"
sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K0"
#mmname <- "K1app"
mmname <- "K2"

# likelihood
likc <- character()
#likc <- "sing"
#likc <- "unif"
likc <- "dist"
#likc <- "bina"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,"-atrend",sep="") # age trend version

#-------------------------------------------------------------
# prepare observed data
#-------------------------------------------------------------
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20210915.Rdata")
    df0 <- sadenoPG} 
  else if (shp == "sessile") {
    load(file = "sessPG-20210915.Rdata")
    df0 <- sess}
  else if (shp == "flat") {
    load(file = "flatPG-20210915.Rdata")
    df0 <- flat}
  else if (shp == "peduncular" & mdv == "grid") {
    load(file = "peduPG-20210915.Rdata")
    df0 <- pedu
    patdata <- "peduPG-20210915.Rdata"}
  else if (shp == "peduncular" & mdv == "pref") {
    load(file = "peduPG-20211103.Rdata")
    levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
    pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
    df0 <- pedu
    patdata <- "peduPG-20211103.Rdata"}
}

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  # location
  if (loca == "distboth") {
    df0 <- subset(df0, loca == "distboth" | loca == "none")} 
  else if (loca == "proximal") {
    df0 <- subset(df0, loca == "proximal" | loca == "none")}
  
  if (dims == "2d") {
    df0$ys <- df0$ys2d
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ys <- df0$ys3d
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}
df0$yhi[df0$sizecat == ">2"] <- -1

# set detection limit boundaries for preferred models
{
  if (mdv == "pref"){
    if (shp == "sessile") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "peduncular") {
      df0$ylo[df0$ylo == 50] <- 40
      df0$ymin[df0$ymin == 50] <- 40}  
  }
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
df0 <- droplevels(df0)

ad <- subset(df0, shape != "none")

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 100
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
dim(sigma)[1]
sigma[1,2] <- sigma[2,1]
if(dim(sigma)[1] == 3)
{
 sigma[1,3] <- sigma[3,1]
 sigma[2,3] <- sigma[3,2]
}
if(dim(sigma)[1] == 4)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
}

cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov

if (all(1 == sign(eigen(sigma)$values)) == TRUE)
#if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
apply(Z,2,mean)
#apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

df.par[1:10,]

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-distrib.R")

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.hyp
    Thelohi <- theta_lohi_K2.hyp
  }
  else
  {
    print("Not implemented\n")
  }
  
  if (likc == "bina"){
    Padeno <- Padeno_bin
  }
  else{
    Padeno <- Padeno_N
    PadenoTop <- Padeno_Nmaxprob
  }
}

#--------------------------------
# model predictions
#--------------------------------
upar <- dpar$parval
#--------------------------------
# adenoma counts with estimated ad.frees
#--------------------------------
df <- df0

cage.sum <- aggregate(df$age*df$npat, list(df$countcat,df$agecat), sum)
cage.len <- aggregate(df$npat, list(df$countcat,df$agecat), sum)
cage.mean <- cage.sum$x/cage.len$x

cnpat.sum <- aggregate(df$npat, list(df$countcat,df$agecat), sum)
cnpno.sum <- aggregate(df$npat*df$pno, list(df$countcat,df$agecat), sum)
cnpno.sum$x/cnpat.sum$x

pct <- data.frame(cage.sum$Group.1,cage.sum$Group.2,cnpat.sum$x,cnpno.sum$x,cage.mean)
names(pct) <- c("Count","AgeGroup","Npat","Npno","age")
pct
dim(pct) # 28 5
pdim <- dim(pct)[1]

# check age group normalization
#aggregate(pct$PNcat,list(pct$AgeGroup),sum)

# measured frequencies in age groups
cnpat.agrp <- aggregate(pct$Npat, list(pct$AgeGroup), sum)
cnpno.agrp <- aggregate(pct$Npno, list(pct$AgeGroup), sum)
help1 <- split(pct, pct$AgeGroup)
nlevels <- length(levels(pct$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- cnpat.agrp$x[i] 
  help1[[i]]$Npno_agrp <- cnpno.agrp$x[i]
}
pcf <- help1[[1]]
for (i in 2:nlevels){
  pcf <- rbind(pcf,help1[[i]])
}

# model predictions
# expectation value
eNad <- ENad(pct$age,upar,gb.ymin) 
# probabilities
pNcat <- unlist(lapply(1:pdim, function(i) Padeno(pct$Count[i],eNad[i]))) # count category

pcf <- data.frame(pcf,eNad)
pcf$sNad <- pcf$Npno_agrp/pcf$Npat_agrp # screened rel. freq. (based on Npno approximation)
pcf <- data.frame(pcf,pNcat)
pcf$sNcat <- pcf$Npat/pcf$Npat_agrp # screened rel. freq. (from exact Npat)

#pcf$sNcatLBD <- unlist(lapply(1:pdim, function(i) Padeno(pct$Count[i],pcf$sNad[i])))

# check integrity
aggregate(pcf$pNcat, list(pcf$AgeGroup), sum)
aggregate(pcf$sNcat, list(pcf$AgeGroup), sum)

#-------------------------------------------------------------
# adenoma count uncertainties
#-------------------------------------------------------------
pdfsNcat <- list()
pdim <- length(pcf$age)
ctdim <- length(levels(pcf$Count))
agdim <- length(levels(pcf$AgeGroup))
for(i in 1:pdim)
{
  pdfsNcat[[i]] <- rpois(nsim,pcf$Npat[i])
} 

pdfsNagroup <- list()
j = 1
for(i in seq(1,pdim,ctdim))
{
  pdfsNagroup[[j]] <- pdfsNcat[[i]] +  pdfsNcat[[i+1]] +  pdfsNcat[[i+2]] +  pdfsNcat[[i+3]]
  j <- j+1
}

# frequencies in categories
j <- 0
pdfsFreqCat <- list()
for(i in 1:pdim)
{
  if (i%%ctdim == 1){j <- j+1}
  cat(sprintf("i,j = %2d,%2d\n", i,j))
  pdfsFreqCat[[i]] <- pdfsNcat[[i]]/pdfsNagroup[[j]]
} 

# expectation value
count <- c(1,2,5,0)
pdfsCount <- list()
sNad <- vector()
j = 1
for(i in seq(1,pdim,ctdim))
{
  sNad[j] <- pcf$Npno_agrp[i]/pcf$Npat_agrp[i] # screened rel. freq. (based on Npno approximation)
  pdfsCount[[j]] <- count[1]*pdfsFreqCat[[i]] +  count[2]*pdfsFreqCat[[i+1]] +  count[3]*pdfsFreqCat[[i+2]] +  count[4]*pdfsFreqCat[[i+3]]
  j <- j+1
}

sNad.lo <- as.numeric(unlist(lapply(1:agdim,function (i) quantile(pdfsCount[[i]], probs = 0.025))))
sNad.md <- unlist(lapply(pdfsCount,median))
sNad.hi <- as.numeric(unlist(lapply(1:agdim,function (i) quantile(pdfsCount[[i]], probs = 0.975))))

# Poisson deviance
sum(-2*(dpois(pcf$Npat,pcf$pNcat*pcf$Npat_agrp, log = TRUE)-dpois(pcf$Npat,pcf$Npat, log = TRUE)))

#------------------------------------------------
# Poisson distribution exploration
#-----------------------------------------------
pcf.0 <- subset(pcf, Count == "0")
pcf.1 <- subset(pcf, Count == "1")
pcf.2 <- subset(pcf, Count == "2-4")
pcf.5 <- subset(pcf, Count == ">=5")

cdim <- length(pcf.0$age)

lbd.0 <- vector()
lbd.1 <- vector()
lbd.2 <- vector()
lbd.5 <- vector()
for (i in 1:cdim)
{
  p.0 <- pcf.0$sNcat[i]
  lbd.0[i] <- -log(p.0)
  p.1 <- pcf.1$sNcat[i]
  lbd.1[i] <- uniroot(function(lbd) p.1 - dpois(1,lbd), interval = c(0,1))$root
  p.2 <- pcf.2$sNcat[i]
  lbd.2[i] <- uniroot(function(lbd) p.2 - dpois(2,lbd) - dpois(3,lbd) - dpois(4,lbd), interval = c(0,1))$root
  p.5 <- pcf.5$sNcat[i]
  lbd.5[i] <- uniroot(function(lbd) p.5 - (1 - dpois(0,lbd) - dpois(1,lbd) - dpois(2,lbd) - dpois(3,lbd) - dpois(4,lbd)), interval = c(0,2))$root
}

exp.nad <- vector()
exp.nad.app<- vector()
exp.1 <- vector()
exp.2 <- vector()
exp.5 <- vector()
for (i in 1:7)
{
  zaehler <- lbd.5[i] - dpois(1,lbd.5[i]) - 2*dpois(2,lbd.5[i]) - 3*dpois(3,lbd.5[i]) - 4*dpois(4,lbd.5[i])
  nenner <- 1 - dpois(0,lbd.5[i]) - dpois(1,lbd.5[i]) - dpois(2,lbd.5[i]) - dpois(3,lbd.5[i]) - dpois(4,lbd.5[i])
  exp.5[i] <- zaehler/nenner 
  exp.nad[i] <- dpois(1,lbd.1[i]) + 2*dpois(2,lbd.2[i]) + 3*dpois(3,lbd.2[i]) + 4*dpois(4,lbd.2[i]) + zaehler
  exp.nad.app[i] <- dpois(1,lbd.1[i]) + 2*(dpois(2,lbd.2[i]) + dpois(3,lbd.2[i]) + dpois(4,lbd.2[i])) + 5*nenner
  exp.1[i] <- dpois(1,lbd.1[i])
  exp.2[i] <- (2*dpois(2,lbd.2[i]) + 3*dpois(3,lbd.2[i]) + 4*dpois(4,lbd.2[i]))/(dpois(2,lbd.2[i]) + dpois(3,lbd.2[i]) + dpois(4,lbd.2[i]))
}
round(exp.nad,3)
round(exp.nad.app,3)
round(pcf.0$sNad,3)
round(1-pcf.0$sNad/exp.nad,3)
round(exp.2,3)
round(exp.5,3)

round((1-dpois(0,pcf.0$sNad))*100,1)
round((1-pcf.0$sNcat)*100,1)
#round((1-dpois(0,lbd.0))*100,1)
round((1-dpois(0,lbd.1))*100,1)
round((1-dpois(0,lbd.2))*100,1)
round((1-dpois(0,lbd.5))*100,1)

#------------------------------------------------------
# actual recorded data without "none"
#------------------------------------------------------

nf <- subset(df0, shape != "none")

cage.sum <- aggregate(nf$age*nf$npat, list(nf$countcat,nf$agecat), sum)
cage.len <- aggregate(nf$npat, list(nf$countcat,nf$agecat), sum)
cage.mean <- cage.sum$x/cage.len$x

cnpat.sum <- aggregate(nf$npat, list(nf$countcat,nf$agecat), sum)
cnpno.sum <- aggregate(nf$npat*nf$pno, list(nf$countcat,nf$agecat), sum)
cnpno.sum$x/cnpat.sum$x

pct <- data.frame(cage.sum$Group.1,cage.sum$Group.2,cnpat.sum$x,cnpno.sum$x,cage.mean)
names(pct) <- c("Count","AgeGroup","Npat","Npno","age")
pct
dim(pct) # 21 5
pdim <- dim(pct)[1]

# check age group normalization
#aggregate(pct$PNcat,list(pct$AgeGroup),sum)

# measured frequencies in age groups
cnpat.agrp <- aggregate(pct$Npat, list(pct$AgeGroup), sum)
cnpno.agrp <- aggregate(pct$Npno, list(pct$AgeGroup), sum)
help1 <- split(pct, pct$AgeGroup)
nlevels <- length(levels(pct$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- cnpat.agrp$x[i] 
  help1[[i]]$Npno_agrp <- cnpno.agrp$x[i]
}
pcf <- help1[[1]]
for (i in 2:nlevels){
  pcf <- rbind(pcf,help1[[i]])
}

pcf$sNad <- pcf$Npno_agrp/pcf$Npat_agrp # screened rel. freq. (based on Npno approximation)
pcf$sNcat <- pcf$Npat/pcf$Npat_agrp # screened rel. freq. (from exact Npat)

# check integrity
aggregate(pcf$sNcat, list(pcf$AgeGroup), sum)

pcf.1 <- subset(pcf, Count == "1")
pcf.2 <- subset(pcf, Count == "2-4")
pcf.5 <- subset(pcf, Count == ">=5")

cdim <- length(pcf.1$age)

lbd.1 <- vector()
lbd.2 <- vector()
lbd.5 <- vector()
for (i in 1:cdim)
{
  p.1 <- pcf.1$sNcat[i]
  lbd.1[i] <- uniroot(function(lbd) p.1 - dpois(1,lbd)/(1-dpois(0,lbd)), interval = c(0.1,5))$root
  p.2 <- pcf.2$sNcat[i]
  lbd.2[i] <- uniroot(function(lbd) p.2 - (dpois(2,lbd) + dpois(3,lbd) + dpois(4,lbd))/(1-dpois(0,lbd)), interval = c(0.1,3))$root
  p.5 <- pcf.5$sNcat[i]
  lbd.5[i] <- uniroot(function(lbd) p.5 - (1 - dpois(0,lbd) - dpois(1,lbd) - dpois(2,lbd) - dpois(3,lbd) - dpois(4,lbd))/(1-dpois(0,lbd)), interval = c(0.1,10))$root
}

exp.nad <- vector()
exp.nad.app<- vector()
exp.2 <- vector()
exp.5 <- vector()
for (i in 1:7)
{
  zaehler <- lbd.5[i] - dpois(1,lbd.5[i]) - 2*dpois(2,lbd.5[i]) - 3*dpois(3,lbd.5[i]) - 4*dpois(4,lbd.5[i])
  zaehler <- zaehler/(1-dpois(0,lbd.5[i]))
  nenner <- 1 - dpois(0,lbd.5[i]) - dpois(1,lbd.5[i]) - dpois(2,lbd.5[i]) - dpois(3,lbd.5[i]) - dpois(4,lbd.5[i])
  nenner <- nenner/(1-dpois(0,lbd.5[i]))
  exp.5[i] <- zaehler/nenner 
  exp.nad[i] <- dpois(1,lbd.1[i])/(1-dpois(0,lbd.1[i])) +
                 (2*dpois(2,lbd.2[i]) + 3*dpois(3,lbd.2[i]) + 4*dpois(4,lbd.2[i]))/(1-dpois(0,lbd.2[i])) + 
                 zaehler
  exp.nad.app[i] <- dpois(1,lbd.1[i])/(1-dpois(0,lbd.1[i])) + 
                      2*(dpois(2,lbd.2[i]) + dpois(3,lbd.2[i]) + dpois(4,lbd.2[i]))/(1-dpois(0,lbd.2[i])) +
                       5*nenner
  exp.2[i] <- (2*dpois(2,lbd.2[i]) + 3*dpois(3,lbd.2[i]) + 4*dpois(4,lbd.2[i]))/(dpois(2,lbd.2[i]) + dpois(3,lbd.2[i]) + dpois(4,lbd.2[i]))
}
round(exp.nad,3)
round(exp.nad.app,3)
round(pcf.1$sNad,3)
round(exp.2,3)
round(exp.5,3)

round((1-dpois(0,lbd.1))*100,1)
round((1-dpois(0,lbd.2))*100,1)
round((1-dpois(0,lbd.5))*100,1)

#------------------------------------------------------
# binary status yes or no
#------------------------------------------------------

bf <- df0
levels(bf$sizecat)[levels(bf$sizecat)!="<DL"] <- "yes" 
levels(bf$sizecat)[levels(bf$sizecat)=="<DL"] <- "no" 
levels(bf$countcat)[levels(bf$countcat)!="0"] <- "yes" 
levels(bf$countcat)[levels(bf$countcat)=="0"] <- "no" 
bf <- droplevels(bf)
table(bf$sizecat,bf$countcat)


cage.sum <- aggregate(bf$age*bf$npat, list(bf$countcat,bf$agecat), sum)
cage.len <- aggregate(bf$npat, list(bf$countcat,bf$agecat), sum)
cage.mean <- cage.sum$x/cage.len$x
cnpat.sum <- aggregate(bf$npat, list(bf$countcat,bf$agecat), sum)

pct <- data.frame(cage.sum$Group.1,cage.sum$Group.2,cnpat.sum$x,cage.mean)
names(pct) <- c("Count","AgeGroup","Npat","age")
pct
dim(pct) # 14 4
pdim <- dim(pct)[1]

# measured frequencies in age groups
cnpat.agrp <- aggregate(pct$Npat, list(pct$AgeGroup), sum)
help1 <- split(pct, pct$AgeGroup)
nlevels <- length(levels(pct$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- cnpat.agrp$x[i] 
}
pcf <- help1[[1]]
for (i in 2:nlevels){
  pcf <- rbind(pcf,help1[[i]])
}
pcf

pcf$sNcat <- pcf$Npat/pcf$Npat_agrp # screened rel. freq. (from exact Npat)

# check integrity
aggregate(pcf$sNcat, list(pcf$AgeGroup), sum)

# model predictions
# expectation value
eNad <- ENad(pct$age,upar,gb.ymin) 
# probabilities
pNcat <- unlist(lapply(1:pdim, function(i) Padeno_bin(pct$Count[i],eNad[i]))) # count category

pcf.y <- subset(pcf, Count == "yes")
pcf.n <- subset(pcf, Count == "no")

cdim <- length(pcf.y$age)

lbd.y <- vector()
lbd.n <- vector()
for (i in 1:cdim)
{
  p.y <- pcf.y$sNcat[i]
  lbd.y[i] <- -log(p.y)
  p.n <- pcf.n$sNcat[i]
  lbd.n[i] <- -(log(1-p.n))
}

exp.nad <- vector()
nv <- seq(0,1000,1)
for (i in 1:cdim)
{
  exp.nad[i] <- sum(nv*dpois(nv,lbd.n[i]))
}
round(exp.nad,3)

1-dpois(0,lbd.y)
