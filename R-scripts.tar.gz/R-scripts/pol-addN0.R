#----------------------------------------------
# adeno: add outpatients with N=0
# and streamline data set
# jck, 2021/05/05
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects 

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma" # project root directory
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
statdir 
datdir 

#-----------------------------------------------------------------------
# survival data 2007-09 Bavaria
#-----------------------------------------------------------------------
setwd("~/imodel/colonlmu/data_lmu/adenoma/")
surv <- read.csv(file ="BY-surv-2007_09-ab55.csv",header = T)
is.data.frame(surv)

# rescaling and calculation of norm factors
surv$survM <- surv$survM/1e5  
surv$survW <- surv$survW/1e5  
cumSurvM <- sum(surv$survM)
cumSurvW <- sum(surv$survW)

surv$agecat <- 1
surv$agecat[surv$age > 59] <- 2
surv$agecat[surv$age > 64] <- 3
surv$agecat[surv$age > 69] <- 4
surv$agecat[surv$age > 74] <- 5
surv$agecat[surv$age > 79] <- 6
surv$agecat[surv$age > 84] <- 7
surv$agecat <- factor(surv$agecat,labels = c("55-59","60-64","65-69","70-74","75-79","80-84",">84"))
str(surv)
#----------------------------------------------------------
# prepare screening data
#----------------------------------------------------------
setwd("~/imodel/colonlmu/data_lmu/adenoma/")
load("adenoJCK2.RData")
adeno <- adenoJCK2

dim(adeno)
# 66232    20
names(adeno)
#[1] "patid"            "sex"              "byr"              "byrcat"           "age"              "agecat"          
#[7] "EXAMINATIONDATE"  "QUARTAL"          "DIAGNOSECOLONCA"  "DIAGNOSEREKTUMCA" "histkarzinom"     "PATIENTRISIKOFAM"
#[13] "PATIENTRISIKOHER" "adenomhist"       "polypcount"       "polypsize"        "polypshape"       "lok"             
#[19] "adv_adenoma"      "adv_npl"          "pscat"   

summary(adeno)
dim(adeno)[1] # 66232

# no cancers in 2009
table(adeno$histkarzinom,adeno$QUARTAL)
#adeno <- adeno[adeno$QUARTAL < 20091,]
adeno <- adeno[adeno$histkarzinom < 1,]
dim(adeno)
# 65761    21

#adeno <- adeno[complete.cases(adeno),] 
#dim(adeno) # 32415    20

# location should be known
#adeno <- adeno[complete.cases(adeno[ , c(18)]),] 
#dim(adeno) # 51843    20

# location, shape, histo should be known
adeno <- adeno[complete.cases(adeno[ , c("adenomhist","polypcount","polypsize","polypshape","lok")]),] 
#adeno <- adeno[complete.cases(adeno[ , c(15,16,17,18)]),] 
dim(adeno) # 50649    21
#summary(adeno)

# adjust age to range of survival data 55-94
table(adeno$agecat)
adeno$age[adeno$age > 94] <- 94

# concatenate location 
adeno$lok2 <- "proximal"
adeno$lok2[adeno$lok == "both"] <- "distboth"
adeno$lok2[adeno$lok == "distal"] <- "distboth"
adeno$lok2 <- as.factor(adeno$lok2)
#adeno$lok2 <- factor(adeno$lok2, levels = c(1:2), labels = c("proximal","distboth"))
table(adeno$lok,adeno$lok2)

# add column with number of patients
adeno$npat <- 1

#----------------------------------------------------------
# generate grouped patient data with adenoma
#----------------------------------------------------------

adpg <- aggregate(adeno$npat,list(adeno$sex,
                                  adeno$age,
                                  adeno$agecat,
                                  adeno$polypshape,
                                  adeno$lok2,
                                  #adeno$adenomhist,
                                  adeno$polypcount,
                                  adeno$pscat), sum)
is.data.frame(adpg)
headline <- c("sex","age","agecat","shape","loca","countcat","sizecat","npat")
names(adpg) <- headline

dim(adpg)
str(adpg)
summary(adpg)

sum(adpg$npat[adpg$sex == "m"])
sum(adpg$npat[adpg$sex == "w"])

#----------------------------------------------------------
# sex-specific assignment of patients without adenoma
#----------------------------------------------------------

adM <- subset(adeno, sex == "m")
adW <- subset(adeno, sex == "w")

ntotM <- length(adM$sex)/0.25
ntotW <- length(adW$sex)/0.25

cM <- ntotM/cumSurvM
cW <- ntotW/cumSurvW

surv$npatM <- as.integer(surv$survM*cM+.5)
surv$npatW <- as.integer(surv$survW*cW+.5)

sum(surv$npatM)
ntotM
sum(surv$npatW)
ntotW

hist(surv$npatM)

npatADM <- aggregate(adM$npat,list(adM$age),sum)$x
npatADW <- aggregate(adW$npat,list(adW$age),sum)$x
# adjust for empty age group
npatADW[39] <- 0 # age 93 not present
npatADW[40] <- 2

# number of outpatients without detetable adenoma
surv$npatN0M <- surv$npatM - npatADM
surv$npatN0W <- surv$npatW - npatADW

sum(surv$npatN0M)/ntotM # share of outpatients without adenoma
sum(surv$npatN0W)/ntotW

adN0M <- data.frame("m",surv$age,surv$agecat,"none","none","0","<DL",surv$npatN0M)
names(adN0M) <- headline
adN0W <- data.frame("w",surv$age,surv$agecat,"none","none","0","<DL",surv$npatN0W)
names(adN0W) <- headline

adN0 <- rbind(adN0M,adN0W)
adN0$sex <- as.factor(adN0$sex)
adN0$shape <- as.factor(adN0$shape)
adN0$loca <- as.factor(adN0$loca)
adN0$countcat <- as.factor(adN0$countcat)
adN0$sizecat <- as.factor(adN0$sizecat)

str(adN0)

#----------------------------------------------------------
# build complete data frame with/without adenoma
#----------------------------------------------------------
adenoN0 <- rbind(adpg,adN0)
dim(adenoN0)
str(adenoN0)
summary(adenoN0)

#----------------------------------------------------------
# count assignment
#----------------------------------------------------------
adenoN0$pno <- 0
adenoN0$pno[adenoN0$countcat == "1"] <- 1
adenoN0$pno[adenoN0$countcat == "2-4"] <- 3
adenoN0$pno[adenoN0$countcat == ">=5"] <- 5

#----------------------------------------------------------
# size (cm) assignment
#----------------------------------------------------------
sizemin <-  exp((log(0.25)+log(0.5))/2)
adenoN0$size <- 0
adenoN0$size[adenoN0$sizecat == "<0.5"] <- sizemin
adenoN0$size[adenoN0$sizecat == "0.5-1"] <- sizemin*2
adenoN0$size[adenoN0$sizecat == "1-2"] <- sizemin*4
adenoN0$size[adenoN0$sizecat == ">2"] <- sizemin*8

#----------------------------------------------------------
# build central age: acen
#----------------------------------------------------------
adenoN0$acen <- (adenoN0$age-65)/10

#----------------------------------------------------------
# cell size assignment
#----------------------------------------------------------
ymin <- 50
adenoN0$ymin <- ymin # physical DL
sefl <- subset(adenoN0, shape == "sessile" | shape == "flat")
pedu <- subset(adenoN0, shape == "peduncular")

none <- subset(adenoN0, shape == "none")
none$ylo2d <- 0
none$ys2d <- 0
none$yhi2d <- 0
none$ylo3d <- 0
none$ys3d <- 0
none$yhi3d <- 0

sefl$ys2d <- 0
sefl$ys2d[sefl$sizecat == "<0.5"] <- 100
sefl$ys2d[sefl$sizecat == "0.5-1"] <- 400
sefl$ys2d[sefl$sizecat == "1-2"] <- 1600
sefl$ys2d[sefl$sizecat == ">2"] <- 6400

sefl$ylo2d <- 0
sefl$ylo2d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo2d[sefl$sizecat == "0.5-1"] <- 200
sefl$ylo2d[sefl$sizecat == "1-2"] <- 800
sefl$ylo2d[sefl$sizecat == ">2"] <- 3200

sefl$yhi2d <- 0
sefl$yhi2d[sefl$sizecat == "<0.5"] <- 200
sefl$yhi2d[sefl$sizecat == "0.5-1"] <- 800
sefl$yhi2d[sefl$sizecat == "1-2"] <- 3200
sefl$yhi2d[sefl$sizecat == ">2"] <- 12800

sefl$ys3d <- 0
sefl$ys3d[sefl$sizecat == "<0.5"] <- 141
sefl$ys3d[sefl$sizecat == "0.5-1"] <- 1131
sefl$ys3d[sefl$sizecat == "1-2"] <- 9051
sefl$ys3d[sefl$sizecat == ">2"] <- 72408

sefl$ylo3d <- 0
sefl$ylo3d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo3d[sefl$sizecat == "0.5-1"] <- 400
sefl$ylo3d[sefl$sizecat == "1-2"] <- 3200
sefl$ylo3d[sefl$sizecat == ">2"] <- 25600

sefl$yhi3d <- 0
sefl$yhi3d[sefl$sizecat == "<0.5"] <- 400
sefl$yhi3d[sefl$sizecat == "0.5-1"] <- 3200
sefl$yhi3d[sefl$sizecat == "1-2"] <- 25600
sefl$yhi3d[sefl$sizecat == ">2"] <- 204800

# set very small pedu's to zero
pedu$ys2d <- 0
#pedu$ys2d[pedu$sizecat == "<0.5"] <- 100
pedu$ys2d[pedu$sizecat == "0.5-1"] <- 100
pedu$ys2d[pedu$sizecat == "1-2"] <- 400
pedu$ys2d[pedu$sizecat == ">2"] <- 1600

pedu$ylo2d <- 0
#pedu$ys2d[pedu$sizecat == "<0.5"] <- 100
pedu$ylo2d[pedu$sizecat == "0.5-1"] <- ymin
pedu$ylo2d[pedu$sizecat == "1-2"] <- 200
pedu$ylo2d[pedu$sizecat == ">2"] <- 800

pedu$yhi2d <- 0
#pedu$ys2d[pedu$sizecat == "<0.5"] <- 100
pedu$yhi2d[pedu$sizecat == "0.5-1"] <- 200
pedu$yhi2d[pedu$sizecat == "1-2"] <- 800
pedu$yhi2d[pedu$sizecat == ">2"] <- 3200

pedu$ys3d <- 0
#pedu$ys3d[pedu$sizecat == "<0.5"] <- 141
pedu$ys3d[pedu$sizecat == "0.5-1"] <- 141
pedu$ys3d[pedu$sizecat == "1-2"] <- 1131
pedu$ys3d[pedu$sizecat == ">2"] <- 9051

pedu$ylo3d <- 0
#pedu$ys3d[pedu$sizecat == "<0.5"] <- 100
pedu$ylo3d[pedu$sizecat == "0.5-1"] <- ymin
pedu$ylo3d[pedu$sizecat == "1-2"] <- 400
pedu$ylo3d[pedu$sizecat == ">2"] <- 3200

pedu$yhi3d <- 0
#pedu$ys3d[pedu$sizecat == "<0.5"] <- 100
pedu$yhi3d[pedu$sizecat == "0.5-1"] <- 400
pedu$yhi3d[pedu$sizecat == "1-2"] <- 3200
pedu$yhi3d[pedu$sizecat == ">2"] <- 25600

pedu$sizecat[pedu$ys2d == 0] <- "<DL"
pedu$shape[pedu$ys2d == 0] <- "none"
pedu$loca[pedu$ys2d == 0] <- "none"
pedu$countcat[pedu$ys2d == 0] <- "0"

#summary(pedu)
#--------------------------------------------------------
# check shares
#--------------------------------------------------------
ef <- rbind(sefl,pedu,none)
dim(ef)
str(ef)
summary(ef)

mADW <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[1:3])
mN0W <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[4])
mADM <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[5:7])
mN0M <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[8])

round(mADW/(mADW+mN0W),3) # 0.248
round(mN0W/(mADW+mN0W),3) # 0.752
round(mADM/(mADM+mN0M),3) # 0.248
round(mN0M/(mADM+mN0M),3) # 0.752

#--------------------------------------------------------
# prepare shape data with optimal patient groups: sessile
#--------------------------------------------------------
adenoPG <- ef
justsess <- subset(adenoPG, shape == "sessile")
notsess <- subset(adenoPG, shape != "sessile")

notsess$sizecat <- "<DL"
notsess$shape <- "none"
notsess$loca <- "none"
notsess$countcat <- "0"
notsess$pno <- 0
notsess$size <- 0
notsess$ylo2d <- 0
notsess$ys2d <- 0
notsess$yhi2d <- 0
notsess$ylo3d <- 0
notsess$ys3d <- 0
notsess$yhi3d <- 0

resess <- rbind(justsess,notsess)
resess <- droplevels(resess)
str(resess)
table(resess$shape)
names(resess)
newline <- c("sex","age","agecat","shape","loca","countcat","sizecat","pno","size","ymin","ylo2d","ys2d","yhi2d","ylo3d","ys3d","yhi3d","npat")
sess <- with(resess,aggregate(npat,list(sex,age,agecat,shape,loca,countcat,sizecat,pno,size,ymin,ylo2d,ys2d,yhi2d,ylo3d,ys3d,yhi3d),sum))
names(sess) <- newline

dim(justsess)
dim(notsess)
dim(resess)
dim(sess)
str(sess)
aggregate(sess$npat,list(sess$agecat),sum)
sum(sess$npat)
sum(justsess$npat)+sum(notsess$npat)

#--------------------------------------------------------
# prepare shape data with optimal patient groups: flat
#--------------------------------------------------------

justflat <- subset(adenoPG, shape == "flat")
notflat <- subset(adenoPG, shape != "flat")

notflat$sizecat <- "<DL"
notflat$shape <- "none"
notflat$loca <- "none"
notflat$countcat <- "0"
notflat$pno <- 0
notflat$size <- 0
notflat$ylo2d <- 0
notflat$ys2d <- 0
notflat$yhi2d <- 0
notflat$ylo3d <- 0
notflat$ys3d <- 0
notflat$yhi3d <- 0

reflat <- rbind(justflat,notflat)
reflat <- droplevels(reflat)
str(reflat)
table(reflat$shape)
names(reflat)
newline <- c("sex","age","agecat","shape","loca","countcat","sizecat","pno","size","ymin","ylo2d","ys2d","yhi2d","ylo3d","ys3d","yhi3d","npat")
flat <- with(reflat,aggregate(npat,list(sex,age,agecat,shape,loca,countcat,sizecat,pno,size,ymin,ylo2d,ys2d,yhi2d,ylo3d,ys3d,yhi3d),sum))
names(flat) <- newline

dim(justflat)
dim(notflat)
dim(reflat)
dim(flat)
str(flat)
aggregate(flat$npat,list(flat$agecat),sum)
sum(flat$npat)
sum(justflat$npat)+sum(notflat$npat)

#--------------------------------------------------------
# prepare shape data with optimal patient groups: pedu
#--------------------------------------------------------

justpedu <- subset(adenoPG, shape == "peduncular")
notpedu <- subset(adenoPG, shape != "peduncular")

notpedu$sizecat <- "<DL"
notpedu$shape <- "none"
notpedu$loca <- "none"
notpedu$countcat <- "0"
notpedu$pno <- 0
notpedu$size <- 0
notpedu$ylo2d <- 0
notpedu$ys2d <- 0
notpedu$yhi2d <- 0
notpedu$ylo3d <- 0
notpedu$ys3d <- 0
notpedu$yhi3d <- 0

repedu <- rbind(justpedu,notpedu)
repedu <- droplevels(repedu)
str(repedu)
table(repedu$shape)
names(repedu)
newline <- c("sex","age","agecat","shape","loca","countcat","sizecat","pno","size","ymin","ylo2d","ys2d","yhi2d","ylo3d","ys3d","yhi3d","npat")
pedu <- with(repedu,aggregate(npat,list(sex,age,agecat,shape,loca,countcat,sizecat,pno,size,ymin,ylo2d,ys2d,yhi2d,ylo3d,ys3d,yhi3d),sum))
names(pedu) <- newline

dim(justpedu)
dim(notpedu)
dim(repedu)
dim(pedu)
str(pedu)
aggregate(pedu$npat,list(pedu$agecat),sum)
sum(pedu$npat)
sum(justpedu$npat)+sum(notpedu$npat)

#----------------------------------------------------
# check patient numbers
#----------------------------------------------------
sum(sess$npat)
aggregate(sess$npat,list(sess$shape),sum)
sum(pedu$npat)
aggregate(pedu$npat,list(pedu$shape),sum)
sum(flat$npat)
aggregate(flat$npat,list(flat$shape),sum)

sum(adenoPG$npat)
aggregate(ef$npat,list(ef$shape),sum)

aggregate(sess$npat,list(sess$shape),sum)$x[2]/sum(sess$npat)
aggregate(pedu$npat,list(pedu$shape),sum)$x[2]/sum(pedu$npat)
aggregate(flat$npat,list(flat$shape),sum)$x[2]/sum(flat$npat)
aggregate(adenoPG$npat,list(adenoPG$shape),sum)$x[4]/sum(adenoPG$npat)

# write data files into project directory
setwd(datdir)
save(adenoPG, file = "adenoPG-20210518.Rdata")
save(sess, file = "sessPG-20210518.Rdata")
save(flat, file = "flatPG-20210518.Rdata")
save(pedu, file = "peduPG-20210518.Rdata")

#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

pf <- ef
summary(pf)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
#myPalette <- c(cbbPalette[2],cbbPalette[6])
myPalette <- c(cbPalette[2],cbPalette[4],cbPalette[7],cbPalette[1])

library(ggplot2)

fp.1 <- ggplot() + 
  geom_bar(data = pf, aes(x=agecat, y=npat, fill=shape), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = surv, aes(x=agecat, y=npat,fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  xlab("Age group (yr)") +
  facet_grid(sex ~ .) + 
  #scale_x_discrete(limits = levels(pfagrp$grp), breaks = levels(pfagrp$grp)) +
  scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12)) 
#  + theme_bw()  # use a white background
print(fp.1)


