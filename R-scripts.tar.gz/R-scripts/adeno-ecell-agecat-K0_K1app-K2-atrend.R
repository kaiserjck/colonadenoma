#----------------------------------------------
# adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
shp <- "flat"
#shp <- "sessile"
#shp <- "peduncular"

noad <- character()
#noad <- "wN0"
noad <- "noN0"

patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    df0$ymin <- 40
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}

sexc <- character()
#sexc <- "both"
sexc <- "m"
#sexc <- "w"

dims <- character()
#dims <- "2d"
dims <- "3d"

mmname <- character()
#mmname <- "K1"
mmname <- "K2"

meth <- character()
#meth <- "sum" # summation
meth <- "hyp" # hypergeometric function

# likelihood
likc <- character()
#likc <- "posize"
likc <- "permut"

mdv <- character()
mdv <- "atrend"
#mdv <- "std"

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,mdv,sep="-") 

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}
df0$acen <- (df0$age-65)/10

{
  if (dims == "2d"){
    if (shp != "peduncular"){
      Size1cm <- 1/sqrt(800)
      Ninf <- 3200
    }
    else {
      Size1cm <- 1/sqrt(200)
      Ninf <- 800
    }
    gdim <- 2
  }
  else if (dims == "3d"){
    if (shp != "peduncular"){
      Size1cm <- 1/3200^(1/3) # 1 cm
      Ninf <- 25600
    }
    else {
      Size1cm <-  1/400^(1/3)
      Ninf <- 3200 # not used
    }
    gdim <- 3
  }
}

# set detection limit boundaries for preferred models
{
  if (mdv == "pref"){
    if (shp == "sessile") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
#    else if (shp == "peduncular") {
#      df0$ylo[df0$ylo == 50] <- 40
#      df0$ymin[df0$ymin == 50] <- 40}  
  }
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
df0 <- droplevels(df0)

ad <- subset(df0, shape != "none")

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------
# set pardir
{
  if (mdv == "atrend"){thispardir <- atrendpardir}
  else if (mdv == "std"){thispardir <- stdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
dim(sigma)[1]
sigma[1,2] <- sigma[2,1]
if(dim(sigma)[1] == 3)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
}
if(dim(sigma)[1] == 4)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
}
if(dim(sigma)[1] == 5)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
  sigma[1,5] <- sigma[5,1]
  sigma[2,5] <- sigma[5,2]
  sigma[3,5] <- sigma[5,3]
  sigma[4,5] <- sigma[5,4]
}
cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov
#pr[1] <- log(pr[1])
if (all(1 == sign(eigen(sigma)$values)) == TRUE)
  #if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
#Z[,1] <- exp(Z[,1])
apply(Z,2,mean)
#apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

#-----------------------------------------------------------------
# assign parms
#-----------------------------------------------------------------
upar <- dpar$parval

if(mdv == "std"){
  npar <- length(upar)
  upar[npar+1] <- 0
  nvarpar <- dim(df.par)[2]
  df.par[,nvarpar+1] <- 0
}

df.par[1:10,]

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-distrib-size.R")

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
      Esize <- EsizeK0
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
    Esize <- EsizeK1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
    Esize <- EsizeK1
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.hyp
    Thelohi <- theta_lohi_K2.hyp
    Esize <- EsizeK2
  }
  else
  {
    print("Not implemented\n")
  }
}

#--------------------------------
# load df.canag
#--------------------------------
setwd(datdir)
load(file = "canag-20220614.Rdata")
head(df.canag)
str(df.canag)

cf <- subset(df.canag, Shape == shp & Sex == sexc)
cf

#--------------------------------
# model predictions for mean cell size
#--------------------------------

# convergence test
#EsizeK2.sum(65,upar,1,0,1000*Ninf)
#EsizeK2.sum(65,upar,1,0,100*Ninf)
#EsizeK2.sum(65,upar,1,0,10*Ninf)
#EsizeK2.hyp(65,upar,1,0,10*Ninf)

#EsizeK2.sum(85,upar,1,0,1000*Ninf)
#EsizeK2.sum(85,upar,1,0,100*Ninf)
#EsizeK2.sum(85,upar,1,0,10*Ninf)
#EsizeK2.hyp(85,upar,1,0,10*Ninf)

#age <- seq(55,90,1)
age <- cf$mage
ndim <- length(age)
#ncell <- unlist(lapply (1:ndim, function(i) ymeanK1(age[i],upar,gb.ymin)))
#ncell <- unlist(lapply (1:ndim, function(i) EsizeK2.sum(age[i],upar,1,gb.ymin,10*Ninf)))
ncell <- vector()
nclone <- vector()
for(i in 1:ndim)
{
  nclone[i] <- ENadK2.hyp(age[i],upar,0)
  ncell[i] <- EsizeK2.sum(age[i],upar,1,0,100*Ninf)
  cat(sprintf("age %g of ageend %g completed\n", age[i],max(age)))
}

{
  if (sexc == "w"){sexcc <- "women"}
  else if (sexc == "m"){sexcc <- "men"}
}

cf$Shape <- "flat,3d"
headline <- names(cf)
ecf <- data.frame(cf,nclone,ncell,ncell*nclone)
names(ecf) <- c(headline,"eNad","eYad","eCad")
ecf
#ecf <- data.frame(shp,sexcc,dims,age,nclone,ncell,ncell*nclone)
#names(ecf) <- c("Shape","Sex","Dim","age","eNad","eYad","eCad")
#ecf

# plot file saving
fname
ffname <- paste("canc-ecell",fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(curvdir)
save(ecf,file = fsavname)

#-----------------------------------------------------------------
# bind all together
#-----------------------------------------------------------------
setwd(curvdir)
load(file = "canc-ecell-sessile-w-2d-K2-permut-atrend.Rdata")
s.w <- ecf
load(file = "canc-ecell-sessile-m-2d-K2-permut-atrend.Rdata")
s.m <- ecf
load(file = "canc-ecell-peduncular-w-2d-K2-permut-atrend.Rdata")
p.w <- ecf
load(file = "canc-ecell-peduncular-m-2d-K2-permut-atrend.Rdata")
p.m <- ecf
load(file = "canc-ecell-flat-w-2d-K2-permut-atrend.Rdata")
f.w <- ecf
load(file = "canc-ecell-flat-m-2d-K2-permut-atrend.Rdata")
f.m <- ecf
load(file = "canc-ecell-flat-w-3d-K2-permut-atrend.Rdata")
f.w.3d <- ecf
load(file = "canc-ecell-flat-m-3d-K2-permut-atrend.Rdata")
f.m.3d <- ecf
load(file = "canc-ecell-all-w-2d-K2-permut-atrend.Rdata")
a.w <- ecf
load(file = "canc-ecell-all-m-2d-K2-permut-atrend.Rdata")
a.m <- ecf

ecf.canag <- rbind(a.w,a.m,s.w,s.m,p.w,p.m,f.w,f.m,f.w.3d,f.m.3d)
setwd(curvdir)
save(ecf.cell, file = "canag-ecell-20220626.Rdata")

