#----------------------------------------------
# plot adeno pcount analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="pcount-all-w-2d-K2-permut-atrend.Rdata")
s.w <- pcf

load(file="pcount-all-m-2d-K2-permut-atrend.Rdata")
s.m <- pcf

# build and adjust pf
pf <- rbind(s.w,s.m)
#str(pf)
levels(pf$AgeGroup)[levels(pf$AgeGroup) == "79-84"] <- "80-84"
#levels(df$conf)[levels(df$conf)=='North'] <- 'N'
pf$Source <- fct_rev(pf$Source)
pf <- droplevels(pf)

#--------------------------------------------------------------------------------------
# calculate share according to Poisson distribution, Poisson distribution is additive
# double check yields identical distribution
#--------------------------------------------------------------------------------------
mdf <- subset(pf, Source == "M") # model
mdf$pNcat[mdf$Count == "0"] <- dpois(0,mdf$enad[mdf$Count == "0"])
mdf$pNcat[mdf$Count == "1"] <- dpois(1,mdf$enad[mdf$Count == "1"])
mdf$pNcat[mdf$Count == "2-4"] <- dpois(2,mdf$enad[mdf$Count == "2-4"]) + dpois(3,mdf$enad[mdf$Count == "2-4"]) + dpois(4,mdf$enad[mdf$Count == "2-4"])
mdf$pNcat[mdf$Count == ">=5"] <- 1-(mdf$pNcat[mdf$Count == "0"] + mdf$pNcat[mdf$Count == "1"] + mdf$pNcat[mdf$Count == "2-4"])
mdf$pNcat[mdf$pNcat < 0] <- 1e-6

sdf <- subset(pf, Source == "S") # screening

#pf <- rbind(sdf,mdf) # re-assemble

#-----------------------------
# prepare plotting
#-----------------------------
summary(pf)
setwd(plotdir)

#pf.1 <- subset(pf, Sex == "men")
pf.1 <- pf

label_fill <- c("Screening","Model")
pf.1$Count <- fct_relevel(pf.1$Count,c("0","1","2-4",">=5"))
fp.1 <- ggplot(data = pf.1, aes(x=Count, y=pNcat*100, fill = Source)) + 
  ggtitle("all shapes") + 
  geom_bar(stat="identity", position="dodge", width = 0.8) +
  #geom_text(aes(x=Count, y=pNcat*100, label = sprintf("%d", round(pNcat*100, digits = 0))), position=position_dodge(width = 1), vjust=-0.2) +
  geom_text(aes(x=Count, y=pNcat*100, 
                             label = sprintf("%d", round(pNcat*100, digits = 0))), position=position_dodge(width = 0.9), vjust=-0.2) +
  geom_text(data = subset(pf.1,Source == "S"), aes(x = 3.6, y = 70, label = sprintf("Npat = %d", Npat_agrp))) +
  #geom_text(aes(x = 2.9, y = 0.7, label = sprintf("N = %d", Npat))) +
  #geom_errorbar(aes(ymin=share.lo, ymax=share.hi), width=.2, position=position_dodge(.8)) +
  scale_fill_manual(values = myPalette, labels = label_fill) +
  xlab("Adenoma count") +
  facet_grid(AgeGroup ~ Sex) + 
  #facet_grid(AgeGroup ~ .) + 
  #scale_x_discrete(limits = levels(pf$Size), breaks = levels(pf$Size)) +
  #scale_y_continuous(name="Share in age group (%)", labels = scales::percent, limits=c(0,1.1), breaks = seq(0,1,0.5)) +
  scale_y_continuous(name="Share in age group (%)", limits=c(0,115), breaks = seq(0,100,50)) +
  #scale_y_continuous(name="Share in age group (%)", trans = "log10") +
  #scale_color_manual(values=cbbPalette[3:5]) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12), legend.position = "none", legend.title = element_blank()) 
#  + theme_bw()  # use a white background
print(fp.1)


legend_title <- "Source"
pf.2 <- subset(pf, Count == "0")
pf.2.s <- subset(pf.2, Source == "S")
fp.2 <- ggplot(data=pf.2, aes(y= 1-pNcat, x = AgeGroup, color=Source)) +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  #geom_bar(stat="identity", position = "fill", width = 0.8) + 
  geom_linerange(data = pf.2.s, aes(x = AgeGroup, y = 1-pNcat, ymin = 1-pNcat.lo, ymax = 1-pNcat.hi), color = cbPalette[1]) + 
  geom_point(size = 3) + 
  facet_grid (Sex ~ .) +
  scale_y_continuous(name="Prevalence") +
  scale_color_manual(values=cbPalette[c(1:3,8)]) +
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15), legend.position = c(0.2,0.9)) 
print(fp.2)
