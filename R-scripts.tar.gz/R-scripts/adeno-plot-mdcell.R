#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="mdcell-flat-w-3d-K2-posize-atrend.Rdata")
mdf$Shape <- "flat,3d"
f.3d.w <- mdf

load(file="mdcell-flat-m-3d-K2-posize-std.Rdata")
mdf$Shape <- "flat,3d"
f.3d.m <- mdf

load(file="mdcell-flat-w-2d-K2-posize-atrend.Rdata")
mdf$Shape <- "flat,2d"
f.2d.w <- mdf

load(file="mdcell-flat-m-2d-K2-posize-std.Rdata")
mdf$Shape <- "flat,2d"
f.2d.m <- mdf

load(file="mdcell-sessile-m-2d-K2-posize-atrend.Rdata")
s.w <- mdf

load(file="mdcell-sessile-w-2d-K2-posize-atrend.Rdata")
s.m <- mdf

load(file="mdcell-peduncular-w-2d-K2-posize-atrend.Rdata")
p.w <- mdf

load(file="mdcell-peduncular-m-2d-K2-posize-std.Rdata")
p.m <- mdf

pf <- rbind(f.2d.w,f.2d.m,f.3d.w,f.3d.m,s.w,s.m,p.w,p.m)
pf$Sex <- fct_rev(pf$Sex)
pf$Source <- fct_rev(pf$Source)
levels(pf$Sex)[levels(pf$Sex)=="w"] <- "women"
levels(pf$Sex)[levels(pf$Sex)=="m"] <- "men"
pf$Shape <- fct_relevel(pf$Shape,c("flat,3d","flat,2d","peduncular","sessile"))
#pf <- subset(pf, AgeGroup != ">84")
pf <- droplevels(pf)
summary(pf)
setwd(plotdir)

fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf, aes(x=age, y=y.md, color = Shape, linetype = Sex), size = 1) +
  #geom_line(data = pf.2, aes(x = age, y =sizecm, color = Shape)) +
  #facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,85), breaks = seq(40,80,10)) +
  scale_y_continuous(name = "Median cell number") + 
  #scale_y_continuous(name="Mean cell number", limits=c(0.4,1.25), breaks = seq(0.4,1.25,0.2)) +
  scale_color_manual(values=cbPalette[c(2,3,7,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.85)) 
#  + theme_bw()  # use a white background
print(fp.1)

# plot with age extrapolation marked
pf.early <- subset(pf, age < 55)
pf.early <- data.frame(pf.early,"early")
names(pf.early)[6] <- "Period"
pf.late <- subset(pf, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[6] <- "Period"

pf.2 <- rbind(pf.early,pf.late)

fp.2 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf.2, aes(x=age, y=y.md, color = Shape,linetype = Period), size = 1) +
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name = "Median cell number") + 
  scale_color_manual(values=cbPalette[c(2,3,7,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.89)) 
#  + theme_bw()  # use a white background
print(fp.2)

