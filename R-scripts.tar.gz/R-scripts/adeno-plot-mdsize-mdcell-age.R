#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)

# sizecm
load(file="sizecm-age20_90-flat-w-3d-K2-permut-atrend.Rdata")
ecf$Shape <- "flat,3d"
f.3d.w <- ecf

load(file="sizecm-age20_90-flat-m-3d-K2-permut-atrend.Rdata")
ecf$Shape <- "flat,3d"
f.3d.m <- ecf

load(file="sizecm-age20_90-flat-w-2d-K2-permut-atrend.Rdata")
ecf$Shape <- "flat,2d"
f.2d.w <- ecf

load(file="sizecm-age20_90-flat-m-2d-K2-permut-atrend.Rdata")
ecf$Shape <- "flat,2d"
f.2d.m <- ecf

load(file="sizecm-age20_90-sessile-w-2d-K2-permut-atrend.Rdata")
s.w <- ecf

load(file="sizecm-age20_90-sessile-m-2d-K2-permut-atrend.Rdata")
s.m <- ecf

load(file="sizecm-age20_90-peduncular-w-2d-K2-permut-atrend.Rdata")
p.w <- ecf

load(file="sizecm-age20_90-peduncular-m-2d-K2-permut-atrend.Rdata")
p.m <- ecf

pf.s <- rbind(f.2d.w,f.2d.m,f.3d.w,f.3d.m,s.w,s.m,p.w,p.m)
pf.s$Sex <- fct_rev(pf.s$Sex)
levels(pf.s$Sex)[levels(pf.s$Sex)=="w"] <- "women"
levels(pf.s$Sex)[levels(pf.s$Sex)=="m"] <- "men"
pf.s$Shape <- fct_relevel(pf.s$Shape,c("flat,3d","flat,2d","peduncular","sessile"))
pf.s <- data.frame("Mean size (cm)",pf.s$Shape,pf.s$Sex,pf.s$age,pf.s$sizecm)
names(pf.s) <- c("quantity","Shape","Sex","age","value")
pf.s <- droplevels(pf.s)
summary(pf.s)

# median
load(file="mdcell-flat-w-3d-K2-permut-atrend.Rdata")
mdf$Shape <- "flat,3d"
mdf$sizemd <- (mdf$y.md/3200)^(1/3)
f.3d.w <- mdf

load(file="mdcell-flat-m-3d-K2-permut-atrend.Rdata")
mdf$Shape <- "flat,3d"
mdf$sizemd <- (mdf$y.md/3200)^(1/3)
f.3d.m <- mdf

load(file="mdcell-flat-w-2d-K2-permut-atrend.Rdata")
mdf$Shape <- "flat,2d"
mdf$sizemd <- sqrt(mdf$y.md/800)
f.2d.w <- mdf

load(file="mdcell-flat-m-2d-K2-permut-atrend.Rdata")
mdf$Shape <- "flat,2d"
mdf$sizemd <- sqrt(mdf$y.md/800)
f.2d.m <- mdf

load(file="mdcell-sessile-m-2d-K2-permut-atrend.Rdata")
mdf$sizemd <- sqrt(mdf$y.md/800)
s.w <- mdf

load(file="mdcell-sessile-w-2d-K2-permut-atrend.Rdata")
mdf$sizemd <- sqrt(mdf$y.md/800)
s.m <- mdf

load(file="mdcell-peduncular-w-2d-K2-permut-atrend.Rdata")
mdf$sizemd <- sqrt(mdf$y.md/200)
p.w <- mdf

load(file="mdcell-peduncular-m-2d-K2-permut-atrend.Rdata")
mdf$sizemd <- sqrt(mdf$y.md/200)
p.m <- mdf

pf.m <- rbind(f.2d.w,f.2d.m,f.3d.w,f.3d.m,s.w,s.m,p.w,p.m)
pf.m$Sex <- fct_rev(pf.m$Sex)
levels(pf.m$Sex)[levels(pf.m$Sex)=="w"] <- "women"
levels(pf.m$Sex)[levels(pf.m$Sex)=="m"] <- "men"
pf.m$Shape <- fct_relevel(pf.m$Shape,c("flat,3d","flat,2d","peduncular","sessile"))

# cell median
pf.ymd <- data.frame("Median cell number",pf.m$Shape,pf.m$Sex,pf.m$age,pf.m$y.md)
names(pf.ymd) <- c("quantity","Shape","Sex","age","value")
pf.ymd <- droplevels(pf.ymd)
summary(pf.ymd)

# size median (cm)
pf.smd <- data.frame("Median size (cm)",pf.m$Shape,pf.m$Sex,pf.m$age,pf.m$sizemd)
names(pf.smd) <- c("quantity","Shape","Sex","age","value")
pf.smd <- droplevels(pf.smd)
summary(pf.smd)

#------------------------------------------------------
# start plotting
#------------------------------------------------------
setwd(plotdir)

pf <- pf.smd

fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(data = pf, aes(x=age, y=value, color = Shape, linetype = Sex), size = 1) +
  geom_smooth(data = pf, method = "lm", formula = y ~ poly(x, 3), se = FALSE, 
              aes(x=age, y=value, color = Shape, linetype = Sex), size = 1) +
  #geom_line(data = pf.2, aes(x = age, y =sizecm, color = Shape)) +
  #facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,85), breaks = seq(40,80,10)) +
  scale_y_continuous(name = "Median size (cm)") + 
  #scale_y_continuous(name="Mean cell number", limits=c(0.4,1.25), breaks = seq(0.4,1.25,0.2)) +
  scale_color_manual(values=cbPalette[c(3,2,7,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.85)) 
#  + theme_bw()  # use a white background
print(fp.1)

pf <- rbind(pf.smd,pf.ymd)
# plot with age extrapolation marked
pf.early <- subset(pf, age < 55)
pf.early <- data.frame(pf.early,"early")
noNames <- dim(pf.early)[2]
names(pf.early)[noNames] <- "Period"
pf.late <- subset(pf, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[noNames] <- "Period"

pf.2 <- rbind(pf.early,pf.late)
#pf.2$quantity <- fct_rev(pf.2$quantity)

fp.2 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(data = pf.2, aes(x=age, y=value, color = Shape, linetype = Period), size = 1) +
  geom_smooth(data = pf.2, method = "lm", formula = y ~ poly(x, 3), se = FALSE, 
              aes(x=age, y=value, color = Shape, linetype = Period), size = 1) +
  facet_grid(quantity ~ Sex, scales = "free_y") + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  #scale_y_continuous(name = "Median cell number") + 
  scale_color_manual(values=cbPalette[c(3,2,7,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),
        axis.title.y=element_blank(),
        legend.position = c(.15,0.9)) 
#  + theme_bw()  # use a white background
print(fp.2)

