#----------------------------------------------
# plot adeno enad analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file = "HRadj-corley.Rdata")
df.cor
df.cor <- subset(df.cor, Sex != "both")
df.cor$Sex <- fct_relevel(df.cor$Sex,"women","men")

load(file="HReff-a65-5yr-reffy_100p-all-w-2d-K2-permut-atrend.Rdata")
f.w <- af

load(file="HReff-a65-5yr-reffy_100p-all-m-2d-K2-permut-atrend.Rdata")
f.m <- af

load(file="HReff-a65-5yr-reffy_50p-all-w-2d-K2-permut-atrend.Rdata")
s.w <- af

load(file="HReff-a65-5yr-reffy_50p-all-m-2d-K2-permut-atrend.Rdata")
s.m <- af

# build and adjust pf
pf <- rbind(f.w,f.m,s.w,s.m)
pf$Sex <- fct_relevel(pf$Sex,"w","m")
levels(pf$Sex)[levels(pf$Sex)== "w"] <- "women"
levels(pf$Sex)[levels(pf$Sex)== "m"] <- "men"
pf$rYeff <- factor(pf$rYeff)
pf <- droplevels(pf)
summary(pf)
str(pf)
#----------------------------------------------------------
# plotting
#----------------------------------------------------------
setwd(plotdir)

legend_title <- expression(paste(r[Y]^eff))
#y_title <- expression(paste(RR[eff]))
#y_title <- bquote(RR[eff])
y_title <- expression('Hazard ratio HR'[eff])
fp.1 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= RR2eff, x = ADReff*100, linetype = rYeff, color = Sex), size = 1.2) + 
  facet_grid (Sex ~ .) +
  scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,50), breaks = seq(0,50,10)) +
  scale_y_continuous(name = y_title, limits = c(0,1), breaks = seq(0,1,0.2)) +
  scale_color_manual(values=cbPalette[c(2,3)]) +
  scale_linetype_manual(legend_title, values = c("dotdash", "solid")) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.15,0.7)) 
print(fp.1)

#---------------------------------------------------
# Adjusting to ADR = 0.1656 (Corley NEJM 20214)
#---------------------------------------------------
help1 <- split(pf, pf$rYeff)
#View(help1[[2]])
x.l.w <- 52
x.h.w <- 53
#x.l.w <- 71
#x.h.w <- 72
x.l.m <- 130
x.h.m <- 131
#ADRp.w <- 0.2150
ADRp.w <- 0.1656
ADRp.m <- 0.1656

df.hazR <- help1[[1]]

# women
x.l <- x.l.w
x.h <- x.h.w
m <- (df.hazR$RR2eff[x.h] - df.hazR$RR2eff[x.l])/(df.hazR$ADReff[x.h] - df.hazR$ADReff[x.l])
b <- df.hazR$RR2eff[x.l] - m*df.hazR$ADReff[x.l]
yp.w <- m*ADRp.w+b
yp.w

# men
x.l <- x.l.m
x.h <- x.h.m
m <- (df.hazR$RR2eff[x.h] - df.hazR$RR2eff[x.l])/(df.hazR$ADReff[x.h] - df.hazR$ADReff[x.l])
b <- df.hazR$RR2eff[x.l] - m*df.hazR$ADReff[x.l]
yp.m <- m*ADRp.m+b
yp.m

df.hazR$hrCor <- 1
df.hazR$hrCor[df.hazR$Sex == "women"] <- df.hazR$RR2eff[df.hazR$Sex == "women"]/yp.w
df.hazR$hrCor[df.hazR$Sex == "men"] <- df.hazR$RR2eff[df.hazR$Sex == "men"]/yp.m

pf.1 <- df.hazR

df.hazR <- help1[[2]]

# women
x.l <- x.l.w
x.h <- x.h.w
m <- (df.hazR$RR2eff[x.h] - df.hazR$RR2eff[x.l])/(df.hazR$ADReff[x.h] - df.hazR$ADReff[x.l])
b <- df.hazR$RR2eff[x.l] - m*df.hazR$ADReff[x.l]
yp.w <- m*ADRp.w+b
yp.w

# men
x.l <- x.l.m
x.h <- x.h.m
m <- (df.hazR$RR2eff[x.h] - df.hazR$RR2eff[x.l])/(df.hazR$ADReff[x.h] - df.hazR$ADReff[x.l])
b <- df.hazR$RR2eff[x.l] - m*df.hazR$ADReff[x.l]
yp.m <- m*ADRp.m+b
yp.m

df.hazR$hrCor <- 1
df.hazR$hrCor[df.hazR$Sex == "women"] <- df.hazR$RR2eff[df.hazR$Sex == "women"]/yp.w
df.hazR$hrCor[df.hazR$Sex == "men"] <- df.hazR$RR2eff[df.hazR$Sex == "men"]/yp.m

pf.2 <- df.hazR

pf <- rbind(pf.1,pf.2)

legend_title <- expression(paste(r[Y]^eff))
#y_title <- expression(paste(RR[eff]))
#y_title <- bquote(RR[eff])
#y_title <- expression('Hazard ratio HR'[eff])
#y_title <- expression(paste('Hazard ratio HR'[eff]))
y_title <- expression(paste('Hazard ratio HR'[eff], ' for interval cancer'))
fp.2 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= hrCor, x = ADReff*100, linetype = rYeff, color = Sex), size = 1.2) + 
  #geom_point(data = df.dor, aes(y= HRmn, x = ADReff*100), size = 2) + 
  facet_grid (Sex ~ .) +
  scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,50), breaks = seq(0,50,10)) +
  scale_y_continuous(name=y_title, limits = c(0,2), breaks = seq(0,2,0.5)) +
  scale_color_manual(labels= c("women", "men"), values=cbPalette[c(2,3)]) +
  scale_linetype_manual(legend_title, values = c("solid", "dotdash")) +
  geom_point(data = df.cor, aes(x = ADR*100, y = HRmn), size = 4) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  geom_linerange(data = df.cor, aes(x = ADR*100, y = HRmn, ymin = HRlo, ymax = HRhi), size = 0.75) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(color = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.85,0.4)) 
print(fp.2)

#-----------------------------------------------------
# adjusted HRs, Dorley et al., NEJM, 2014, Table 2
#-----------------------------------------------------
#ADR <- c(0.1656,0.2150,0.2570,0.3096,0.3886)
#HRmn.m <- c(1,0.79,0.82,0.69,0.60)
#HRlo.m <- c(1,0.55,0.61,0.48,0.42)
#HRhi.m <- c(1,1.14,1.08,0.99,0.88)
#HRmn.w <- c(1,1.07,0.89,0.70,0.43)
#HRlo.w <- c(1,0.74,0.63,0.49,0.28)
#HRhi.w <- c(1,1.56,1.26,1.01,0.66)
#HRmn.b <- c(1,1.93,0.85,0.70,0.52)
#HRlo.b <- c(1,0.70,0.68,0.54,0.39)
#HRhi.b <- c(1,1.23,1.06,0.91,0.69)

#headline <- c("Sex","ADR","HRmn","HRlo","HRhi")
#df.w <- data.frame("women",ADR,HRmn.w,HRlo.w,HRhi.w)
#names(df.w) <- headline
#df.m <- data.frame("men",ADR,HRmn.m,HRlo.m,HRhi.m)
#names(df.m) <- headline
#df.b <- data.frame("both",ADR,HRmn.b,HRlo.b,HRhi.b)
#names(df.b) <- headline

#df.cor <- rbind(df.w,df.m,df.b)
#df.cor

#setwd(curvdir)
#fname <- "HRadj-corley.Rdata"
#save(df.cor, file = fname)