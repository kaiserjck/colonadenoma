#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(datdir)
load(file = "nu65fit-canag-20220215.Rdata")
#cf <- subset(cf, Shape != "flat,2d")
cf <- subset(cf, chaz > 0)
#names(cf)[1] <- "Shape"
#names(cf)[2] <- "Sex"
#cf$Sex[cf$Sex == "w"] <- "women"
#cf$Sex[cf$Sex == "m"] <- "men"
levels(cf$Sex)[levels(cf$Sex)=="w"] <- "women"
levels(cf$Sex)[levels(cf$Sex)=="m"] <- "men"
cf$pshp <- "shp1"
cf$mage[cf$Shape == "flat"] <- cf$mage[cf$Shape == "flat"] - 1
cf$mage[cf$Shape == "peduncular"] <- cf$mage[cf$Shape == "peduncular"] + 1
cf$Sex <- fct_rev(cf$Sex)
cf

#-----------------------------------------------------
# read cells per adenoma
#------------------------------------------------------
setwd(statdir)
setwd("sizeexp")

headline <- c("Shape","Sex","refage","age","ncell")
p.age.m <- read.csv(file = "ecell-peduncular-pref-age-m.csv")
p.age.m <- data.frame("peduncular","men","trend",p.age.m$age,p.age.m$ncell)
names(p.age.m) <- headline
p.age.w <- read.csv(file = "ecell-peduncular-pref-age-f.csv")
p.age.w <- data.frame("peduncular","women","trend",p.age.w$age,p.age.w$ncell)
names(p.age.w) <- headline

f.age.m <- read.csv(file = "ecell-flat-pref-age-m.csv")
f.age.m <- data.frame("flat","men","trend",f.age.m$age,f.age.m$ncell)
names(f.age.m) <- headline
f.age.w <- read.csv(file = "ecell-flat-pref-age-f.csv")
f.age.w <- data.frame("flat","women","trend",f.age.w$age,f.age.w$ncell)
names(f.age.w) <- headline

f2d.age.m <- read.csv(file = "ecell-flat-2d-age-m.csv")
f2d.age.m <- data.frame("flat,2d","men","trend",f2d.age.m$age,f2d.age.m$ncell)
names(f2d.age.m) <- headline
f2d.age.w <- read.csv(file = "ecell-flat-2d-age-w.csv")
f2d.age.w <- data.frame("flat,2d","women","trend",f2d.age.w$age,f2d.age.w$ncell)
names(f2d.age.w) <- headline

s.age.m <- read.csv(file = "ecell-sessile-pref-age-m.csv")
s.age.m <- data.frame("sessile","men","trend",s.age.m$age,s.age.m$ncell)
names(s.age.m) <- headline
s.age.w <- read.csv(file = "ecell-sessile-pref-age-f.csv")
s.age.w <- data.frame("sessile","women","trend",s.age.w$age,s.age.w$ncell)
names(s.age.w) <- headline

pf.size <- rbind(f.age.w,f.age.m,s.age.w,s.age.m,p.age.w,p.age.m)

#-----------------------------------------------------
# read adenoma per colonoscopy
#------------------------------------------------------
setwd(curvdir)
# read model prediction from age 20,90
load(file="enad-age-flat-all-w-3d-K2-dist-atrend.Rdata")
f.age.w <- eaf

load(file="enad-age-flat-all-m-3d-K2-dist-atrend.Rdata")
f.age.m <- eaf

load(file="enad-age-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.age.w <- eaf

load(file="enad-age-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.age.m <- eaf

load(file="enad-age-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
p.age.w <- eaf

load(file="enad-age-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
p.age.m <- eaf

pf.enad <- rbind(f.age.w,f.age.m,s.age.w,s.age.m,p.age.w,p.age.m)

# build and adjust pf
pf <- pf.size
pf$enad <- pf.enad$enad
pf$ecell <- pf$enad*pf$ncell
summary(pf)
pf <- droplevels(pf)
#pf$Source <- fct_rev(pf$Source)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("flat","sessile","peduncular"))
#summary(pf)
str(pf)

#---------------------------------------
# create hazard estimate from nu estimate
#---------------------------------------
pf$acen <- (pf$age-65)/10
pf$haz <- -1

# flat: no exponential hazard increase
cf.t <- subset(cf, Sex == "men" & Shape == "flat" & agecat == "55-59")
pf$haz[pf$Sex == "men" & pf$Shape == "flat"] <- pf$ecell[pf$Sex == "men" & pf$Shape == "flat"]*
  cf.t$nu65*exp(cf.t$cacen*pf$acen[pf$Sex == "men" & pf$Shape == "flat"])
cf.t <- subset(cf, Sex == "women" & Shape == "flat" & agecat == "55-59")
pf$haz[pf$Sex == "women" & pf$Shape == "flat"] <- pf$ecell[pf$Sex == "women" & pf$Shape == "flat"]*
  cf.t$nu65*exp(cf.t$cacen*pf$acen[pf$Sex == "women" & pf$Shape == "flat"])

# sessile: exponential hazard increase significant
cf.t <- subset(cf, Sex == "men" & Shape == "sessile" & agecat == "55-59")
pf$haz[pf$Sex == "men" & pf$Shape == "sessile"] <- pf$ecell[pf$Sex == "men" & pf$Shape == "sessile"]*
  cf.t$nu65*exp(cf.t$cacen*pf$acen[pf$Sex == "men" & pf$Shape == "sessile"])
cf.t <- subset(cf, Sex == "women" & Shape == "sessile" & agecat == "55-59")
pf$haz[pf$Sex == "women" & pf$Shape == "sessile"] <- pf$ecell[pf$Sex == "women" & pf$Shape == "sessile"]*
  cf.t$nu65*exp(cf.t$cacen*pf$acen[pf$Sex == "women" & pf$Shape == "sessile"])

# peduncular: exponential hazard increase significant
cf.t <- subset(cf, Sex == "men" & Shape == "peduncular" & agecat == "55-59")
pf$haz[pf$Sex == "men" & pf$Shape == "peduncular"] <- pf$ecell[pf$Sex == "men" & pf$Shape == "peduncular"]*
  cf.t$nu65*exp(cf.t$cacen*pf$acen[pf$Sex == "men" & pf$Shape == "peduncular"])
cf.t <- subset(cf, Sex == "women" & Shape == "peduncular" & agecat == "55-59")
pf$haz[pf$Sex == "women" & pf$Shape == "peduncular"] <- pf$ecell[pf$Sex == "women" & pf$Shape == "peduncular"]*
  cf.t$nu65*exp(cf.t$cacen*pf$acen[pf$Sex == "women" & pf$Shape == "peduncular"])

#setwd(curvdir)
#ecf <- pf
#save(ecf, file = "ecell-haz-age20_90.RData")

#--------------------------------------
# start plotting
#--------------------------------------
cf.age <- subset(cf, agecat != "total")
setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(aes(y=ncell, color = Shape, linetype = Sex), size = 1) +
  geom_line(data = pf, aes(x=age, y=haz/ecell, color = Shape, linetype = Sex), size = 1) +
  #geom_point(data = cf.age, aes(x=mage, y=chaz, color = Shape, shape = Sex), size = 4) + 
  #geom_linerange(data = cf.age, aes(x = mage, y=chaz, ymax = chaz.hi, ymin = chaz.lo), size = .75) +
  facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,85), breaks = seq(40,80,10)) +
  #scale_y_log10(name = bquote('Hazard '(yr^-1)),
                #breaks = trans_breaks("log10", function(x) 10^x),
  #              labels = trans_format("log10", math_format(10^.x))) +
  #scale_y_continuous(name="Mean cell number", limits=c(0.4,1.25), breaks = seq(0.4,1.25,0.2)) +
  scale_color_manual(values=cbPalette[c(2,4,7)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.85)) 
#  + theme_bw()  # use a white background
print(fp.1)

# plot with age extrapolation marked
pf.early <- subset(pf, age < 55)
pf.early <- data.frame(pf.early,"early")
names(pf.early)[10] <- "Period"
pf.late <- subset(pf, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[10] <- "Period"

pf.2 <- rbind(pf.early,pf.late)

fp.3 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf.2, aes(x=age, y=ncell, color = Shape,linetype = Period), size = 1) +
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  #scale_y_continuous(name = "Mean cell number", trans = "log10", labels = scales::scientific) + 
  scale_y_log10(name = "Mean cell number",
                #breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  scale_color_manual(values=cbPalette[c(2,4,7)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(linetype="none", color = "none") + 
  theme(text = element_text(size=15),legend.position = c(.15,0.9)) 
#  + theme_bw()  # use a white background
print(fp.3)

fp.4 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf.2, aes(x=age, y=haz, color = Shape, linetype = Period), size = 1) +
  geom_point(data = cf.age, aes(x=mage, y=chaz, color = Shape, shape = pshp), size = 4) + 
  #geom_linerange(data = cf, aes(x = mage, y=chaz, ymax =chaz.hi, ymin = chaz.lo), size = .75) +
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  #scale_y_log10(name = "Mean cell number") + 
  scale_y_log10(name = bquote('Cancer hazard '(yr^-1)), limits = c(10^.5*1e-7,10^.5*1e-3),
                #breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  scale_color_manual(values=cbPalette[c(2,4,7)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  scale_shape_manual(values = c(21, 16)) +
  guides(linetype="none", shape="none") + 
  theme(text = element_text(size=15),legend.position = c(.25,0.9)) 
#  + theme_bw()  # use a white background
print(fp.4)

library(cowplot)
plot_grid(fp.2,fp.4, nrow = 1)

pf.tot <- subset(pf.2, Shape == "sessile")
pf.tot$haz <- pf.2$haz[pf.2$Shape == "sessile"] + pf.2$haz[pf.2$Shape == "peduncular"] + pf.2$haz[pf.2$Shape == "flat"]
pf.tot$Shape <- "total"

pf.3 <- rbind(pf.2,pf.tot)

setwd(datdir)
load(file = "nu65fit-canag.Rdata")
cf <- subset(cf, Shape != "flat,2d")
#names(cf)[1] <- "Shape"
#names(cf)[2] <- "Sex"
cf$Sex[cf$Sex == "w"] <- "women"
cf$Sex[cf$Sex == "m"] <- "men"
cf$Sex <- fct_rev(cf$Sex)
cf$pshp <- "shp1"
cf$mage[cf$Shape == "flat"] <- cf$mage[cf$Shape == "flat"] - 1
cf$mage[cf$Shape == "peduncular"] <- cf$mage[cf$Shape == "peduncular"] + 1
cf

cf.tot <- subset(cf, Shape == "sessile")
#cf.tot$pyr <- cf$pyr[cf$Shape == "sessile"] + cf$pyr[cf$Shape == "flat"] + cf$pyr[cf$Shape == "peduncular"]
cf.tot$ncanc <- cf$ncanc[cf$Shape == "sessile"] + cf$ncanc[cf$Shape == "flat"] + cf$ncanc[cf$Shape == "peduncular"]
cf.tot$npat <- cf$npat[cf$Shape == "sessile"] + cf$npat[cf$Shape == "flat"] + cf$npat[cf$Shape == "peduncular"]
cf.tot$nad <- cf$nad[cf$Shape == "sessile"] + cf$nad[cf$Shape == "flat"] + cf$nad[cf$Shape == "peduncular"]
cf.tot$enad <- cf$enad[cf$Shape == "sessile"] + cf$enad[cf$Shape == "flat"] + cf$enad[cf$Shape == "peduncular"]
cf.tot$chaz <- cf.tot$ncanc/cf.tot$pyr
#cf.tot$chaz <- cf$chaz[cf$Shape == "sessile"] + cf$chaz[cf$Shape == "flat"] + cf$chaz[cf$Shape == "peduncular"]
cf.tot$chaz.lo <- qpois(0.025,cf.tot$ncanc)/cf.tot$pyr
cf.tot$chaz.hi <- qpois(0.975,cf.tot$ncanc)/cf.tot$pyr
cf.tot$Shape <- "total"

pf.3$Shape <- fct_relevel(pf.3$Shape,c("total","sessile","peduncular","flat"))

setwd(plotdir)
hazfac <- 1e4
fp.5 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf.3, aes(x=age, y=haz*hazfac, color = Shape, linetype = Period), size = 1) +
  geom_point(data = cf.tot, aes(x=mage, y=chaz*hazfac, color = Shape, shape = pshp), size = 4) + 
  geom_linerange(data = cf.tot, aes(x = mage, y=chaz*hazfac, ymax =chaz.hi*hazfac, ymin = chaz.lo*hazfac), size = .75) +
  facet_wrap(Sex ~ ., ncol = 1, scales = "free_y") + 
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  scale_y_continuous(name = "Cancer hazard in 10,000 persons per yr") + 
  #scale_y_log10(name = bquote('Cancer hazard '(yr^-1)), limits = c(10^.5*1e-7,10^.5*1e-4),
                #breaks = trans_breaks("log10", function(x) 10^x),
  #              labels = trans_format("log10", math_format(10^.x))) +
  #scale_color_manual(values=cbPalette[c(2,4,7)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  scale_color_manual(labels = c("all shapes","sessile","peduncular","flat"), values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  scale_shape_manual(values = c(21, 16)) +
  guides(linetype="none", shape="none") + 
  theme(text = element_text(size=15),legend.position = c(.15,0.8)) 
#  + theme_bw()  # use a white background
print(fp.5)

#x <- 1:4
#y <- c(0, 0.0001, 0.0002, 0.0003)
#dd <- data.frame(x, y)

#ggplot(dd, aes(x, y)) + geom_point() +
#  scale_y_log10("y",
#                breaks = trans_breaks("log10", function(x) 10^x),
#                labels = trans_format("log10", math_format(10^.x)))

