#----------------------------------------------
# adeno ADR analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-------------------------------------------
# directory structure
#-------------------------------------------

shp <- character()
shp <- "all"
#shp <- "flat"
#shp <- "sessile"
#shp <- "peduncular"

sexc <- character()
sexc <- "m"
#sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K0"
#mmname <- "K1app"
#mmname <- "K1"
mmname <- "K2"

# likelihood
likc <- character()
likc <- "permut"
#likc <- "dist"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

# model version
atr <- character()
atr <- "atrend" # age trend
#atr <- "std" # standard

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,atr,sep="-")

#-------------------------------------------------------------
# prepare observed data
#-------------------------------------------------------------
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG} 
  else if (shp == "sessile") {
    load(file = "sessPG-20210915.Rdata")
    df0 <- sess}
  else if (shp == "flat") {
    load(file = "flatPG-20210915.Rdata")
    df0 <- flat}
  else if (shp == "peduncular" & mdv == "grid") {
    load(file = "peduPG-20210915.Rdata")
    df0 <- pedu
    patdata <- "peduPG-20210915.Rdata"}
  else if (shp == "peduncular" & mdv == "pref") {
    load(file = "peduPG-20211103.Rdata")
    levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
    pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
    df0 <- pedu
    patdata <- "peduPG-20211103.Rdata"}
}

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ys <- df0$ys2d
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ys <- df0$ys3d
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}
#df0$yhi[df0$sizecat == ">2"] <- -1
df0$acen <- (df0$age-65)/10

{
  if (dims == "2d"){
    if (shp != "peduncular"){
      Size1cm <- 1/sqrt(800)
    }
    else {
      Size1cm <- 1/sqrt(200)
    }
    gdim <- 2
    Ninf <- max(df0$yhi2d)
  }
  else if (dims == "3d"){
    if (shp != "peduncular"){
      Size1cm <- 1/3200^(1/3) # 1 cm
    }
    else {
      Size1cm <- 1/400^(1/3)
    }
    gdim <- 3
    Ninf <- max(df0$yhi3d)
  }
}

# set detection limit boundaries for preferred models
{
  if (mdv == "pref"){
    if (shp == "sessile" | shp == "all") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "peduncular") {
      df0$ylo[df0$ylo == 50] <- 40
      df0$ymin[df0$ymin == 50] <- 40}  
  }
}

#summary(df0)
dim(df0)[1]
df0 <- droplevels(df0)

df <- df0

ad <- subset(df0, shape != "none")

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid" & atr =="atrend"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
  else if (mdv == "grid" & atr == "std"){thispardir <- gstdpardir}
}
#thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
{
  if (atr == "atrend"){
    source("pAdenoK0K1K2atrend-permut.R")
  }
  else if (atr == "std"){
    source("pAdenoK0K1K2std-distrib-size.R")
  }
}

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
      Esize <- ymeanK0
      Prev <- PrevK0
      pn_K <- pn_K0_ler
      }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
    Esize <- ymeanK1
    Prev <- PrevK1.app
    pn_K <- pn_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.sum
    Thelohi <- theta_lohi_K1.sum
    #Theloho <- pnlohi_K1.sum
    Esize <- EsizeK1.hyp
    Prev <- PrevK1
    pn_K <- pn_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.sum
    Thelohi <- theta_lohi_K2.sum
    Esize <- EsizeK2.sum
    Prev <- PrevK2
    pn_K <- pn_K2.sum
  }
  else
  {
    print("Not implemented\n")
  }
}

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
upar <- dpar$parval

#--------------------------------
# model predictions
#--------------------------------
#ages <- seq(20,80,1)
ages <- 65
delt <- 5
ages2 <- ages + delt
ninf <- Ninf # needed for denominator
ydim <- 1
ymin <- df$ymin[1]
rYeff <- 0.5
#ymin <- 100

eSize_y0 <- Esize(ages,upar,1,ymin,100*ninf)
eSize_y0_10 <- Esize(ages,upar,1,ymin,1000*ninf)
convrat <- (eSize_y0-eSize_y0_10)/eSize_y0_10
if (abs(convrat) > 1e-3){
  cat(sprintf("Convergence failure with ratio: %g\n", convrat))
  } else {
  cat(sprintf("Convergence failure test passed with ratio: %g\n", convrat))
  }

eSize_0 <- Esize(ages,upar,1,0,100*ninf)
eSize_0_2 <- Esize(ages2,upar,1,0,100*ninf)
DeSize_0 <- Esize(delt,upar,1,0,100*ninf)

# remaining cells per clone
eN_y0 <- ENad(ages,upar,ymin)
eN_0 <- ENad(ages,upar,0)
DeN_0 <- ENad(delt,upar,0)
eN_0_2 <- ENad(ages2,upar,0)

R_Y_0 <- (eSize_0-eN_y0/eN_0*eSize_y0)
R_Y_0

# remaining clones per colonoscopy
R_N_0  <- eN_0 - eN_y0
R_N_0

R_0 <- R_N_0*R_Y_0
R_0

E_0 <- eN_0*eSize_0
E_0

# ratio of remaining cells
RR <- R_0/E_0
RR

ADR <- 1-exp(-eN_y0)
ADR
eN_y0

PREV <- 1-exp(-eN_0)
PREV
eN_0

E_0_2 <- eSize_0_2*eN_0_2
DeCell_0 <- DeSize_0*DeN_0
DhCell <- (E_0_2 - DeCell_0)/E_0 

# screening effectivity factor
reffvec <- seq(0,1,0.01)
nreff <- length(reffvec)
RReff <- vector()
HReff <- vector()
ADReff <- vector()
APCeff <- vector()
HR2eff <- vector()
RR2eff <- vector()

for (i in 1:nreff){
  reff <- reffvec[i]
  
  # cell per clone
  R_Yeff_0 <- eSize_0-(reff*eN_y0/eN_0)*eSize_y0
  
  # reduced cells per clone
  R_Y2eff_0 <- eSize_0-(reff*eN_y0/eN_0)*rYeff*eSize_y0
  
  # reduced clones
  R_Neff_0 <- ENad(ages,upar,0) - reff*ENad(ages,upar,ymin)
  
  # cells
  R_eff_0 <- R_Yeff_0*R_Neff_0
  
  # reduced cells
  R2_eff_0 <- R_Y2eff_0*R_Neff_0

  # share of remaining cells
  RReff[i] <- R_eff_0/E_0
  
  HReff[i] <- (R_eff_0*DhCell + DeCell_0)/E_0_2
  
  HR2eff[i] <- (R2_eff_0*DhCell + DeCell_0)/E_0_2

  # effective ADR
  ADReff[i] <- 1-exp(-reff*eN_y0)
  
  #effective APC
  APCeff[i] <- reff*eN_y0
  
  # new formula for RReff
  RR2eff[i] <- (reff*eN_y0/eN_0 -1)*((reff*eN_y0/eN_0)*(rYeff*eSize_y0/eSize_0) -1)
}

headline <- c("Shape","Sex","rYeff","rNeff","ADReff", "APCeff", "RReff","RR2eff","HReff", "HR2eff","E_0","E_0_2")
af <- data.frame(shp, sexc, rYeff, reffvec, ADReff, APCeff, RReff, RR2eff, HReff, HR2eff, E_0, E_0_2)
names(af) <- headline
af
convrat

# plot file saving
ffname <- "HReff-a65-5yr-reffy_50p"
ffname <- paste(ffname,fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(curvdir)
save(af, file = fsavname)

