#----------------------------------------------
# adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-------------------------------------------
# directory structure
#-------------------------------------------

shp <- character()
#shp <- "all"
shp <- "flat"
#shp <- "sessile"
#shp <- "peduncular"

noad <- character()
noad <- "wN0"
#noad <- "noN0"

loca <- character()
loca <- "all"

sexc <- character()
sexc <- "m"
#sexc <- "w"

dims <- character()
#dims <- "2d"
dims <- "3d"

mmname <- character()
#mmname <- "K0"
#mmname <- "K1app"
#mmname <- "K1"
mmname <- "K2"

# likelihood
likc <- character()
#likc <- "sing"
#likc <- "unif"
likc <- "dist"
#likc <- "bina"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,"-atrend",sep="") # age trend version

#-------------------------------------------------------------
# prepare observed data
#-------------------------------------------------------------
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20210915.Rdata")
    df0 <- sadenoPG} 
  else if (shp == "sessile") {
    load(file = "sessPG-20210915.Rdata")
    df0 <- sess}
  else if (shp == "flat") {
    load(file = "flatPG-20210915.Rdata")
    df0 <- flat}
  else if (shp == "peduncular" & mdv == "grid") {
    load(file = "peduPG-20210915.Rdata")
    df0 <- pedu
    patdata <- "peduPG-20210915.Rdata"}
  else if (shp == "peduncular" & mdv == "pref") {
    load(file = "peduPG-20211103.Rdata")
    levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
    pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
    df0 <- pedu
    patdata <- "peduPG-20211103.Rdata"}
}

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  # location
  if (loca == "distboth") {
    df0 <- subset(df0, loca == "distboth" | loca == "none")} 
  else if (loca == "proximal") {
    df0 <- subset(df0, loca == "proximal" | loca == "none")}
  
  if (dims == "2d") {
    df0$ys <- df0$ys2d
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ys <- df0$ys3d
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}
df0$yhi[df0$sizecat == ">2"] <- -1
#df0$acen <- (df0$age-65)/10

{
  if (dims == "2d"){
    if (shp != "peduncular"){
      Size1cm <- 1/sqrt(800)
    }
    else {
      Size1cm <- 1/sqrt(200)
    }
    gdim <- 2
    Ninf <- max(df0$yhi2d)
  }
  else if (dims == "3d"){
    if (shp != "peduncular"){
      Size1cm <- 1/3200^(1/3) # 1 cm
    }
    else {
      Size1cm <- 1/400^(1/3)
    }
    gdim <- 3
    Ninf <- max(df0$yhi3d)
  }
}

# set detection limit boundaries for preferred models
{
  if (mdv == "pref"){
    if (shp == "sessile") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "peduncular") {
      df0$ylo[df0$ylo == 50] <- 40
      df0$ymin[df0$ymin == 50] <- 40}  
  }
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
df0 <- droplevels(df0)

ad <- subset(df0, shape != "none")

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-distrib-size.R")

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
      Esize <- ymeanK0
      Pext <- PextK0
      Pint <- PintK0
      Prev <- PrevK0
      }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
    Esize <- ymeanK1
    Pext <- PextK1.app # needs rho!
    Pint <- PyminK1.app # needs rho!
    Prev <- PrevK1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.sum
    Thelohi <- theta_lohi_K1.sum
    #Theloho <- pnlohi_K1.sum
    Esize <- EsizeK1.sum
    Pext <- PextK1
    Pint <- PyminK1
    Prev <- PrevK1
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.sum
    Thelohi <- theta_lohi_K2.sum
    Esize <- EsizeK2.sum
    Pext <- PextK2
    Pint <- PyminK2
    Prev <- PrevK2
  }
  else
  {
    print("Not implemented\n")
  }
  
  if (likc == "bina"){
    Padeno <- Padeno_bin
  }
  else{
    Padeno <- Padeno_N
  }
}

#-------------------------------------------------------
# service functions for determination of percentiles
#-------------------------------------------------------
yperc <- function(ysize,ageref,upar,ymin,perc)
{
  lbd <- ENad(ageref,upar,ymin) 
  cumP <- Thelohi(ageref,upar,ymin,ysize)/lbd
  return(perc - cumP)
}

# median
ymedian <- function(age,upar,ymin,ymax)
{
  perc <- 0.5 # median
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = TRUE)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

# 2.5%-tile
y025 <- function(age,upar,ymin,ymax)
{
  perc <- 0.025 # 2.5%
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = TRUE)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

# 97.5%-tile
y975 <- function(age,upar,ymin,ymax)
{
  perc <- 0.975 # 97.5%
  ndim <- length(age)
  ymed <- vector()
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = TRUE)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

y25 <- function(age,upar,ymin,ymax)
{
  perc <- 0.25 # 25%
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = TRUE)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

# 97.5%-tile
y75 <- function(age,upar,ymin,ymax)
{
  perc <- 0.75 # 75%
  ndim <- length(age)
  ymed <- vector()
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = TRUE)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
upar <- dpar$parval

#--------------------------------
# model predictions
#--------------------------------
#ages <- seq(20,80,1)
ages <- 60
#ndim <- length(ages)
#delt <- 10
delt <- seq(0.2,20,0.2)
ndim <- length(delt)

#PyminK1(ages,delt,upar,gb.ymin)
p0 <- exp(-ENad(ages,upar,gb.ymin))
p1 <- unlist(lapply(1:ndim, function(i) exp(-ENad(ages+delt[i],upar,gb.ymin)) ))

p00 <- p0*p1
p01 <- p0*(1-p1)
p10 <- (1-p0)*p1
p11 <- (1-p0)*(1-p1)
p00+p01+p10+p11
#-----------------------------------------
# build plot frame
#-----------------------------------------
{
  if (sexc == "w") {sexcc = "women"}
  else if (sexc == "m") {sexcc = "men"}
}

# Mode
mde <- character()
#mde <- "md"
mde <- "a60"

headline <- c("Shape","Sex","Dim","Mode","out","age","delt","pint")
pif.00 <- data.frame(shp,sexcc,gdim,mde,"00",ages,delt,p00)
names(pif.00) <- headline
pif.01 <- data.frame(shp,sexcc,gdim,mde,"01",ages,delt,p01)
names(pif.01) <- headline
pif.10 <- data.frame(shp,sexcc,gdim,mde,"10",ages,delt,p10)
names(pif.10) <- headline
pif.11 <- data.frame(shp,sexcc,gdim,mde,"11",ages,delt,p11)
names(pif.11) <- headline

pif <- rbind(pif.00,pif.01,pif.10,pif.11)
str(pif)

# plot file saving
ffname <- paste("pint",mde,sep = "-")
ffname <- paste(ffname,fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(statdir)
setwd("pext")
save(pif, file = fsavname)
