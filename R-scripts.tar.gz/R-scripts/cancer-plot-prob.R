#----------------------------------------------
# adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#--------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)
library(corrplot)
library(forcats)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#--------------------------------------------------------------------
# cancer probability
#--------------------------------------------------------------------
setwd(curvdir)
load("prob60_70-ts0p25yr-all-w-2d-K2-permut-atrend.Rdata")
a.w <- prf

load("prob60_70-ts0p25yr-all-m-2d-K2-permut-atrend.Rdata")
a.m <- prf

load("prob60_70-ts0p25yr-sessile-w-2d-K2-permut-atrend.Rdata")
s.w <- prf

load("prob60_70-ts0p25yr-sessile-m-2d-K2-permut-atrend.Rdata")
s.m <- prf

load("prob60_70-ts0p25yr-peduncular-w-2d-K2-permut-atrend.Rdata")
p.w <- prf

load("prob60_70-ts0p25yr-peduncular-m-2d-K2-permut-atrend.Rdata")
p.m <- prf

load("prob60_70-ts0p25yr-flat-w-2d-K2-permut-atrend.Rdata")
f.w <- prf

load("prob60_70-ts0p25yr-flat-m-2d-K2-permut-atrend.Rdata")
f.m <- prf

prb <- rbind(a.m,a.w,s.m,s.w,p.m,p.w,f.m,f.w)

#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------
pf <-  prb
pf <- subset(pf, Size != "0.25 cm")
pf <- subset(pf, Size != "2 cm")
#pf <- subset(pf, Size != "0.25 cm" | Shape != "peduncular")

pf$Sex[pf$Sex == "w"] <- "women"
pf$Sex[pf$Sex == "m"] <- "men"
pf$Shape <- fct_relevel(pf$Shape,c("all","sessile","peduncular","flat"))
pf$Shape <- fct_recode(pf$Shape, "all shapes" = "all")
pf$Sex <- fct_rev(pf$Sex)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)

legend_title = "Size (cm)"
fp.1 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= pCanc*100, x = age, color = Shape), size = 1.2) + 
  facet_grid (Sex ~ Size) +
  #scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,100), breaks = seq(0,100,20)) +
  scale_x_continuous(name = "Age (yr)", limits = c(60,70), breaks = seq(60,70,5)) +
  #scale_x_continuous(name = "Age (yr)", limits = c(55,75), breaks = seq(55,75,5)) +
  scale_y_continuous(name="Cancer probability (%)", limits = c(0,6), breaks = seq(0,6,1)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(legend_title, values = c("dotdash","solid","twodash","dotted")) +
  #guides(linetype = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.14,0.8)) 
print(fp.1)

fp.2 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= pCanc*100, x = age, color = Shape, linetype = Size), size = 1.2) + 
  facet_grid (Sex ~ .) +
  #scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,100), breaks = seq(0,100,20)) +
  scale_x_continuous(name = "Age (yr)", limits = c(60,70), breaks = seq(60,70,5)) +
  #scale_y_continuous(name="Cancer probability (%)", limits = c(0,2.5), breaks = seq(0,3,.5)) +
  scale_y_log10(name="Cancer probability (%)") +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(legend_title, values = c("dotted","twodash","solid","dotted")) +
  guides(linetype = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.15,0.5)) 
print(fp.2)

