#----------------------------------------------
# plot age/byr dependence of parameter
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(gridExtra)
library(geomtextpath)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-----------------------------------------------------
# read parameter dependences with uncertainties
#------------------------------------------------------
setwd(curvdir)

load(file = "pardep-XP-gam-all-w-K2-2d.Rdata")
a.w <- pardf

load(file = "pardep-XP-gam-all-m-K2-2d.Rdata")
a.m <- pardf

load(file = "pardep-XP-gam-sessile-w-K2-2d.Rdata")
s.w <- pardf

load(file = "pardep-XP-gam-sessile-m-K2-2d.Rdata")
s.m <- pardf

load(file = "pardep-XP-gam-peduncular-w-K2-2d.Rdata")
p.w <- pardf

load(file = "pardep-XP-gam-peduncular-m-K2-2d.Rdata")
p.m <- pardf

load(file = "pardep-XP-gam-flat-w-K2-3d.Rdata")
pardf$Shape[pardf$Shape == "flat"] <- "flat,3d"
f.w.3d <- pardf

load(file = "pardep-XP-gam-flat-m-K2-3d.Rdata")
pardf$Shape[pardf$Shape == "flat"] <- "flat,3d"
f.m.3d <- pardf

load(file = "pardep-XP-gam-flat-w-K2-2d.Rdata")
pardf$Shape[pardf$Shape == "flat"] <- "flat,2d"
f.w.2d <- pardf

load(file = "pardep-XP-gam-flat-m-K2-2d.Rdata")
pardf$Shape[pardf$Shape == "flat"] <- "flat,2d"
f.m.2d <- pardf

#--------------------------------------
# start plotting
#--------------------------------------
setwd(plotdir)

# root plot file
pf <- rbind(a.w,a.m,s.w,s.m,p.w,p.m,f.w.3d,f.m.3d,f.w.2d,f.m.2d)

pf$Shape[pf$Shape == "all"] <- "all shapes"
pf$Sex[pf$Sex == "w"] <- "women"
pf$Sex[pf$Sex == "m"] <- "men"

pf$Shape <- fct_relevel(pf$Shape, "all shapes","sessile","peduncular","flat,2d","flat,3d")
pf$Sex <- fct_relevel(pf$Sex, "women","men")
pf$Par <- fct_relevel(pf$Par, "X0","gam")

pf.1 <- pf
dim(pf.1)
str(pf.1)
summary(pf.1)

#Par.labs <- c("X[P]","\u03b1, \u03b3") # subscript needed!!!
#names(Par.labs) <- c("X0", "gam")

#par_labeller <- as_labeller(c(X0="X[P]", gam="gamma"),
#                           default = label_parsed)

#https://stackoverflow.com/questions/37089052/r-ggplot2-facet-grid-how-include-math-expressions-in-few-not-all-labels
# read plotmath expressions with labeller = labeller(Par = label_parsed)
#levels(pf.1$Par)<- c("'control test'", "100~mu*g*'.L'^-1")
levels(pf.1$Par)<- c("'parameter X'[P]", "'parameters \u03b1, \u03b3'")

fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(aes(y=ncell, color = Shape, linetype = Sex), size = 1) +
  geom_line(data = pf.1, aes(x=byr, y=mle, color = Shape), size = 1) +
  #geom_ribbon(data = subset(pf.1, Shape == "all shapes"), aes(x=byr, ymin=lo, ymax=hi, group = Shape), linetype=0, alpha=0.1) +
  #geom_vline(xintercept = 1942, linetype = "dashed") + 
  #geom_text(data = pf.1, aes(x=1942, y=0.8, label = "1942"), angle = 90, vjust = -1) +
  #geom_textvline(data = pf.1, label = "1942", xintercept = 1942, vjust = -.5, linetype = 2) +
  #geom_text(aes(x=1942, y=0.8, label="1942",) angle=90, vjust = 1.2) +
  facet_grid(Sex ~ Par, labeller = labeller(Par = label_parsed)) +
  scale_x_continuous(name = "Birth year", limits = c(1917,1952), breaks = seq(1920,1950,10)) +
  #scale_y_log10(name = bquote('Hazard '(yr^-1)),
                #breaks = trans_breaks("log10", function(x) 10^x),
  #              labels = trans_format("log10", math_format(10^.x))) +
  scale_y_continuous(name="Normalized parameter values (at birth year 1942)", limits=c(0.3,1.3), breaks = seq(0.4,1.2,0.2)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2,3)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.7,0.53)) 
#  + theme_bw()  # use a white background
print(fp.1)

fp.2 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(aes(y=ncell, color = Shape, linetype = Sex), size = 1) +
  geom_line(data = pf.1, aes(x=age, y=mle, color = Shape), size = 1) +
  #geom_ribbon(data = subset(pf.1, Shape == "all shapes"), aes(x=byr, ymin=lo, ymax=hi, group = Shape), linetype=0, alpha=0.1) +
  #geom_vline(xintercept = 1942, linetype = "dashed") + 
  #geom_text(data = pf.1, aes(x=1942, y=0.8, label = "1942"), angle = 90, vjust = -1) +
  #geom_textvline(data = pf.1, label = "1942", xintercept = 1942, vjust = -.5, linetype = 2) +
  #geom_text(aes(x=1942, y=0.8, label="1942",) angle=90, vjust = 1.2) +
  facet_grid(Sex ~ Par, labeller = labeller(Par = label_parsed)) +
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(60,90,10), 
                     sec.axis = sec_axis(~. -2007, name = "Birth year", 
                                         labels = c("1950","1940","1930","1920"), breaks = seq(-1950,-1920,10))) +
  #scale_y_log10(name = bquote('Hazard '(yr^-1)),
  #breaks = trans_breaks("log10", function(x) 10^x),
  #              labels = trans_format("log10", math_format(10^.x))) +
  scale_y_continuous(name="Normalized parameter values (at age 65)", limits=c(0.3,1.3), breaks = seq(0.4,1.2,0.2)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2,3)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.7,0.55)) 
#  + theme_bw()  # use a white background
print(fp.2)

