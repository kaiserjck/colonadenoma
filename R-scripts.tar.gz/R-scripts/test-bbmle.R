#
# Person year table for thyroid cancer incidence
# RERF, July 2016
# preferred TSCE model, November 2016, jck
#
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)

#------------------------------------------------------------------------------
# directory structure
#------------------------------------------------------------------------------
#dir <- "~/gsf/imodel/mechthyr"
dir <- "~/imodel/mechthyr"
statdir<- paste(dir, "/stats", sep = "")
datadir <- paste(dir, "/rerfdata", sep = "")

#------------------------------------------------------------------------------#
# Data 
#------------------------------------------------------------------------------#
# read data

setwd (datadir)
load(file = "LSSUkrAm-1958_2005.RData")
sum(dat$papcar) # 292
dat$e10 <- (dat$agex-10)/10

#---------------------------------------------------------------
# mechanistic model
#---------------------------------------------------------------
# run subscripts
setwd(statdir)
source("./subscripts/fage.R")

tscecases <- function(X_mf, g_m, g_f, d_mf, xd, ps, ahs, b0, slp, ecen) 
{ 
  age <- dat$age
  agex <- dat$agex
  
  X <- exp(X_mf)
  
  gamma <- ((1-dat$isex)*g_m + dat$isex*g_f)
  
#  d_f <- exp(d_f)
#  d_m <- exp(d_m)
#  d <- ((1-dat$isex)*d_m + dat$isex*d_f)
  d <- exp (d_mf)
  q <- 0.5*(sqrt(gamma^2+4*d)-gamma)
  
#  b0 <- (1-dat$isex)*b0_m + dat$isex*b0_f
  X <- X * exp(b0*dat$e10)
  
  haz0 <- X * (exp((gamma+2*q)*age)-1)/(gamma + q*(exp((gamma+2*q)*age)+1)) 
#  haz0 <- haz0 * exp(ahs*dat$iahs) # AHS correction for baseline only
    
  # radiation-induced 
#  delT <- 7/365
  X0  <- exp(-23.9638)
  
#  xd_m <- exp(xd_m)
#  xd_f <- exp(xd_f)
#  xd <- (1-dat$isex)*xd_m + dat$isex*xd_f
  
#  hazR <- X0*age + (xd*1e-4*dat$d10gy*fage(slp,ecen,agex)) # linear dose response
  hazR <- X0*age + (xd*1e-4*dat$d10gy)*exp(ps*dat$msex)
  hazR <- hazR*fage(slp,ecen,agex)
#  hazR <- X0*age + (xd*1e-4*dat$d10gy*exp(slp*(ecen-agex))) # linear dose response
  
  hazard <- haz0+hazR
  hazard <- hazard * exp(ahs*dat$iahs) # AHS increases total hazard
   
  return (dat$PYR * hazard)
}

pardir <- paste(statdir,"/parms",sep="")
setwd(pardir)
x <- read.csv ("tsce-iahstot-etanh-d_mf-msex.csv") # preferred mechanistic model
t2par <- x[,-1]
t2par <- as.numeric(t2par)

# Poisson deviance
-2*sum(dpois (dat$papcar, 
              tscecases (X_mf = t2par[1],
                         g_m = t2par[2], g_f = t2par[3], 
                         d_mf = t2par[4], xd = t2par[5], ps = t2par[6],
                         ahs = t2par[7], b0 = t2par[8],slp = t2par[9],ecen = t2par[10]), log = TRUE))

# using formula with mle2
mle.1 <- mle2(papcar ~ dpois (lambda = tscecases (X_mf, g_m, g_f, d_mf, xd, ps, ahs, b0, slp, ecen)), 
                 start=list(X_mf = t2par[1],
                            g_m = t2par[2], g_f = t2par[3], 
                            d_mf = t2par[4], xd = t2par[5], ps = t2par[6],
                            ahs = t2par[7], b0 = t2par[8],slp = t2par[9],ecen = t2par[10]), 
                 parameters=list(X_mf~1, g_m~1, g_f~1, d_mf~1, xd~1, ps~1, ahs~1, b0~1, slp~1, ecen~1),
#                 fixed=list(slp = t2par[9], ecen = t2par[10]), # ecen fitted but fixed here to stabilize the fit
                 data = dat)

summary(mle.1) # 3003.439 
AIC(mle.1) # 3003.439

#residual deviance
rn <- sum(dpois (dat$papcar, dat$papcar, log = TRUE))
-2*(logLik(mle.1) - rn)

# Pearson residuals
res <- residuals(mle.1,type="pearson")
# number of adjustable parameters
length(coef(mle.1,exclude.fixed=T))
#npar <- ICtab(mle.1)$df
df <- length(dat$age) - npar
# dispersion parameter
sum(res^2)/df

#---------------------------------------------------------------
# write model parameters to file
#---------------------------------------------------------------
pardir <- paste(statdir,"/parms",sep="")
parms <- data.frame (coef(mle.1))
names(parms)[c(1)] <- c("parval")

write.csv(parms, file = "tsce0.csv", quote = F)
capture.output(summary(mle.1), file = "tsce0.txt")

parms.red <- data.frame (coef(mle.1,exclude.fixed=T))
names(parms.red)[c(1)] <- c("parval")
write.csv(parms.red, file = "tsce0-red.csv", quote = F)

#------------------------------------------------------------------------------------------
# tsce with Hessian for double checking
#------------------------------------------------------------------------------------------

tsceHcases <- function (par)
{ 
  age <- dat$age
  agex <- dat$agex
  
  X <- exp(par[1])
  
  gamma <- ((1-dat$isex)*par[2] + dat$isex*par[3])
  
#  d_f <- exp(par[4])
#  d_m <- d_f
#  d_m <- exp(-20)
#  d <- ((1-dat$isex)*d_m + dat$isex*d_f)
  d <- exp(par[4])
  q <- 0.5*(sqrt(gamma^2+4*d)-gamma)
  
  haz0 <- X * (exp((gamma+2*q)*age)-1)/(gamma + q*(exp((gamma+2*q)*age)+1)) 
#  haz0 <- haz0 * exp(par[7]*dat$iahs) # AHS correction for baseline only

  haz0 <- haz0*exp(par[8]*dat$e10)
  
  # radiation-induced 
#  delT <- 7/365
  X0  <- exp(-23.9638)
  
#  xd_m <- exp(par[5])
#  xd_f <- exp(par[6])
#  xd <- (1-dat$isex)*xd_m + dat$isex*xd_f
#  hazR <- X0*age + (xd*X0*delT*dat$d10gy) # linear dose response, log transformed

#  xd <- (1-dat$isex)*par[5] + dat$isex*par[6]
  hazR <- X0*age + (par[5]*1e-4*dat$d10gy)*exp(par[6]*dat$msex)
#  hazR <- hazR*fage(par[9],par[10],agex)
  hazR <- hazR*fage(t2par[9],t2par[10],agex) # ecen fixed

 
  hazard <- haz0+hazR
  hazard <- hazard * exp(par[7]*dat$iahs) # AHS increases total hazard
  
  return (dat$PYR * hazard)
}

# -log(likelihood) 
tploglik <- function(par)
{
  return (-sum(dpois (dat$papcar, tsceHcases (par), log = TRUE)))
}

setwd(pardir)
x <- read.csv ("tsce0-red.csv")
tpar <- x[,-1]

# Poisson deviance
-2*sum(dpois (dat$papcar, tsceHcases (tpar), log = TRUE))

# model fit
tpmdl <- nlminb(start = tpar, objective = tploglik, lower = -Inf, upper = Inf)
tpar <- tpmdl$par

tpmdl$convergence
#tpmdl$iterations
#tpmdl$evaluations

# Poisson deviance from tpmdl
2*tpmdl$objective
# Poisson deviance, direct method
res <- -dpois (dat$papcar, tsceHcases (tpmdl$par), log = TRUE)
2*sum(res)
# residual deviance
rp <- -dpois (dat$papcar, dat$papcar, log = TRUE)
2*sum(res-rp)
# AIC
2*tpmdl$objective + 2*length(tpmdl$par)
# best estimates
tpmdl$par

# calculation of Wald-based stdev, p-values and CI 
# Hessian matrix
tpmdl_hessian <- hessian(func = tploglik, x = tpmdl$par)
is.positive.definite(tpmdl_hessian, tol=1e-8)

# stdev for parameters (Wald-based)
stdev <- sqrt(diag(ginv(tpmdl_hessian)))

# z-transformation (t-value)
zval <- tpmdl$par/stdev

# p-value
pval <- 2*pnorm(-abs(zval))

# parameter CI 
upper <- tpmdl$par + qnorm(.975)*stdev
lower <- tpmdl$par - qnorm(.975)*stdev

# plot table
sum_tbl <- cbind(tpmdl$par, stdev, zval, pval, lower, upper)
colnames(sum_tbl) <- c("Estimate", "Std. Error", "z value", "Pr(>|z|)", "95% CI: LB", "95% CI: UB")
print(sum_tbl,digits = 4)

#---------------------------------------------------------------
# write model parameters to file
#---------------------------------------------------------------
#setwd("~/riskanalysis/UNSCEAR/thyroid/mstats/parms")
#parms <- data.frame (tpmdl$par)
#names(parms)[c(1)] <- c("parval")

#write.csv(parms, file = "tsce-etanh-red.csv", quote = F)

#-----------------------------------------------------------------------------
# read data
#-----------------------------------------------------------------------------
library(forcats)
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
setwd(datdir)

load(file = "nu65fit-canag.Rdata")
cf <- subset(cf, Shape != "flat,2d")
#cf <- subset(cf, chaz > 0)
#names(cf)[1] <- "Shape"
#names(cf)[2] <- "Sex"
#cf$Sex[cf$Sex == "w"] <- "women"
#cf$Sex[cf$Sex == "m"] <- "men"
#cf$mage[cf$Shape == "flat"] <- cf$mage[cf$Shape == "flat"] - 1
#cf$mage[cf$Shape == "peduncular"] <- cf$mage[cf$Shape == "peduncular"] + 1
cf$Sex <- fct_rev(cf$Sex)
cf$pyr10k <- cf$pyr*1e-4
cf
#--------------------------------
# fitting simple descriptive models
#--------------------------------
af <- subset(cf, agecat != "total")
af$lage65 <- log(af$mage/65)
# Attention: parametric byr, cyr models are dangerous
desc.0 <- glm(ncanc ~ lage65 + Sex + Shape, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.0) # AIC: 180.15

#--------------------------------
# TSCE model
#--------------------------------
tsce0 <- function(X0, gam0, del0) 
{ 
  age <- ff$age
  pyr <- ff$pyr10k
  
  X <- exp(X0)
  gamma <- gam0
  d <- exp (del0)
  q <- 0.5*(sqrt(gamma^2+4*d)-gamma)
  
  haz0 <- X * (exp((gamma+2*q)*age)-1)/(gamma + q*(exp((gamma+2*q)*age)+1)) 
  
  return (pyr*haz0)
}
