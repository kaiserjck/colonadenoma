#----------------------------------------------
# plot adeno enad analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
#----------------------------------------
# Hazards from Corley NEJM 2014
#---------------------------------------
load(file = "HRunadj-dorley.Rdata")
df.dor
lin.1 <- glm(HRmn ~ ADReff, data = df.dor)
summary(lin.1)
df.new <- data.frame(1,seq(0,0.5,0.01))
names(df.new) <- c("HRmn","ADReff")
lin.1.pred <- predict(lin.1, newdata = df.new)
df.adj <- data.frame(df.new$ADReff,lin.1.pred/lin.1.pred[1])
names(df.adj) <- c("ADR","hr")

#------------------------------------------------------------
# Hazard ratios from models
#------------------------------------------------------------
# rNeff = 0.5
load(file="HReff-a65-5yr-flat-all-w-3d-K2-dist-atrend.Rdata")
f.w <- af

load(file="HReff-a65-5yr-flat-all-m-3d-K2-dist-atrend.Rdata")
f.m <- af

load(file="HReff-a65-5yr-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.w <- af

load(file="HReff-a65-5yr-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.m <- af

load(file="HReff-a65-5yr-peduncular-all-w-2d-K1-dist-atrend.Rdata")
p.w <- af

load(file="HReff-a65-5yr-peduncular-all-m-2d-K1-dist-atrend.Rdata")
p.m <- af

shp_flat <- f.w$Shape[1]

# build and adjust pf
pf <- rbind(f.w,f.m,s.w,s.m,p.w,p.m)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular",shp_flat))
pf <- droplevels(pf)
summary(pf)

# calculate total values
pf.tot <- pf
pf.tot <- subset(pf.tot, Shape == "sessile")
pf.tot <- droplevels(pf.tot)
levels(pf.tot$Shape)[levels(pf.tot$Shape)=="sessile"] <- "total"
str(pf.tot)
pf.tot$APCeff <- pf$APCeff[pf$Shape == "sessile"] + pf$APCeff[pf$Shape == shp_flat] + pf$APCeff[pf$Shape == "peduncular"]
#pf.tot$ADReff <- pf$ADReff[pf$Shape == "sessile"] + pf$ADReff[pf$Shape == shp_flat] + pf$ADReff[pf$Shape == "peduncular"]
pf.tot$ADReff <- 1-exp(-pf.tot$APCeff) # additive Poisson distribution

#tothaz_0 <- pf$E_0[pf$Shape == "sessile"]*pf$nu[pf$Shape == "sessile"] + 
#  pf$E_0[pf$Shape == shp_flat]*pf$nu[pf$Shape == shp_flat] + pf$E_0[pf$Shape == "peduncular"]*pf$nu[pf$Shape == "peduncular"]
#pf.tot$RReff <- (pf$RReff[pf$Shape == "sessile"]*pf$E_0[pf$Shape == "sessile"]*pf$nu[pf$Shape == "sessile"]
#                 + pf$RReff[pf$Shape == shp_flat]*pf$E_0[pf$Shape == shp_flat]*pf$nu[pf$Shape == shp_flat]
#                 + pf$RReff[pf$Shape == "peduncular"]*pf$E_0[pf$Shape == "peduncular"]*pf$nu[pf$Shape == "peduncular"])/tothaz_0
tothaz_0 <- pf$E_0[pf$Shape == "sessile"] + pf$E_0[pf$Shape == shp_flat] + pf$E_0[pf$Shape == "peduncular"]
pf.tot$RReff <- (pf$RReff[pf$Shape == "sessile"]*pf$E_0[pf$Shape == "sessile"]
                 + pf$RReff[pf$Shape == shp_flat]*pf$E_0[pf$Shape == shp_flat]
                 + pf$RReff[pf$Shape == "peduncular"]*pf$E_0[pf$Shape == "peduncular"])/tothaz_0
pf.tot$RR2eff <- (pf$RR2eff[pf$Shape == "sessile"]*pf$E_0[pf$Shape == "sessile"]
                 + pf$RR2eff[pf$Shape == shp_flat]*pf$E_0[pf$Shape == shp_flat]
                 + pf$RR2eff[pf$Shape == "peduncular"]*pf$E_0[pf$Shape == "peduncular"])/tothaz_0

tothaz_0_2 <- pf$E_0_2[pf$Shape == "sessile"]*pf$nu[pf$Shape == "sessile"] + 
  pf$E_0_2[pf$Shape == shp_flat]*pf$nu[pf$Shape == shp_flat] + pf$E_0_2[pf$Shape == "peduncular"]*pf$nu[pf$Shape == "peduncular"]
pf.tot$HReff <- (pf$HReff[pf$Shape == "sessile"]*pf$E_0_2[pf$Shape == "sessile"]*pf$nu[pf$Shape == "sessile"]
                 + pf$HReff[pf$Shape == shp_flat]*pf$E_0_2[pf$Shape == shp_flat]*pf$nu[pf$Shape == shp_flat]
                 + pf$HReff[pf$Shape == "peduncular"]*pf$E_0_2[pf$Shape == "peduncular"]*pf$nu[pf$Shape == "peduncular"])/tothaz_0_2
pf.tot$HR2eff <- (pf$HR2eff[pf$Shape == "sessile"]*pf$E_0_2[pf$Shape == "sessile"]*pf$nu[pf$Shape == "sessile"]
                 + pf$HR2eff[pf$Shape == shp_flat]*pf$E_0_2[pf$Shape == shp_flat]*pf$nu[pf$Shape == shp_flat]
                 + pf$HR2eff[pf$Shape == "peduncular"]*pf$E_0_2[pf$Shape == "peduncular"]*pf$nu[pf$Shape == "peduncular"])/tothaz_0_2


# save pf for 5yr
pf.1 <- pf.tot
#pf.1$HRref[pf.1$Sex == "m"]  <- 0.61174488158189
#pf.1$HRref[pf.1$Sex == "w"] <- 0.390549566755746
#pf.1$HRdor <- pf.1$HR2eff/pf.1$HRref
#pf.1$RRref[pf.1$Sex == "m"]  <- 0.580192587523072
#pf.1$RRref[pf.1$Sex == "w"] <- 0.349015524452001
#pf.1$RRdor <- pf.1$RR2eff/pf.1$RRref
#pf.1$delt <- "5yr"
#pf.1$rY <- "30%"

headline <- c("HRtype","hr","Shape","Sex","nu","rYeff","rNeff","ADR","APC")
pf.1.RR <- data.frame("RR",pf.1$RReff,pf.1$Shape, pf.1$Sex, pf.1$nu, 1, pf.1$rNeff, pf.1$ADReff, pf.1$APCeff)
names(pf.1.RR) <- headline
pf.1.HR <- data.frame("HR",pf.1$HReff, pf.1$Shape, pf.1$Sex, pf.1$nu, 1, pf.1$rNeff, pf.1$ADReff, pf.1$APCeff)
names(pf.1.HR) <- headline
pf.1.RRred <- data.frame("RR",pf.1$RR2eff, pf.1$Shape, pf.1$Sex, pf.1$nu, pf.1$rYeff, pf.1$rNef, pf.1$ADReff, pf.1$APCeff)
names(pf.1.RRred) <- headline
pf.1.HRred <- data.frame("HR",pf.1$HR2eff, pf.1$Shape, pf.1$Sex, pf.1$nu, pf.1$rYeff, pf.1$rNef, pf.1$ADReff, pf.1$APCeff)
names(pf.1.HRred) <- headline

#----------------------------------------------------------
# plotting
#----------------------------------------------------------
setwd(plotdir)
pf <- rbind(pf.1.HR,pf.1.HRred,pf.1.RR,pf.1.RRred)
str(pf)

legend_title <- "PMC"
fp.1 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= hr, x = ADR*100, linetype = as.character(rYeff), color = Sex), size = 1.2) + 
  geom_line(data = df.adj, aes(y= hr, x = ADR*100), size = 1.2) + 
  facet_grid (Sex ~ HRtype) +
  scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,50), breaks = seq(0,50,10)) +
  scale_y_continuous(name="Hazard ratio", limits = c(0,1), breaks = seq(0,1,0.2)) +
  scale_color_manual(labels= c("women", "men"), values=cbPalette[c(2,3)]) +
  #scale_linetype_manual(legend_title, values = c("dotdash", "solid"), labels = c("10 yr","5 yr")) +
  #geom_point(data = df.dor, aes(x = ADReff*100, y = HRdor), size = 4) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  #geom_linerange(data = df.dor, aes(x = ADReff*100, y = HRdor, ymin = HRlo, ymax = HRhi), size = 0.75) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  #guides(color = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.15,0.7)) 
print(fp.1)

#---------------------------------------------------
# Adjusting to ADR = 0.1656 (Corley NEJM 20214)
#---------------------------------------------------
x.l.w <- 53
x.h.w <- 54
#x.l.w <- 71
#x.h.w <- 72
x.l.m <- 133
x.h.m <- 134
#ADRp.w <- 0.2150
ADRp.w <- 0.1656
ADRp.m <- 0.1656

df.hazR <- pf.1.HR

# women
x.l <- x.l.w
x.h <- x.h.w
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.w <- m*ADRp.w+b
yp.w

# men
x.l <- x.l.m
x.h <- x.h.m
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.m <- m*ADRp.m+b
yp.m

df.hazR$hrCor <- 1
df.hazR$hrCor[df.hazR$Sex == "w"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.w
df.hazR$hrCor[df.hazR$Sex == "m"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.m

pf.1.HR <- df.hazR

df.hazR <- pf.1.RR

# women
x.l <- x.l.w
x.h <- x.h.w
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.w <- m*ADRp.w+b
yp.w

# men
x.l <- x.l.m
x.h <- x.h.m
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.m <- m*ADRp.m+b
yp.m

df.hazR$hrCor <- 1
df.hazR$hrCor[df.hazR$Sex == "w"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.w
df.hazR$hrCor[df.hazR$Sex == "m"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.m

pf.1.RR <- df.hazR

df.hazR <- pf.1.HRred

# women
x.l <- x.l.w
x.h <- x.h.w
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.w <- m*ADRp.w+b
yp.w

# men
x.l <- x.l.m
x.h <- x.h.m
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.m <- m*ADRp.m+b
yp.m

df.hazR$hrCor <- 1
df.hazR$hrCor[df.hazR$Sex == "w"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.w
df.hazR$hrCor[df.hazR$Sex == "m"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.m

pf.1.HRred <- df.hazR

df.hazR <- pf.1.RRred

# women
x.l <- x.l.w
x.h <- x.h.w
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.w <- m*ADRp.w+b
yp.w

# men
x.l <- x.l.m
x.h <- x.h.m
m <- (df.hazR$hr[x.h] - df.hazR$hr[x.l])/(df.hazR$ADR[x.h] - df.hazR$ADR[x.l])
b <- df.hazR$hr[x.l] - m*df.hazR$ADR[x.l]
yp.m <- m*ADRp.m+b
yp.m

df.hazR$hrCor <- 1
df.hazR$hrCor[df.hazR$Sex == "w"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.w
df.hazR$hrCor[df.hazR$Sex == "m"] <- df.hazR$hr[df.hazR$Sex == "w"]/yp.m

pf.1.RRred <- df.hazR

setwd(curvdir)
load(file = "HRadj-corley.Rdata")
df.cor <- subset(df.cor, Sex != "both")
df.cor$Sex <- fct_rev(df.cor$Sex)
#df.cor$HRmn[df.cor$Sex == "women"] <- df.cor$HRmn[df.cor$Sex == "women"]/1.07
#df.cor$HRlo[df.cor$Sex == "women"] <- df.cor$HRlo[df.cor$Sex == "women"]/1.07
#df.cor$HRhi[df.cor$Sex == "women"] <- df.cor$HRhi[df.cor$Sex == "women"]/1.07

setwd(plotdir)
pf <- rbind(pf.1.RR,pf.1.RRred)
#pf$Sex <- fct_rev(pf$Sex)
levels(pf$Sex)[levels(pf$Sex)=="w"] <- "women"
levels(pf$Sex)[levels(pf$Sex)=="m"] <- "men"
#pf$Sex <- as.character(pf$Sex)

legend_title <- expression(paste(r[Y]^eff))
#y_title <- expression(paste(RR[eff]))
#y_title <- bquote(RR[eff])
y_title <- expression('Hazard ratio HR'[eff])
fp.2 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= hrCor, x = ADR*100, linetype = as.character(rYeff*100), color = Sex), size = 1.2) + 
  #geom_point(data = df.dor, aes(y= HRmn, x = ADReff*100), size = 2) + 
  facet_grid (Sex ~ .) +
  scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,50), breaks = seq(0,50,10)) +
  scale_y_continuous(name=y_title, limits = c(0,2), breaks = seq(0,2,0.5)) +
  scale_color_manual(labels= c("women", "men"), values=cbPalette[c(2,3)]) +
  scale_linetype_manual(legend_title, values = c("dotdash", "solid"),labels = c("1", " 0.5")) +
  geom_point(data = df.cor, aes(x = ADR*100, y = HRmn), size = 4) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  geom_linerange(data = df.cor, aes(x = ADR*100, y = HRmn, ymin = HRlo, ymax = HRhi), size = 0.75) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(color = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.85,0.4)) 
print(fp.2)

#-----------------------------------------------------
# create df.dor, Dorley et al., NEJM, 2014, Table 2
#-----------------------------------------------------
#ADReff <- c(0.1656,0.2150,0.2570,0.3096,0.3886)
#CASdor <- c(186,144,139,167,76)
#HAZdor <- c(9.8,8.6,8.0,7.0,4.8)
#PYRdor <- c(189796,167442,173750,238571,158333)
#HRdor <- HAZdor/HAZdor[1]

#nsim <- 10000
#posdis <- list()
#for (i in 1:length(CASdor)){
#  posdis[[i]] <- rpois(nsim,CASdor[i])
#}

#HRdis <- list()
#for (i in 1:length(CASdor)){
#  HRdis[[i]] <- (posdis[[i]]/PYRdor[i])/(posdis[[1]]/PYRdor[1])
#}

#HRmn <- vector()
#HRlo <- vector()
#HRhi <- vector()
#for (i in 1:length(CASdor)){
#  HRmn[i] <- mean(HRdis[[i]])
#  HRlo[i] <- quantile(HRdis[[i]], probs = c(0.025,0.975))[1]
#  HRhi[i] <- quantile(HRdis[[i]], probs = c(0.025,0.975))[2]
#}

#df.dor <- data.frame(ADReff,CASdor,PYRdor,HAZdor,HRdor, HRmn, HRlo, HRhi)
#names(df.dor) <- c("ADReff","cases","PYR","haze4","HRdor","HRmn","HRlo","HRhi")
#df.dor

#setwd(curvdir)
#fname <- "HRunadj-dorley.Rdata"
#save(df.dor, file = fname)

#-----------------------------------------------------
# fit df.dor, Dorley et al., NEJM, 2014, Table 2
#-----------------------------------------------------
#pos.1 <- glm(cases ~ ADReff, data = df.dor, offset = log(PYR), family = poisson(link = "log"))
#summary(pos.1)
#predict(pos.1)
#lin.1 <- glm(HRmn ~ ADReff, data = df.dor)
#summary(lin.1)
#df.new <- data.frame(1,seq(0,0.5,0.01))
#names(df.new) <- c("HRmn","ADReff")
#lin.1.pred <- predict(lin.1, newdata = df.new)
#df.adj <- data.frame(df.new$ADReff,lin.1.pred/lin.1.pred[1])
#names(df.adj) <- c("ADR","hr")

#-----------------------------------------------------
# adjusted HRs, Dorley et al., NEJM, 2014, Table 2
#-----------------------------------------------------
#ADR <- c(0.1656,0.2150,0.2570,0.3096,0.3886)
#HRmn.m <- c(1,0.79,0.82,0.69,0.60)
#HRlo.m <- c(1,0.55,0.61,0.48,0.42)
#HRhi.m <- c(1,1.14,1.08,0.99,0.88)
#HRmn.w <- c(1,1.07,0.89,0.70,0.43)
#HRlo.w <- c(1,0.74,0.63,0.49,0.28)
#HRhi.w <- c(1,1.56,1.26,1.01,0.66)
#HRmn.b <- c(1,1.93,0.85,0.70,0.52)
#HRlo.b <- c(1,0.70,0.68,0.54,0.39)
#HRhi.b <- c(1,1.23,1.06,0.91,0.69)

#headline <- c("Sex","ADR","HRmn","HRlo","HRhi")
#df.w <- data.frame("women",ADR,HRmn.w,HRlo.w,HRhi.w)
#names(df.w) <- headline
#df.m <- data.frame("men",ADR,HRmn.m,HRlo.m,HRhi.m)
#names(df.m) <- headline
#df.b <- data.frame("both",ADR,HRmn.b,HRlo.b,HRhi.b)
#names(df.b) <- headline

#df.cor <- rbind(df.w,df.m,df.b)
#df.cor

#setwd(curvdir)
#fname <- "HRadj-corley.Rdata"
#save(df.cor, file = fname)

