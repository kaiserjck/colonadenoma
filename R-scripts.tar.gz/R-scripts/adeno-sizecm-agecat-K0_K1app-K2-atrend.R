#----------------------------------------------
# adeno OE analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
#shp <- "flat"
#shp <- "sessile"
shp <- "peduncular"

noad <- character()
#noad <- "wN0"
noad <- "noN0"

patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    df0$ymin <- 40
    df0$size[df0$sizecat == "<0.5"] <- exp((log(sqrt(40/200))+log(0.5))/2)
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}

sexc <- character()
#sexc <- "both"
#sexc <- "m"
sexc <- "w"

dims <- character()
#dims <- "2d"
dims <- "3d"

mmname <- character()
#mmname <- "K1"
mmname <- "K2"

meth <- character()
#meth <- "sum" # summation
meth <- "hyp" # hypergeometric function

# likelihood
likc <- character()
likc <- "posize"
#likc <- "dist"

mdv <- character()
mdv <- "atrend"
#mdv <- "std"

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,mdv,sep="-") 

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
#ymin <- unique(df$ylo[df$sizecat == "<0.5"])
#df$ymin <- ymin
df <- droplevels(df)

# calculate df$npat_age
ad <- df

#npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum, drop=FALSE)
npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum)
#npat_size_age <- aggregate(ad$npat, list(factor(ad$age),ad$sizecat), sum)
#npat_size_age$x[is.na(npat_size_age$x) == T] <- 0
age_sum <- aggregate(ad$npat*ad$age, list(ad$agecat,ad$sizecat), sum)
#age_sum <- aggregate(ad$npat*ad$age, list(factor(ad$age),ad$sizecat), sum)
age_mean <- age_sum$x/npat_size_age$x
ylo_uni <- aggregate(ad$ylo, list(ad$agecat,ad$sizecat), unique)
yhi_uni <- aggregate(ad$yhi, list(ad$agecat,ad$sizecat), unique)
ymin_uni <- aggregate(ad$ymin, list(ad$agecat,ad$sizecat), unique)
#ylo_uni <- aggregate(ad$ylo, list(factor(ad$age),ad$sizecat), unique)
#yhi_uni <- aggregate(ad$yhi, list(factor(ad$age),ad$sizecat), unique)
#ymin_uni <- aggregate(ad$ymin, list(factor(ad$age),ad$sizecat), unique)

size_sum <- aggregate(ad$npat*ad$size, list(ad$agecat,ad$sizecat), sum)
size_mean <- size_sum$x/npat_size_age$x

df.h <- data.frame(shp,sexc,dims,age_mean,(age_mean-65)/10,npat_size_age,size_mean,ylo_uni$x,yhi_uni$x,ymin_uni$x)

npat_age <- aggregate(ad$npat, list(ad$agecat), sum)
#npat_age <- aggregate(ad$npat, list(factor(ad$age)), sum)
help1 <- split(df.h, df.h$Group.1)
nlevels <- length(levels(df.h$Group.1))
for(i in 1:nlevels){
  help1[[i]]$npat_age <- npat_age$x[i]
}
df.r <- help1[[1]]
for (i in 2:nlevels){
  df.r <- rbind(df.r,help1[[i]])
}
#df.r <- data.frame(df.h)
dim(df.r)
names(df.r) <- c("shp","sex","dims","age","acen","agecat","sizecat","npat","size","ylo","yhi","ymin","npat_age")
aggregate(df.r$npat,list(df.r$agecat),sum)
unique(df.r$npat_age)
#df <- df.r

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(ad)[1]))
cat(sprintf("   All Npat: %d\n", sum(ad$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(ad$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------
# set pardir
{
  if (mdv == "atrend"){thispardir <- patrendpardir}
  else if (mdv == "std"){thispardir <- pstdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
dim(sigma)[1]
sigma[1,2] <- sigma[2,1]
if(dim(sigma)[1] == 3)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
}
if(dim(sigma)[1] == 4)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
}
if(dim(sigma)[1] == 5)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
  sigma[1,5] <- sigma[5,1]
  sigma[2,5] <- sigma[5,2]
  sigma[3,5] <- sigma[5,3]
  sigma[4,5] <- sigma[5,4]
}
cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov
#pr[1] <- log(pr[1])
if (all(1 == sign(eigen(sigma)$values)) == TRUE)
  #if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
#Z[,1] <- exp(Z[,1])
apply(Z,2,mean)
#apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
upar <- dpar$parval

if(mdv == "std"){
  npar <- length(upar)
  upar[npar+1] <- 0
  nvarpar <- dim(df.par)[2]
  df.par[,nvarpar+1] <- 0
}

df.par[1:10,]

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-posize.R")

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
{ # this bracket is needed!
  if (mmname == "K0")
  {
    ENad <- ENadK0
    Thelohi <- theta_lohi_K0_ler
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.hyp
    Thelohi <- theta_lohi_K2.hyp
  }
  else
  {
    print("Not implemented\n")
  }
}

#--------------------------------
# model predictions
#--------------------------------
# adenoma size
#--------------------------------
psz <- df.r
#df <- droplevels(df)

# model predictions
# expectation value
lbd <- ENad(psz$age,upar,gb.ymin) 

# probabilities
# model prediction for size category
pdim <- dim(psz)[1]
PScat <- unlist(lapply(1:pdim, function(i) Thelohi(psz$age[i],upar,psz$ylo[i],psz$yhi[i])/lbd[i]))

# model uncertainties
pdfPScat <- list()
for(i in 1:pdim)
{
  PScatsav <- unlist(lapply(1:10, function(j) 
    Thelohi(psz$age[i],as.numeric(df.par[j,]),psz$ylo[i],psz$yhi[i])/ENad(psz$age[i],as.numeric(df.par[j,]),gb.ymin)))
  pdfPScat[[i]] <- PScatsav
  cat(sprintf("Model uncertainty simulation: cell no. %2d completed\n", i))
}

PScat.mn <- unlist(lapply(pdfPScat,mean))
PScat.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfPScat[[i]], probs = 0.025))))
PScat.md <- unlist(lapply(pdfPScat,median))
PScat.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfPScat[[i]], probs = 0.975))))

#-----------------------------------------------
# count uncertainties
#-----------------------------------------------
MScat <- unlist(lapply(1:pdim, function(i) psz$npat[i]/psz$npat_age[i]))

# simulation
pdfNpat <- list()
for(i in 1:pdim)
{
  Npatsav <- rpois(nsim,psz$npat[i])
  pdfNpat[[i]] <- Npatsav
}
pdfNpatCat <- list()
nage <- length(levels(psz$agecat))
nsize <- length(levels(psz$sizecat))
#for(i in 1:(nage-1))
for(i in 1:nage)
{
  j <- (i-1)*(nsize-1)
  k <- i+j
  cat(sprintf("nage: %g, k: %g\n", i, k))
  pdfNpatCat[[i]] <- pdfNpat[[k]] + pdfNpat[[k+1]] + pdfNpat[[k+2]] + pdfNpat[[k+3]]
}
#pdfNpatCat[[7]] <- pdfNpat[[25]] + pdfNpat[[26]] + pdfNpat[[27]]

pdfMScat <- list()
for(i in 1:pdim){
  j <- as.integer((i-1)/nsize)+1
  cat(sprintf("pdim: %g, agecat: %g\n", i, j))
  pdfMScat[[i]] <- pdfNpat[[i]]/pdfNpatCat[[j]]
}

#MScat.mn <- unlist(lapply(pdfMScat,mean))
#MScat.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfMScat[[i]], probs = 0.025))))
#MScat.md <- unlist(lapply(pdfMScat,median))
#MScat.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfMScat[[i]], probs = 0.975))))

size <- psz$size[1:nsize]
pdfsSize <- list()
#j = 1
#for(i in seq(1,pdim,nsize))
#{
#  pdfsSize[[j]] <- size[1]*pdfMScat[[i]] +  size[2]*pdfMScat[[i+1]] +  size[3]*pdfMScat[[i+2]] +  size[4]*pdfMScat[[i+3]]
#  j <- j+1
#}
#for(i in 1:(nage-1))
for(i in 1:nage)
{
  j <- (i-1)*(nsize-1)
  k <- i+j
  cat(sprintf("nage: %g, k: %g\n", i, k))
  pdfsSize[[i]] <- size[1]*pdfMScat[[k]] +  size[2]*pdfMScat[[k+1]] +  size[3]*pdfMScat[[k+2]] +  size[4]*pdfMScat[[k+3]]
}
#pdfsSize[[7]] <- size[2]*pdfMScat[[25]] + size[3]*pdfMScat[[26]] + size[4]*pdfMScat[[27]]

sizecm.lo <- as.numeric(unlist(lapply(1:nage,function (i) quantile(pdfsSize[[i]], probs = 0.025))))
sizecm.md <- unlist(lapply(pdfsSize,median))
sizecm.hi <- as.numeric(unlist(lapply(1:nage,function (i) quantile(pdfsSize[[i]], probs = 0.975))))

# check for completeness
aggregate(MScat, list(psz$agecat), sum)
aggregate(PScat, list(psz$agecat), sum)

# compare size in categories
sizecm.S <- aggregate(MScat*psz$size,list(psz$agecat),sum)
sizecm.MS <- aggregate(PScat*psz$size,list(psz$agecat),sum)

agem <- aggregate(psz$age,list(psz$agecat),mean)$x
ndim <- length(agem)
#Size1cm * unlist(lapply (1:ndim, function(i) EsizeK2.sum(agem[i],upar,gdim,gb.ymin,-1)))
#sizecm.M <- Size1cm * unlist(lapply (1:ndim, function(i) EsizeK2.sum(agem[i],upar,gdim,gb.ymin,100*Ninf)))

headline <- c("Shape","Sex","Source","agecat","age","sizecm","sizecm.lo","sizecm.hi")
sf.S <- data.frame(shp,sexc,"S",sizecm.S$Group.1,agem,sizecm.S$x,sizecm.lo,sizecm.hi)
names(sf.S) <- headline

sf.MS <- data.frame(shp,sexc,"MS",sizecm.MS$Group.1,agem,sizecm.MS$x,0,0)
names(sf.MS) <- headline

scf <- rbind(sf.S,sf.MS)
head(scf)

fname
ffname <- paste("esize-agecat",fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(curvdir)
save(scf, file = fsavname)

