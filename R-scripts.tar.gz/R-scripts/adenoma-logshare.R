# adjust adenoma data set for polypcount
# JCK, 2018/06/08

setwd("~/imodel/2018colonlmu/data_lmu/adenoma/")
load("adenoJCK.RData")
adeno <- adenoJCK

names(adeno)
#[1] "patid"            "sex"              "byr"              "byrcat"           "age"             
#[6] "agecat"           "EXAMINATIONDATE"  "QUARTAL"          "DIAGNOSECOLONCA"  "DIAGNOSEREKTUMCA"
#[11] "histkarzinom"     "PATIENTRISIKOFAM" "PATIENTRISIKOHER" "adenomhist"       "polypcount"      
#[16] "polypsize"        "polypshape"       "lok"              "adv_adenoma"      "adv_npl"  

adeno <- adeno[complete.cases(adeno[ , c(2,5,15,16,17,18)]),] 
dim(adeno) # 51843    20

prodi <- subset(adeno, lok == "distal" | lok == "proximal")

df <- adeno
ndim <- nrow(df)

#df.expanded <- df[rep(row.names(df), df$freq), 1:ncol(df)]
#dim(df.expanded)
#summary(df.expanded)

df$psizecat <- 99
df$psizecat[df$polypsize <= 0.5] <- 1
df$psizecat[df$polypsize > 0.5] <- 2
df$psizecat[df$polypsize > 1] <- 3
df$psizecat[df$polypsize > 2] <- 4
df$psizecat <- factor(df$psizecat, levels = c(1,2,3,4), labels = c("<0.5cm","0.5-1cm","1-2cm",">2cm"))

aggregate(df$agecat, list(df$agecat), length)
aggregate(df$agecat[df$psizecat == "<0.5cm"], list(df$agecat[df$psizecat == "<0.5cm"]), length)

str(df)

tbl <- table(df$psizecat[df$polypshape=="flat"],df$agecat[df$polypshape=="flat"])
p.flat <- prop.table(tbl, margin=2)
round(p.flat,digits=2)
#        55-59 60-64 65-69 70-74 75-79 80-84  >84
#<0.5cm   0.40  0.35  0.34  0.35  0.32  0.25 0.22
#0.5-1cm  0.35  0.39  0.36  0.35  0.34  0.37 0.24
#1-2cm    0.17  0.17  0.18  0.19  0.18  0.20 0.33
#>2cm     0.09  0.09  0.11  0.12  0.17  0.18 0.20

tbl <- table(df$psizecat[df$polypshape=="sessile"],df$agecat[df$polypshape=="sessile"])
p.sessile <- prop.table(tbl, margin=2)
round(p.sessile,digits=2)
#       55-59 60-64 65-69 70-74 75-79 80-84  >84
#<0.5cm   0.58  0.56  0.54  0.53  0.51  0.50 0.46
#0.5-1cm  0.32  0.33  0.33  0.33  0.34  0.33 0.34
#1-2cm    0.08  0.09  0.09  0.10  0.11  0.13 0.13
#>2cm     0.02  0.03  0.03  0.04  0.05  0.05 0.07

tbl <- table(df$psizecat[df$polypshape=="peduncular"],df$agecat[df$polypshape=="peduncular"])
p.peduncular <- prop.table(tbl, margin=2)
round(p.peduncular,digits=2)
#        55-59 60-64 65-69 70-74 75-79 80-84  >84
#<0.5cm   0.03  0.04  0.03  0.04  0.04  0.05 0.00
#0.5-1cm  0.46  0.44  0.45  0.43  0.43  0.44 0.47
#1-2cm    0.37  0.39  0.37  0.37  0.39  0.39 0.41
#>2cm     0.13  0.13  0.15  0.15  0.13  0.12 0.12

#df$psizecat <- factor(df$psizecat, levels=rev(levels(df$psizecat)))
flat <- subset(df, polypshape == "flat")
sessile <- subset(df, polypshape == "sessile")
peduncular <- subset(df, polypshape == "peduncular")

table(sessile$agecat)
table(flat$agecat)
table(peduncular$agecat)
table(sessile$psizecat,sessile$lok)
table(flat$psizecat,flat$lok)
table(peduncular$psizecat)

aggregate(flat$agecat, list(flat$agecat), length)
aggregate(flat$agecat[flat$psizecat == "<0.5cm"], list(flat$agecat[flat$psizecat == "<0.5cm"]), length)
#--------------------------------------------------
# prepare plot frame
#--------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[2],cbPalette[3],cbPalette[4],cbPalette[5])

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

#----------------------------------------------
# call ggplot2
#----------------------------------------------
library(ggplot2)
library(scales)

gp.1 <- ggplot(data=peduncular, aes(psizecat)) +
        ggtitle("Peduncular adenoma (prox+dist)") + 
        geom_bar(aes(y = ..count.., fill=sex), width = 0.5) +
        facet_grid (agecat ~ .) +
        xlab("Adenoma size") + 
        ylab("Count") +
        theme(text = element_text(size=15)) 
print(gp.1)

#setwd("~/imodel/colonlmu/stats/plots")
#ggsave("logshare_prodi-peduncular.png")

gp.2 <- ggplot(data=sessile, aes(y= ..count.., x = agecat, fill=psizecat)) +
  geom_bar(position = "dodge", width = 0.75) + 
#  facet_grid (sex ~ .) +
#  scale_y_continuous(labels = percent) +
  theme(text = element_text(size=15)) 
print(gp.2)

gp.3 <- ggplot(data=sessile, aes(y= ..count../sum(..count..), x = agecat, fill=psizecat)) +
  geom_bar(position = "fill", width = 0.75) + 
  facet_grid (sex ~ .) +
  xlab("Adenoma size") + 
  ylab("Percent") +
  scale_y_continuous(labels = percent) +
  theme(text = element_text(size=15)) 
print(gp.3)

gp.4 <- ggplot(data=sessile, aes(y= ..count../sum(..count..), x = agecat, fill=psizecat)) +
  ggtitle("Sessile adenoma (prox+dist)") + 
  geom_bar(position = "fill", width = 0.75) + 
  facet_grid (sex ~ .) +
  xlab("Age group") + 
  ylab("Percent") +
  scale_y_continuous(labels = percent) +
  scale_fill_manual(values=cbPalette[c(1:3,8)]) +
  theme(text = element_text(size=15)) 
print(gp.4)

# shape
ndim <- length(levels(df$agecat))
shp.f <- character(length = ndim)
shp.f[1:ndim] <- "flat"
shp.s <- character(length = ndim)
shp.s[1:ndim] <- "sessile"
shp.p <- character(length = ndim)
shp.p[1:ndim] <- "peduncular"

# size
size.0 <- character(length = ndim) 
size.0[1:ndim] <- levels(df$psizecat)[1]
size.1 <- character(length = ndim) 
size.1[1:ndim] <- levels(df$psizecat)[2]
size.2 <- character(length = ndim) 
size.2[1:ndim] <- levels(df$psizecat)[3]
size.3 <- character(length = ndim) 
size.3[1:ndim] <- levels(df$psizecat)[4]


headline <- c("Shape","Size","age","share")
f.0 <- data.frame(shp.f,size.0,levels(df$agecat),p.flat[1,])
colnames(f.0) <- headline
f.1 <- data.frame(shp.f,size.1,levels(df$agecat),p.flat[2,])
colnames(f.1) <- headline
f.2 <- data.frame(shp.f,size.2,levels(df$agecat),p.flat[3,])
colnames(f.2) <- headline
f.3 <- data.frame(shp.f,size.3,levels(df$agecat),p.flat[4,])
colnames(f.3) <- headline
f <- rbind(f.0,f.1,f.2,f.3)

s.0 <- data.frame(shp.s,size.0,levels(df$agecat),p.sessile[1,])
colnames(s.0) <- headline
s.1 <- data.frame(shp.s,size.1,levels(df$agecat),p.sessile[2,])
colnames(s.1) <- headline
s.2 <- data.frame(shp.s,size.2,levels(df$agecat),p.sessile[3,])
colnames(s.2) <- headline
s.3 <- data.frame(shp.s,size.3,levels(df$agecat),p.sessile[4,])
colnames(s.3) <- headline
s <- rbind(s.0,s.1,s.2,s.3)

p.0 <- data.frame(shp.p,size.0,levels(df$agecat),p.peduncular[1,])
colnames(p.0) <- headline
p.1 <- data.frame(shp.p,size.1,levels(df$agecat),p.peduncular[2,])
colnames(p.1) <- headline
p.2 <- data.frame(shp.p,size.2,levels(df$agecat),p.peduncular[3,])
colnames(p.2) <- headline
p.3 <- data.frame(shp.p,size.3,levels(df$agecat),p.peduncular[4,])
colnames(p.3) <- headline
p <- rbind(p.0,p.1,p.2,p.3)

pf <- rbind(s,f,p)
summary(pf)
head(pf)
levels(pf$age)
pf$age <- ordered(pf$age, levels = levels(df$agecat))
pf <- pf[pf$age != ">84",]

gp.2 <- ggplot(data=pf, aes(x = Size, y = share, fill = Shape)) +
#  ggtitle("Peduncular adenoma") + 
#  geom_point(size=3) +
  geom_bar(stat = 'identity', position = 'dodge') + 
  facet_grid (age ~ Shape) +
  xlab("Adenoma size") + 
  ylab("Percent") +
  scale_fill_manual(values=cbPalette[c(2:3,8)]) +
  scale_y_continuous(labels = percent) +
  theme(text = element_text(size=15)) 
print(gp.2)

gp.5 <- ggplot(data=pf, aes(x = Size, y = share, fill = Shape)) +
  #  ggtitle("Peduncular adenoma") + 
  #  geom_point(size=3) +
  geom_bar(stat = 'identity', position = 'dodge') + 
  facet_grid (age ~ Shape) +
  xlab("Adenoma size") + 
  ylab("Percent") +
  scale_fill_manual(values=cbPalette[c(2:3,8)]) +
  scale_y_continuous(labels = percent) +
  geom_text(aes(y = share + .1,    # nudge above top of bar
                label = sprintf("%0.2f", round(share, digits = 2))),    # prettify
            position = position_dodge(width = .9), 
            size = 3) + 
  theme(text = element_text(size=15)) 
print(gp.5)

gp.5 <- ggplot(data=pf, aes(x = Size, y = share, fill = Shape)) +
  ggtitle("Adenoma shape, age groups 55-59, 60-64, ... , > 84") + 
  #  geom_point(size=3) +
  geom_bar(stat = 'identity', position = 'dodge', show.legend=F) + 
#  geom_bar(stat = 'identity', position = 'dodge', show.legend=F) + 
  facet_grid (age ~ Shape) +
  xlab("Adenoma size") + 
  ylab("Share in age group") +
  scale_fill_manual(values=cbPalette[c(2:3,8)]) +
  scale_y_continuous(labels = percent) +
  geom_text(aes(y = share + .1,    # nudge above top of bar
                label = sprintf("%0.1f%%", round(share*100, digits = 2))),    # prettify
            position = position_dodge(width = .9), 
            size = 3) + 
  theme(text = element_text(size=12)) 
print(gp.5)

#setwd("~/imodel/colonlmu/stats/plots")
#ggsave("logshare_sessile_flat_peduncular.png")




