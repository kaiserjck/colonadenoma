#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="sizecat-sessile-w-2d-K2-posize-atrend.Rdata")
dim(scf)
scf$Sex[scf$Sex == "w"] <- "women"
scf$Mode[29:56] <- "S" # i forgot
pf.w <- scf

load(file="sizecat-sessile-m-2d-K2-posize-atrend.Rdata")
scf$Sex[scf$Sex == "m"] <- "men"
scf$Mode[29:56] <- "S" # i forgot
pf.m <- scf

# build and adjust pf
pf <- rbind(pf.w,pf.m)
pf$Mode <- fct_rev(pf$Mode)
#pf$Sex <- fct_rev(pf$Sex)
pf.S <- subset(pf, Mode == "S")
#pf <- droplevels(pf)
summary(pf)

fp.1 <- ggplot(data = pf, aes(x=sizecat, y=pmn*100, fill = Mode)) + 
  ggtitle("sessile") +
  geom_bar(stat="identity", position="dodge", width = 0.8) +
  geom_text(aes(x=sizecat, y=pmn*100, label = sprintf("%d", round(pmn*100, digits = 0))), 
            position=position_dodge(width = 0.8), vjust=-0.2) +
  #geom_text(aes(x = 3.9, y = 0.7, label = sprintf("N = %d", Npno))) +
  #geom_text(data = pf.S, aes(x = 2.9, y = 70, label = sprintf("Npat = %d", npat_age))) +
  geom_text(data = pf.S, aes(x = 3.8, y = 70, label = sprintf("Npat = %d", npat_age))) +
  #geom_errorbar(data = pf.S, aes(x=sizecat, ymin=plo*100, ymax=phi*100), 
  #              width=.2, position=position_dodge(width = 0.8)) +
  scale_fill_manual(values = myPalette) +
  xlab("Adenoma size (cm)") +
  facet_grid(agecat ~ Sex) + 
  #facet_grid(.~AgeGroup) + 
  #scale_x_discrete(limits = levels(pf$Size), breaks = levels(pf$Size)) +
  #scale_y_continuous(name="Share in age group", labels = scales::percent, limits=c(0,.9), breaks = seq(0,0.8,0.2)) +
  scale_y_continuous(name="Share in age group (%)", limits=c(0,90), breaks = seq(0,80,20)) +
  #  scale_color_manual(values=cbbPalette[3:5]) +
  guides(fill="none") + 
  theme(text = element_text(size=12)) 
#  + theme_bw()  # use a white background
print(fp.1)

