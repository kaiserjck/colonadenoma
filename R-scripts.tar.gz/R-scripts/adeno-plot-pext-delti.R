#----------------------------------------------
# plot extinction probability
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
library(cowplot)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(statdir)
setwd("pext")

load(file="pext-delti-1cm-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.delti.w <- pef
load(file="pext-delti-1cm-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.delti.m <- pef

load(file="pext-delti-1cm-flat-all-w-3d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 3d"
f.delti.3d.w <- pef
load(file="pext-delti-1cm-flat-all-m-3d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 3d"
f.delti.3d.m <- pef
load(file="pext-delti-1cm-flat-all-w-2d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 2d"
f.delti.2d.w <- pef
load(file="pext-delti-1cm-flat-all-m-2d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 2d"
f.delti.2d.m <- pef

load(file="pext-delti-1cm-peduncular-all-w-2d-K1-dist-atrend.Rdata")
p.delti.w <- pef
load(file="pext-delti-1cm-peduncular-all-m-2d-K1-dist-atrend.Rdata")
p.delti.m <- pef

# build and adjust pf
# age group data
pf <- rbind(s.delti.w,s.delti.m,f.delti.3d.w,f.delti.3d.m,f.delti.2d.w,f.delti.2d.m,p.delti.w,p.delti.m)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular","flat, 2d", "flat, 3d"))
pf <- droplevels(pf)
summary(pf)

setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = delt, y = (1-pext)*100, color = Shape), size = 1) + 
  facet_grid(. ~ Sex) +
  scale_x_continuous(name = "Waiting time (yr)", limits = c(0,10), breaks = seq(0,10,5)) +
  scale_y_continuous(name = "Survival probability (%)", limits = c(0,100), breaks = seq(0,100,25)) +
  scale_color_manual(values=cbPalette[c(4,7,3,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F, color = F) + 
  theme(text = element_text(size=12),legend.position = "top") 
print(fp.1)

fp.2 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = delt, y = halfN, color = Shape), size = 1) + 
  facet_grid(. ~ Sex) +
  scale_x_continuous(name = "Waiting time (yr)", limits = c(0,10), breaks = seq(0,10,5)) +
  scale_y_continuous(name = "Half-value of cells", trans = "log10") +
  scale_color_manual(values=cbPalette[c(4,7,3,2)]) +
  geom_hline(yintercept = 200, linetype = "dashed") + 
  #geom_text(aes(x=2, y=200, label = "200")) +
  annotate(geom="text", x=6, y=165, label=200) +
  annotate(geom="text", x=6, y=700, label=800) +
  annotate(geom="text", x=6, y=2700, label=3200) +
  geom_hline(yintercept = 800, linetype = "dashed") + 
  geom_hline(yintercept = 3200, linetype = "dashed") + 
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F) + 
  theme(text = element_text(size=12),legend.position = "top") + 
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + 
  theme(#plot.title = element_text(size = 12, face = "bold"),
    legend.title=element_text(size=10), 
    legend.text=element_text(size=9))
print(fp.2)

plot_grid(fp.2, fp.1, labels = "AUTO", ncol = 1)
 