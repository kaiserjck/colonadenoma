#----------------------------------------------
# adeno OE analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)
library(forcats)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-------------------------------------------
# directory structure
#-------------------------------------------

shp <- character()
#shp <- "all"
shp <- "flat"
#shp <- "sessile"
#shp <- "peduncular"

noad <- character()
noad <- "wN0"
#noad <- "noN0"

loca <- character()
loca <- "all"

sexc <- character()
sexc <- "m"
#sexc <- "w"

dims <- character()
#dims <- "2d"
dims <- "3d"

mmname <- character()
#mmname <- "K0"
#mmname <- "K1app"
mmname <- "K2"

# likelihood
likc <- character()
#likc <- "sing"
#likc <- "unif"
likc <- "dist"
#likc <- "bina"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,"-atrend",sep="") # age trend version

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
dim(sigma)[1]
sigma[1,2] <- sigma[2,1]
if(dim(sigma)[1] == 3)
{
 sigma[1,3] <- sigma[3,1]
 sigma[2,3] <- sigma[3,2]
}
if(dim(sigma)[1] == 4)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
}

cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov

if (all(1 == sign(eigen(sigma)$values)) == TRUE)
#if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
apply(Z,2,mean)
#apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

df.par[1:10,]

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-distrib.R")

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.hyp
    Thelohi <- theta_lohi_K2.hyp
  }
  else
  {
    print("Not implemented\n")
  }
  
  if (likc == "bina"){
    Padeno <- Padeno_bin
  }
  else{
    Padeno <- Padeno_N
    PadenoTop <- Padeno_Nmaxprob
  }
}

#--------------------------------
# model predictions
#--------------------------------
upar <- dpar$parval
#--------------------------------
# adenoma counts
#--------------------------------
RefAge <- 57 #reference age
#RefAge <- 67 #reference age
#RefAge <- 77 #reference age

tpar <- vector()
tpar <- upar
tf.par <- df.par
{
  if (mmname == "K1" | mmname == "K2") {
    tpar[1] <- upar[1]*exp(upar[5]*(RefAge-65)/10) # bx
    tpar[2] <- upar[2]*exp(upar[6]*(RefAge-65)/10) # ba
    tpar[3] <- upar[3]*exp(upar[6]*(RefAge-65)/10) # ba
    tpar[4] <- upar[4]/exp(upar[6]*(RefAge-65)/10) # ba
    tpar[5:7] <- 0
    
    for (j in 1:nsim)
    {
      tf.par[j,1] <- df.par[j,1]*exp(df.par[j,5]*(RefAge-65)/10) # bx
      tf.par[j,2] <- df.par[j,2]*exp(df.par[j,6]*(RefAge-65)/10) # ba
      tf.par[j,3] <- df.par[j,3]*exp(df.par[j,6]*(RefAge-65)/10) # ba
      tf.par[j,4] <- df.par[j,4]/exp(df.par[j,6]*(RefAge-65)/10) # ba
      tf.par[j,5:7] <- 0      
    }
  }
  else if (mmname == "K1app"){
    tpar[1] <- upar[1]*exp(upar[5]*(RefAge-65)/10)/exp(upar[6]*(RefAge-65)/10) # bx, ba
    tpar[2] <- upar[2]*exp(upar[6]*(RefAge-65)/10) # ba
    tpar[3] <- upar[3]*exp(upar[6]*(RefAge-65)/10) # ba    
    tpar[4:6] <- 0
    
    for (j in 1:nsim)
    {
      tf.par[j,1] <- df.par[j,1]*exp(df.par[j,5]*(RefAge-65)/10)/exp(df.par[j,6]*(RefAge-65)/10) # bx, ba
      tf.par[j,2] <- df.par[j,2]*exp(df.par[j,6]*(RefAge-65)/10) # ba
      tf.par[j,3] <- df.par[j,3]*exp(df.par[j,6]*(RefAge-65)/10) # ba
      tf.par[j,4:6] <- 0      
    }
  }
  else if (mmname == "K0"){
    tpar[1] <- upar[1]*exp(upar[5]*(RefAge-65)/10) # bx
    tpar[2] <- upar[2]*exp(upar[6]*(RefAge-65)/10) # ba
    tpar[3] <- upar[3]*exp(upar[6]*(RefAge-65)/10) # ba    
    tpar[4:6] <- 0
    
    for (j in 1:nsim)
    {
      tf.par[j,1] <- df.par[j,1]*exp(df.par[j,5]*(RefAge-65)/10) # bx
      tf.par[j,2] <- df.par[j,2]*exp(df.par[j,6]*(RefAge-65)/10) # ba
      tf.par[j,3] <- df.par[j,3]*exp(df.par[j,6]*(RefAge-65)/10) # ba
      tf.par[j,4:6] <- 0      
    }
  }
}

#------------------------------------------
# model predictions
#------------------------------------------
ages <- seq(0,100,1)

# expectation value
mNad <- ENad(ages,tpar,gb.ymin) 
# prevalence
mPrev <- 1-exp(-mNad)

pdfmNad <- list()
pdfmPrev <- list()
pdim <- length(mNad)
for(i in 1:pdim)
{
  mNadsav <- unlist(lapply(1:nsim, function(j) ENad(ages[i],as.numeric(tf.par[j,]),gb.ymin)))
  pdfmNad[[i]] <- mNadsav
  pdfmPrev[[i]] <- unlist(lapply(1:nsim, function(j) 1-exp(-mNadsav[j])))
  cat(sprintf("Model undercertainty simulation: cell no. %2d completed\n", i))
} 

#pcf <- data.frame(pcf,mNad)
mNad.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfmNad[[i]], probs = 0.025))))
mNad.md <- unlist(lapply(pdfmNad,median))
mNad.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfmNad[[i]], probs = 0.975))))

#pcf <- data.frame(pcf,mNcat)
mPrev.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfmPrev[[i]], probs = 0.025))))
mPrev.md <- unlist(lapply(pdfmPrev,median))
mPrev.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfmPrev[[i]], probs = 0.975))))

#-----------------------------------------
# build plot frame
#-----------------------------------------
{
  if (sexc == "w") {sexcc = "women"}
  else if (sexc == "m") {sexcc = "men"}
}
headline <- c("Shape","Sex","Age","ages","enad","enad.lo","eand.hi","prev","prev.lo","prev.hi")

ppf <- data.frame(shp,sexcc,RefAge,ages,mNad,mNad.lo,mNad.hi,mPrev,mPrev.lo,mPrev.hi)
names(ppf) <- headline

# plot file saving
fname
ffname <- paste("prev-refage",fname,sep = "-")
ffname <- paste(sprintf("%2d",RefAge),fname,sep = "")
fsavname <- paste(ffname,"Rdata", sep = ".")
setwd(curvdir)
save(ppf, file = fsavname)
