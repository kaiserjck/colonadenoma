#----------------------------------------------
# test K0 functions
# jck, 2021/08/25
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
# library for function "lerch"
library(VGAM)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(pardir)
#parDF <- read.csv ("temp/flat-noN0-all-m-3d-K1-std_parms.csv")

one_minus_azeta <- function (s1,alp, gam, age)
{
  dage <- age - s1
  
  bet <- alp-gam
  
  zaehler <- exp(gam*dage) - 1
  nenner <- alp*exp(gam*dage) - bet
  zet <- zaehler/nenner
  
  return (1-alp*zeta)
}


pn_zeta <- function(s1, alp, gam, n, age)
{
  dage <- age - s1
  
  bet <- alp-gam
  
  zaehler <- exp(gam*dage) - 1
  nenner <- alp*exp(gam*dage) - bet
  zet <- zaehler/nenner

  pn <- vector()  
  pn <- {ifelse(n == 0, bet*zet, (1-bet*zet)*(1-alp*zet)*(alp*zet)^(n-1))}
  
  return(pn)
}

pn_zeta2 <- function(s1, alp, gam, n, age)
{
  dage <- age - s1
  
  bet <- alp-gam
  
  zaehler <- exp(gam*dage) - 1
  nenner <- alp*exp(gam*dage) - bet
  zet <- zaehler/nenner
  
  pn <- (1-bet*zet)*(1-alp*zet)*(alp*zet)^(n-1)
  
  return(pn)
}

pn_g <- function(s1, alp, gam, n, age)
{
  dage <- s1 - age
  
  g <- exp(gam*dage)
  G <- alp/gam*(1-g)
  
  pn <- vector()  
  pn <- {ifelse(n == 0, 1-1/(g+G), 1/(g+G)*g/G*(G/(g+G))^n)}
  
  return(pn)
}

pn_g2 <- function(s1, alp, gam, n, age)
{
  dage <- s1 - age
  
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)*(gfunc/Gfunc)
  return(f2*(f1^n))
}

# summation over pn_g or pn_zeta
p0_gG <- function(s1, alp, gam, y0, age)
{
  dage <- s1 - age
  
  g <- exp(gam*dage)
  G <- alp/gam*(1-g)
  
  retarg <- 1/(g+G)*(G/(g+G))^y0
  return(retarg)
}

py_gG_sinteg <- function(alp, gam, y0, age)
{
  #py_age <- vector()
  #py_age <- unlist(lapply(1:ndim, 
  #                      function(i) 
  #                      {ifelse(y0 > 0, integrate(p0_gG, lower = 0, upper = age[i], alp, gam, y0, age = age[i])$value, 1)}))
  
  py_age <- integrate(p0_gG, lower = 0, upper = age, alp, gam, y0, age = age)$value
  return(py_age)
}

py_lerch <- function(alp, gam, y0, age)
{
  bet <- alp - gam
  
  zaehler <- exp(gam*age) - 1
  nenner <- alp*exp(gam*age) - bet
  zet <- zaehler/nenner
  
  az <- alp*zet
  retarg <- (az)^(1+y0)*lerch(az,1,1+y0)/alp
  return(retarg)
}

# difference of almost equal numbers
p_ys_lerch <- function(alp, gam, ys, age)
{
  bet <- alp - gam
  zaehler <- exp(gam*age) - 1
  nenner <- alp*exp(gam*age) - bet
  zet <- zaehler/nenner
  az <- alp*zet
  cat(sprintf("(lerch(az,1,ys)): %g, az*lerch(az,1,1+ys)): %g\n", lerch(az,1,ys), az*lerch(az,1,1+ys)))
  retarg <- az^(ys)*(lerch(az,1,ys)-az*lerch(az,1,1+ys))/alp
  return(retarg)
}

p_ys_sinteg <- function(alp, gam, ys, age)
{
  
  retarg <- integrate(pn_zeta2, lower = 0, upper = age, alp, gam, ys, age = age)$value
  return(retarg)
}

# difference of almost equal numbers
p_ylyh_lerch <- function(alp, gam, yl, yh, age)
{
  bet <- alp - gam
  zaehler <- exp(gam*age) - 1
  nenner <- alp*exp(gam*age) - bet
  zet <- zaehler/nenner
  az <- alp*zet
  
  arg1 <- az^(yl+1)*lerch(az,1,1+yl)
  
  arg2 <- 0
  if(yh > 0) {arg2 <- az^(yh+1)*lerch(az,1,1+yh)}
  
  retarg <- arg1 - arg2
  retarg <- retarg/alp
  
  return(retarg)
}

person_deviance_ylyh <- function(X0, alp, gam, ymin, yl, yh, pno, npat, age)
{
  enad <- -X0*py_lerch(alp, gam, y0, age)
  psize <- p_ylyh_lerch(alp, gam, yl, yh, age)
  
  cat(sprintf(" p_pat: %g\n", psize))
  cat(sprintf(" Devadno: %g\n", -2*npat*enad))
  cat(sprintf(" Devsize: %g\n", -2*npat*pno*(log(X0*psize))))
  
  lnlik <- pno*log(psize*X0) + enad
  return(-2*npat*lnlik)
}

person_deviance_ylyh_exact <- function(X0, alp, gam, ymin, yl, yh, pno, npat, age)
{
  enad <- -X0*py_lerch(alp, gam, y0, age)
  psize_yl <- p_ylyh_lerch(alp, gam, yl, yh, age)
  psize_y0 <- p_ylyh_lerch(alp, gam, y0, yh, age)
  
  lnj <- -1
  {
    if(pno == 0)
    {lnj <- 0}
    else if (pno == 1)
    {lnj <- log(X0*psize_yl)}
    else if (pno == 2)
    {lnj <- log(X0*psize_y0) + log(X0*psize_yl) - log(2)}
    else if (pno == 5)
    {lnj <- 4*log(X0*psize_y0) + log(X0*psize_yl) - log(120)}
  }
  
  cat(sprintf(" p_pat_yl: %g, p_pat_y0: %g, lnj: %g\n", psize_yl, psize_y0, lnj))
  cat(sprintf(" Devadno: %g\n", -2*npat*enad))
  cat(sprintf(" Devsize: %g\n", -2*npat*lnj))
  
  lnlik <- lnj + enad
  return(-2*npat*lnlik)
}

person_deviance_ylyh_factorial <- function(X0, alp, gam, ymin, yl, yh, pno, npat, age)
{
  enad <- -X0*py_lerch(alp, gam, y0, age)
  psize_yl <- p_ylyh_lerch(alp, gam, yl, yh, age)
  psize_y0 <- p_ylyh_lerch(alp, gam, y0, yh, age)
  
  n2_4 <- c(2:4)
  n0_4 <- c(0:4)
  
  lnj <- -1
  {
    if(pno == 0)
    {lnj <- 0}
    else if (pno == 1)
    {lnj <- log(X0*psize_yl)}
    else if (pno == 2)
    {lnj <- log(X0*psize_yl/psize_y0*(sum(psize_y0^n2_4/factorial(n2_4))))}
    else if (pno == 5)
    {lnj <- log(X0^5*psize_yl/psize_y0*(exp(psize_y0) - sum(psize_y0^n0_4/factorial(n0_4))))}
  }
  print(exp(psize_y0) - sum(psize_y0^n0_4/factorial(n0_4)))
  cat(sprintf(" p_pat_yl: %g, p_pat_y0: %g, lnj: %g\n", psize_yl, psize_y0, lnj))
  cat(sprintf(" Devadno: %g\n", -2*npat*enad))
  cat(sprintf(" Devsize: %g\n", -2*npat*lnj))
  
  lnlik <- lnj + enad
  return(-2*npat*lnlik)
}

person_deviance_ys <- function(X0, alp, gam, ymin, ys, pno, npat, age)
{
  enad <- -X0*py_lerch(alp, gam, y0, age)
  psize <- p_ys_sinteg(alp, gam, ys, age)
  
  cat(sprintf(" p_pat: %g\n", psize))
  cat(sprintf(" Devadno: %g\n", -2*npat*enad))
  cat(sprintf(" Devsize: %g\n", -2*npat*pno*(log(X0*psize))))
  
  lnlik <- pno*log(psize*X0) + enad
  return(-2*npat*lnlik)
}

upar <- vector()
#upar <- as.numeric(parDF$parval)
upar[1] <- 10
upar[2] <- 20
upar[3] <- -0.05

X0 <- upar[1]
alp <- upar[2]
gam <- upar[3]
ages <- 55
y0 <- 50
ys <- 9051
yl <- 50
yh <- 400
pno <- 1
npat <- 51
nvec <- seq(0,y0,1)

p1 <- pn_zeta(0, alp, gam, nvec, ages)
p2 <- pn_g(0, alp, gam, nvec, ages)
#(p1-p2)/p1*100

p0_zeta <- 1-sum(p1)
p0_g <- 1-sum(p2)
(p0_zeta-p0_g)/p0_zeta*100

# integration vs lerch difference ys - (ys-1)
psl <- p_ys_lerch(alp, gam, ys, ages)
pss <- p_ys_sinteg(alp, gam, ys, ages)
psl
pss
(psl-pss)/pss*100

(p0_zeta - p0_gG(0, alp, gam, y0, ages))/p0_zeta*100

pl <- py_lerch(alp, gam, y0, ages)
pgG <-py_gG_sinteg(alp, gam, y0, ages) 
(pl-pgG)/pl

print(p_ys_lerch(alp, gam, ys, ages))
print(p_ys_sinteg(alp, gam, ys, ages))
pds <- person_deviance_ys(X0, alp, gam, ymin, ys, pno, npat, ages)
pds
pdd <- person_deviance_ylyh(X0, alp, gam, ymin, yl, yh, pno, npat, ages)
pdd
pdde <- person_deviance_ylyh_exact(X0, alp, gam, ymin, yl, yh, pno, npat, ages)
pdde
pddf <- person_deviance_ylyh_factorial(X0, alp, gam, ymin, yl, yh, pno, npat, ages)
pddf
(pdde-pddf)/pddf





