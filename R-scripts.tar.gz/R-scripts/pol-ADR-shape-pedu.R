#----------------------------------------------
# adeno: data set with negative screening results
# check age and sex dependence
# based on adenoma prevalence
# keep shape information
# jck, 2022/05/30
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects 

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma" # project root directory
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
statdir 
datdir 

#----------------------------------------------------------
# prepare screening data
#----------------------------------------------------------
setwd("~/imodel/colonlmu/data_lmu/adenoma/")
load("adeno-ADR.Rdata")

dim(adeno)
# 258116     19
table(adeno$dad) # DIAGNOSEADENOMA
#     no    yes 
# 191884  66232 
names(adeno)
#[1] "patid"           "postcode"        "sex"             "byr"             "byrcat"          "age"             "agecat"         
#[8] "pscat"           "EXAMINATIONDATE" "QUARTAL"         "dad"             "lok"             "polypcount"      "polypsize"      
#[15] "polypshape"      "adenomhist"      "histkarzinom"    "adv_adenoma"     "adv_npl" 

str(adeno)
summary(adeno)

# no cancers in 2009
table(adeno$histkarzinom,adeno$QUARTAL)

mean(adeno$age[adeno$histkarzinom == 1 & adeno$QUARTAL < 20091]) # 68.35644
#adeno <- adeno[adeno$QUARTAL < 20091,]
length(adeno$dad[adeno$dad == "yes"]) # 66232
sum(adeno$histkarzinom) # 1919
table(adeno$histkarzinom)
#      0      1 
# 256197   1919 

# remove carcinoma
adeno <- adeno[adeno$histkarzinom < 1,]
dim(adeno) # 256197     19
table(adeno$dad)
#     no    yes 
# 190436  65761

table(adeno$adenomhist[adeno$dad == "yes"],useNA = "always")
# tubular tubulovillous       villous     dysplasia          <NA> 
#   53206          8953           688          1587          1327  
table(adeno$polypcount[adeno$dad == "yes"],useNA = "always")
#      1   2-4   >=5  <NA> 
#  31414 28773  5208   366 
table(adeno$polypsize[adeno$dad == "yes"],useNA = "always")
#   0.25  0.75   1.5     2   2.5     4  <NA> 
#  28827 23024  7592  2539  2987   418   374 
table(adeno$polypshape[adeno$dad == "yes"],useNA = "always")
#  flat    sessile peduncular       <NA> 
#  7482      47061      10839        379 
table(adeno$lok[adeno$dad == "yes"],useNA = "always")
#distal     both proximal     <NA> 
#  18306    20087    13139    14229 

help1 <- split(adeno,adeno$dad)

acc.org <- help1[[2]] # with adenoma
# complete cases for adenoma
acc <- acc.org[complete.cases(acc.org[ , c("adenomhist","polypcount","polypsize","polypshape","lok")]),]
dim(acc) # 50649    19
dim(acc.org)[1]- dim(acc)[1] # 15112 records with incomplete information removed
round(dim(acc)[1]/dim(acc.org)[1]*100,1)  # 77.0% remain
table(acc$dad,useNA="always")
# no   yes  <NA> 
#  0 50649     0 

# calculate reduction factor for age and sex
# limit to maximal age
noad <- help1[[1]] # no adenoma
table(noad$dad,useNA="always")
a.o <- subset(acc.org, age < 93)
a.r <- subset(acc, age < 93)
n.o <- subset(noad, age < 93)
a.o$npat <- 1
a.o <- aggregate(a.o$npat,list(a.o$sex,a.o$age), sum)
a.r$npat <- 1
a.r <- aggregate(a.r$npat,list(a.r$sex,a.r$age), sum)
n.o$npat <- 1
n.o <- aggregate(n.o$npat,list(n.o$sex,n.o$age), sum)
# data frame with with reduced number of patients without adenoma
n.r <- n.o
n.r$x <- as.integer(a.r$x/a.o$x*n.o$x+.5)

# concatenate location
table(acc$lok)
acc$lok2 <- "proximal"
acc$lok2[acc$lok == "both"] <- "distboth"
acc$lok2[acc$lok == "distal"] <- "distboth"
acc$lok2 <- as.factor(acc$lok2)
#acc$lok2 <- factor(acc$lok2, levels = c(1:2), labels = c("proximal","distboth"))
table(acc$lok,acc$lok2)

#----------------------------------------------------------
# generate grouped patient data with adenoma
#----------------------------------------------------------
# add column with number of patients
acc$npat <- 1

acc.r <- aggregate(acc$npat,list(acc$sex,
                                  acc$age,
                                  acc$agecat,
                                  acc$polypshape,
                                  #acc$lok2,
                                  #acc$accmhist,
                                  acc$polypcount,
                                  acc$pscat), sum)
headline <- c("sex","age","agecat","shape","countcat","sizecat","npat")
names(acc.r) <- headline

dim(acc.r)
str(acc.r)
summary(acc.r)

noad$npat <- 1
noad.o <- aggregate(noad$npat,list(noad$sex,noad$age,noad$agecat), sum)
noad.r <- data.frame(noad.o$Group.1,noad.o$Group.2,noad.o$Group.3,"none","0","<DL",noad.o$x)
names(noad.r) <- headline

# replace with reduced number of patients
noad.r$npat[1:76] <- n.r$x # leave age counts >= 93
round(sum(noad.r$npat)/sum(noad.o$x)*100.1) # 77.0%
round(dim(acc)[1]/dim(acc.org)[1]*100,1)  # 77.0% remain

dim(noad.r)
str(noad.r)
summary(noad.r)

adpg <- rbind(acc.r,noad.r)

dim(adpg)
str(adpg)
summary(adpg)

sum(adpg$npat[adpg$sex == "m"]) # 88300
sum(adpg$npat[adpg$sex == "w"]) # 109047

adpg$pno <- NA
adpg$pno[adpg$countcat == "0"] <- 0
adpg$pno[adpg$countcat == "1"] <- 1
adpg$pno[adpg$countcat == "2-4"] <- 2 # most probable number
adpg$pno[adpg$countcat == ">=5"] <- 5 # most probable number
table(adpg$pno,useNA="always")

sizemin <-  exp((log(0.25)+log(0.5))/2)
adpg$size <- NA
adpg$size[adpg$sizecat == "<DL"] <- 0
adpg$size[adpg$sizecat == "<0.5"] <- sizemin
adpg$size[adpg$sizecat == "0.5-1"] <- sizemin*2
adpg$size[adpg$sizecat == "1-2"] <- sizemin*4
adpg$size[adpg$sizecat == ">2"] <- sizemin*8
table(adpg$size,useNA="always")

#----------------------------------------------------------
# cell size assignment
#----------------------------------------------------------
ymin <- 50
adpg$ymin <- ymin # physical DL

none <- subset(adpg, sizecat == "<DL")
sefl <- subset(adpg, shape == "sessile" | shape == "flat")
pedu <- subset(adpg, shape == "peduncular")

none <- subset(adenoN0, shape == "none")
none$ylo2d <- 0
none$yhi2d <- 0
none$ylo3d <- 0
none$yhi3d <- 0

sefl$ylo2d <- 0
sefl$ylo2d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo2d[sefl$sizecat == "0.5-1"] <- 200
sefl$ylo2d[sefl$sizecat == "1-2"] <- 800
sefl$ylo2d[sefl$sizecat == ">2"] <- 3200

sefl$yhi2d <- 0
sefl$yhi2d[sefl$sizecat == "<0.5"] <- 200
sefl$yhi2d[sefl$sizecat == "0.5-1"] <- 800
sefl$yhi2d[sefl$sizecat == "1-2"] <- 3200
sefl$yhi2d[sefl$sizecat == ">2"] <- -1 # 12800

sefl$ylo3d <- 0
sefl$ylo3d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo3d[sefl$sizecat == "0.5-1"] <- 400
sefl$ylo3d[sefl$sizecat == "1-2"] <- 3200
sefl$ylo3d[sefl$sizecat == ">2"] <- 25600

sefl$yhi3d <- 0
sefl$yhi3d[sefl$sizecat == "<0.5"] <- 400
sefl$yhi3d[sefl$sizecat == "0.5-1"] <- 3200
sefl$yhi3d[sefl$sizecat == "1-2"] <- 25600
sefl$yhi3d[sefl$sizecat == ">2"] <- -1 # 204800

# set very small pedu's to zero
ymin.pedu <- 40
pedu$ymin <- ymin.pedu
pedu$ylo2d <- 0
pedu$ylo2d[pedu$sizecat == "<0.5"] <- ymin.pedu # 13
pedu$ylo2d[pedu$sizecat == "0.5-1"] <- 50
pedu$ylo2d[pedu$sizecat == "1-2"] <- 200
pedu$ylo2d[pedu$sizecat == ">2"] <- 800

pedu$yhi2d <- 0
pedu$yhi2d[pedu$sizecat == "<0.5"] <- 50
pedu$yhi2d[pedu$sizecat == "0.5-1"] <- 200
pedu$yhi2d[pedu$sizecat == "1-2"] <- 800
pedu$yhi2d[pedu$sizecat == ">2"] <- -1 # 3200

pedu$ylo3d <- 0
pedu$ylo3d[pedu$sizecat == "<0.5"] <- ymin.pedu # 6
pedu$ylo3d[pedu$sizecat == "0.5-1"] <- 50
pedu$ylo3d[pedu$sizecat == "1-2"] <- 400
pedu$ylo3d[pedu$sizecat == ">2"] <- 3200

pedu$yhi3d <- 0
pedu$yhi3d[pedu$sizecat == "<0.5"] <- 50
pedu$yhi3d[pedu$sizecat == "0.5-1"] <- 400
pedu$yhi3d[pedu$sizecat == "1-2"] <- 3200
pedu$yhi3d[pedu$sizecat == ">2"] <- -1 # 25600

#pedu$sizecat[pedu$ylo2d == 0] <- "<DL"
#pedu$shape[pedu$ylo2d == 0] <- "none"
#pedu$loca[pedu$ylo2d == 0] <- "none"
#pedu$countcat[pedu$ylo2d == 0] <- "0"


#--------------------------------------------------------
# check shares
#--------------------------------------------------------
ef <- rbind(sefl,pedu,none)

# DIAGNOSEADENOMA
ef$dad <- "yes"
ef$dad[ef$sizecat == "<DL"] <- "no"
ef$dad <- as.factor(ef$dad)

# control for likelihood
#ef$shape <- "all"
#ef$shape[ef$sizecat == "<DL"] <- "none"
#ef$shape <- as.factor(ef$shape)

dim(ef)
str(ef)
summary(ef)

mADW <- sum(aggregate(ef$npat[ef$sizecat != "<DL"],list(ef$sex[ef$sizecat != "<DL"]),sum)$x[1])
mN0W <- sum(aggregate(ef$npat[ef$sizecat == "<DL"],list(ef$sex[ef$sizecat == "<DL"]),sum)$x[1])
mADM <- sum(aggregate(ef$npat[ef$sizecat != "<DL"],list(ef$sex[ef$sizecat != "<DL"]),sum)$x[2])
mN0M <- sum(aggregate(ef$npat[ef$sizecat == "<DL"],list(ef$sex[ef$sizecat == "<DL"]),sum)$x[2])

round(mADW/(mADW+mN0W),3) # 0.203
round(mN0W/(mADW+mN0W),3) # 0.797
round(mADM/(mADM+mN0M),3) # 0.324
round(mN0M/(mADM+mN0M),3) # 0.676
round((mADM+mADW)/(mADM+mN0M+mADW+mN0W),3) # 0.257
round((mN0M+mN0W)/(mADM+mN0M+mADW+mN0W),3) # 0.743

#------------------------------------------------------
# check npat, pno & shape for Table S1
#------------------------------------------------------
ef.w <- subset(ef, sex == "w")
ef.m <- subset(ef, sex == "m")

aggregate(ef.w$npat,list(ef.w$agecat),sum)
sum(ef.w$npat) # 109047
aggregate(ef.w$npat,list(ef.w$agecat,ef.w$dad),sum)
aggregate(ef.w$npat,list(ef.w$dad),sum)
aggregate(ef.w$pno*ef.w$npat,list(ef.w$agecat,ef.w$dad),sum)
aggregate(ef.w$pno*ef.w$npat,list(ef.w$dad),sum)

aggregate(ef.m$npat,list(ef.m$agecat),sum)
sum(ef.m$npat)
aggregate(ef.m$npat,list(ef.m$agecat,ef.m$dad),sum)
aggregate(ef.m$npat,list(ef.m$dad),sum)
aggregate(ef.m$pno*ef.m$npat,list(ef.m$agecat,ef.m$dad),sum)
aggregate(ef.m$pno*ef.m$npat,list(ef.m$dad),sum)

library(forcats)
ef$shape <- fct_relevel(ef$shape, "sessile","peduncular","flat","none")

aggregate(ef.w$npat,list(ef.w$agecat,ef.w$shape),sum)
aggregate(ef.w$npat,list(ef.w$shape),sum)
aggregate(ef.m$npat,list(ef.m$agecat,ef.m$shape),sum)
aggregate(ef.m$npat,list(ef.m$shape),sum)

#-----------------------------------------------------
# produce shape-specific files
#----------------------------------------------------
#--------------------------------------------------------
# prepare shape data with optimal patient groups: sessile
#--------------------------------------------------------
justsess <- subset(ef, shape == "sessile")
notsess <- subset(ef, shape != "sessile")

notsess$sizecat <- "<DL"
notsess$shape <- "none"
#notsess$loca <- "none"
notsess$countcat <- "0"
notsess$pno <- 0
notsess$size <- 0
notsess$ylo2d <- 0
#notsess$ys2d <- 0
notsess$yhi2d <- 0
notsess$ylo3d <- 0
#notsess$ys3d <- 0
notsess$yhi3d <- 0

resess <- rbind(justsess,notsess)
resess <- droplevels(resess)
str(resess)
table(resess$shape)
names(resess)
newline <- c("sex","dad","age","agecat","shape","countcat","sizecat","pno","size","ymin","ylo2d","yhi2d","ylo3d","yhi3d","npat")
sess <- with(resess,aggregate(npat,list(sex,dad,age,agecat,shape,countcat,sizecat,pno,size,ymin,ylo2d,yhi2d,ylo3d,yhi3d),sum))
names(sess) <- newline

dim(justsess)
dim(notsess)
dim(resess)
dim(sess)
str(sess)
aggregate(sess$npat,list(sess$agecat),sum)
sum(sess$npat)
sum(justsess$npat)+sum(notsess$npat)

#--------------------------------------------------------
# prepare shape data with optimal patient groups: peduncular
#--------------------------------------------------------
justpedu <- subset(ef, shape == "peduncular")
notpedu <- subset(ef, shape != "peduncular")

notpedu$sizecat <- "<DL"
notpedu$shape <- "none"
#notpedu$loca <- "none"
notpedu$countcat <- "0"
notpedu$pno <- 0
notpedu$size <- 0
notpedu$ylo2d <- 0
#notpedu$ys2d <- 0
notpedu$yhi2d <- 0
notpedu$ylo3d <- 0
#notpedu$ys3d <- 0
notpedu$yhi3d <- 0

repedu <- rbind(justpedu,notpedu)
repedu <- droplevels(repedu)
str(repedu)
table(repedu$shape)
names(repedu)
newline <- c("sex","dad","age","agecat","shape","countcat","sizecat","pno","size","ymin","ylo2d","yhi2d","ylo3d","yhi3d","npat")
pedu <- with(repedu,aggregate(npat,list(sex,dad,age,agecat,shape,countcat,sizecat,pno,size,ymin,ylo2d,yhi2d,ylo3d,yhi3d),sum))
names(pedu) <- newline

dim(justpedu)
dim(notpedu)
dim(repedu)
dim(pedu)
str(pedu)
aggregate(pedu$npat,list(pedu$agecat),sum)
sum(pedu$npat)
sum(justpedu$npat)+sum(notpedu$npat)

#--------------------------------------------------------
# prepare shape data with optimal patient groups: flat
#--------------------------------------------------------
justflat <- subset(ef, shape == "flat")
notflat <- subset(ef, shape != "flat")

notflat$sizecat <- "<DL"
notflat$shape <- "none"
#notflat$loca <- "none"
notflat$countcat <- "0"
notflat$pno <- 0
notflat$size <- 0
notflat$ylo2d <- 0
#notflat$ys2d <- 0
notflat$yhi2d <- 0
notflat$ylo3d <- 0
#notflat$ys3d <- 0
notflat$yhi3d <- 0

reflat <- rbind(justflat,notflat)
reflat <- droplevels(reflat)
str(reflat)
table(reflat$shape)
names(reflat)
newline <- c("sex","dad","age","agecat","shape","countcat","sizecat","pno","size","ymin","ylo2d","yhi2d","ylo3d","yhi3d","npat")
flat <- with(reflat,aggregate(npat,list(sex,dad,age,agecat,shape,countcat,sizecat,pno,size,ymin,ylo2d,yhi2d,ylo3d,yhi3d),sum))
names(flat) <- newline

dim(justflat)
dim(notflat)
dim(reflat)
dim(flat)
str(flat)
aggregate(flat$npat,list(flat$agecat),sum)
sum(flat$npat)
sum(justflat$npat)+sum(notflat$npat)

#----------------------------------------------------
# check patient numbers
#----------------------------------------------------
sum(sess$npat) # 197347
aggregate(sess$npat,list(sess$shape,sess$sex),sum)
sum(aggregate(sess$npat,list(sess$shape,sess$sex),sum)$x)
sum(pedu$npat) # 197347
aggregate(pedu$npat,list(pedu$shape,pedu$sex),sum)
sum(aggregate(pedu$npat,list(pedu$shape,pedu$sex),sum)$x)
sum(flat$npat) # 197347
aggregate(flat$npat,list(flat$shape,flat$sex),sum)
sum(aggregate(flat$npat,list(flat$shape,flat$sex),sum)$x)

adenoPG <- ef
sum(adenoPG$npat) # 197347
aggregate(adenoPG$npat,list(adenoPG$shape,adenoPG$sex),sum)
sum(aggregate(adenoPG$npat,list(adenoPG$shape,adenoPG$sex),sum)$x)

round(1 - aggregate(sess$npat,list(sess$shape),sum)$x[2]/sum(sess$npat),4) # 0.1849
round(1 - aggregate(pedu$npat,list(pedu$shape),sum)$x[2]/sum(pedu$npat),4) # 0.0419
round(1 - aggregate(flat$npat,list(flat$shape),sum)$x[2]/sum(flat$npat),4) # 0.0298
round(aggregate(adenoPG$npat,list(adenoPG$shape),sum)$x[4]/sum(adenoPG$npat),4) # 0.7434

# write data files into project directory
setwd(datdir)
#save(adenoPG, file = "adenoPG-shape-20220518.Rdata")
#save(sess, file = "sessPG-20220527.Rdata")
#save(flat, file = "flatPG-20220527.Rdata")
#save(pedu, file = "peduPG-20220527.Rdata")

#-----------------------------------------------------
# write data files into project directory
#----------------------------------------------------
setwd(datdir)
names(ef)
#adenoPG <- ef
#save(adenoPG, file = "adenoPG-shape-20220518.Rdata")
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------
setwd(plotdir)
library(ggplot2)
library(scales)
library(cowplot)

pf <- adenoPG
summary(pf)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[4],cbPalette[7],cbPalette[2],cbPalette[1])
#myPalette <- c(cbPalette[1],cbbPalette[1])

# New facet label names for sex variable
sex.labs <- c("women", "men")
names(sex.labs) <- c("w", "m")

fp.1 <- ggplot() + 
  #ggtitle("Age & sex specific patient numbers, 2022/04/08") + 
  #geom_bar(data = pf, aes(x=agecat, y=npat, fill=dad), stat="identity", position="dodge", width = 0.8) +
  geom_bar(data = pf, aes(x=agecat, y=npat, fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(name = "Shape", values = myPalette) +
  facet_grid(sex ~ ., labeller = labeller(sex = sex.labs)) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  scale_y_log10(name="No. of patients", labels=trans_format('log10', math_format(10^.x))) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15)) 
#  + theme_bw()  # use a white background
print(fp.1)

pf.s <- subset(pf, shape != "none")
fp.1.1 <- ggplot() + 
  #ggtitle("Age & sex specific patient numbers, 2022/04/08") + 
  #geom_bar(data = pf, aes(x=agecat, y=npat, fill=dad), stat="identity", position="dodge", width = 0.8) +
  geom_bar(data = pf.s, aes(x=agecat, y=npat, fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(name = "Shape", values = myPalette) +
  facet_grid(sex ~ ., labeller = labeller(sex = sex.labs)) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  #scale_y_log10(name="No. of patients", labels=trans_format('log10', math_format(10^.x))) +
  scale_y_continuous(name="No. of patients") +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15)) 
#  + theme_bw()  # use a white background
print(fp.1.1)

#-----------------------------------------
# reproduce imposed prevalence and plot
#-----------------------------------------

pf.prev <- aggregate(pf$npat,list(pf$sex,pf$shape,pf$agecat),sum)
names(pf.prev) <- c("Sex","Shape","agecat","npat")
help1 <- split(pf.prev,pf.prev$Sex)
pf.w <- help1[[1]]
pf.m <- help1[[2]]
sum(pf.w$npat)
sum(pf.m$npat)

pf.ac.m <- aggregate(pf.m$npat,list(pf.m$agecat),sum)
pf.ac.w <- aggregate(pf.w$npat,list(pf.w$agecat),sum)

help2.m <- split(pf.m,pf.m$agecat)
help2.w <- split(pf.w,pf.w$agecat)

for(i in 1:7){
  help2.m[[i]]$nagrp <- pf.ac.m$x[i] 
  help2.w[[i]]$nagrp <- pf.ac.w$x[i] 
}

pf.p.m <- help2.m[[1]]
pf.p.w <- help2.w[[1]]
for(i in 2:7){
  pf.p.m <- rbind(pf.p.m,help2.m[[i]])
  pf.p.w <- rbind(pf.p.w,help2.w[[i]])
}
pf.p <- rbind(pf.p.m,pf.p.w)
pf.p$ppat <- pf.p$npat/pf.p$nagrp
pf.p$ppat[pf.p$Shape == "none"] <- 1 - pf.p$ppat[pf.p$Shape == "none"]
levels(pf.p$Shape)[4] <- "all shapes"
pf.p

fp.2 <- ggplot() + 
  #ggtitle("Age & sex specific prevalence, 2022/05/18") + 
  #geom_bar(data = pf.p, aes(x=agecat, y = 100*ppat, fill=Adenoma), stat="identity", position="dodge", width = 0.8) +
  geom_bar(data = pf.p, aes(x=agecat, y=100*ppat,fill=Shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(Sex ~ ., labeller = labeller(Sex = sex.labs)) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  scale_y_continuous(name="Adenoma detection rate (%)", limits=c(0,50), breaks = seq(0,50,10)) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Share (%)", labels = scales::percent, limits=c(0,1), breaks = seq(0,1,0.2)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15)) 
#  + theme_bw()  # use a white background
print(fp.2)

pf.p.s <- subset(pf.p, Shape != "all shapes")
fp.2.1 <- ggplot() + 
  #ggtitle("Age & sex specific prevalence, 2022/05/18") + 
  #geom_bar(data = pf.p, aes(x=agecat, y = 100*ppat, fill=Adenoma), stat="identity", position="dodge", width = 0.8) +
  geom_bar(data = pf.p.s, aes(x=agecat, y=100*ppat,fill=Shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(Sex ~ ., labeller = labeller(Sex = sex.labs)) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  scale_y_continuous(name="Adenoma detection rate (%)", limits=c(0,30), breaks = seq(0,30,10)) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Share (%)", labels = scales::percent, limits=c(0,1), breaks = seq(0,1,0.2)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15)) 
#  + theme_bw()  # use a white background
print(fp.2.1)

#--------------------------------------------------------
# cowplot
#--------------------------------------------------------
plot_grid(fp.1.1, fp.2.1, labels = "AUTO", ncol=1)

#--------------------------------------------------------
# all-in-one
#--------------------------------------------------------

headline <- c("quant","Sex","agecat","Shape","value")
names(pf.s)
pf.pat <- data.frame("Npat",pf.s$sex,pf.s$agecat,pf.s$shape,pf.s$npat)
names(pf.pat) <- headline
names(pf.p.s)
pf.adr <- data.frame("ADR",pf.p.s$Sex,pf.p.s$agecat,pf.p.s$Shape,pf.p.s$ppat*100)
names(pf.adr) <- headline

pf.pa <- rbind(pf.pat,pf.adr)
str(pf.pa)

quant.labs <- c("No. of patients", "Adenoma detection rate (%)")
names(quant.labs) <- c("Npat", "ADR")

pf.pa$quant <- fct_rev(pf.pa$quant)

fp.3 <- ggplot() + 
  #ggtitle("Age & sex specific prevalence, 2022/05/18") + 
  #geom_bar(data = pf.p, aes(x=agecat, y = 100*ppat, fill=Adenoma), stat="identity", position="dodge", width = 0.8) +
  geom_bar(data = pf.pa, aes(x=agecat, y=value,fill=Shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(quant ~ Sex, labeller = labeller(Sex = sex.labs, quant = quant.labs), scales = "free_y") + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  #scale_y_continuous(name="Adenoma detection rate (%)", limits=c(0,30), breaks = seq(0,30,10)) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Share (%)", labels = scales::percent, limits=c(0,1), breaks = seq(0,1,0.2)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15),
        axis.title.y=element_blank(),
        legend.position = c(0.83,0.9)) 
#  + theme_bw()  # use a white background
print(fp.3)

