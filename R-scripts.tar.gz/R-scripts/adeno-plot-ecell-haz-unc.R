#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(datdir)
load(file = "canag-ecell-20220615.Rdata")
cf <- ecf.canag
str(cf)

cf$Sex[cf$Sex == "w"] <- "women"
cf$Sex[cf$Sex == "m"] <- "men"
#levels(cf$Sex)[levels(cf$Sex)=="w"] <- "women"
#levels(cf$Sex)[levels(cf$Sex)=="m"] <- "men"

#cf$mage[cf$Shape == "flat"] <- cf$mage[cf$Shape == "flat"] - 1
#cf$mage[cf$Shape == "peduncular"] <- cf$mage[cf$Shape == "peduncular"] + 1
cf$Sex <- fct_relevel(cf$Sex, "women","men")
#cf$pshp <- "pshp"
cf <- subset(cf, Shape != "flat,3d" & agecat != "total")
cf <- cf[complete.cases(cf), ]  
cf <- droplevels(cf)

#cf <- subset(cf, chaz > 0)
#-----------------------------------------------------
# read hazards with model uncertainties
#------------------------------------------------------
setwd(curvdir)
# read model prediction from age 20,90
load(file="haz-unc-a55_90.Rdata")

ec$Shape <- fct_relevel(ec$Shape, "all","sessile","peduncular", "flat")
ec$Sex <- fct_relevel(ec$Sex, "women","men")
ec

#--------------------------------------
# start plotting
#--------------------------------------

setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(aes(y=ncell, color = Shape, linetype = Sex), size = 1) +
  geom_line(data = ec, aes(x=age, y=eYad, color = Shape), size = 1) +
  #geom_ribbon(data = ec, aes(x=age, ymin=hazlo/eCad, ymax=hazhi/eCad, group = Shape), linetype=0, alpha=0.1) +
  #geom_line(data = ec, aes(x=age, y=haz, color = Shape), size = 1) +
  #geom_ribbon(data = ec, aes(x=age, ymin=hazlo, ymax=hazhi, group = Shape), linetype=0, alpha=0.1) +
  #geom_point(data = cf.age, aes(x=mage, y=chaz, color = Shape, shape = Sex), size = 4) + 
  #geom_linerange(data = cf.age, aes(x = mage, y=chaz, ymax = chaz.hi, ymin = chaz.lo), size = .75) +
  facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(35,90,5)) +
  #scale_y_log10(name = bquote('Hazard '(yr^-1)),
                #breaks = trans_breaks("log10", function(x) 10^x),
  #              labels = trans_format("log10", math_format(10^.x))) +
  #scale_y_continuous(name="Mean cell number", limits=c(0.4,1.25), breaks = seq(0.4,1.25,0.2)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.85)) 
#  + theme_bw()  # use a white background
print(fp.1)

fp.3 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = ec, aes(x=age, y=eYad, color = Shape), size = 1) +
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  #scale_y_continuous(name = "Mean cell number", trans = "log10", labels = scales::scientific) + 
  scale_y_log10(name = "Mean cell number",
                #breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(linetype="none", color = "none") + 
  theme(text = element_text(size=15),legend.position = c(.15,0.9)) 
#  + theme_bw()  # use a white background
print(fp.3)

cf.p <- cf
cf.p$mage[cf.p$Shape == "sessile"] <- cf.p$mage[cf.p$Shape == "sessile"] - .5
cf.p$mage[cf.p$Shape == "peduncular"] <- cf.p$mage[cf.p$Shape == "peduncular"] + .5
cf.p$mage[cf.p$Shape == "flat"] <- cf.p$mage[cf.p$Shape == "flat"] + 1
fp.4 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = ec, aes(x=age, y=hazmn, color = Shape), size = 1) +
  #geom_ribbon(data = ec, aes(x=age, ymin=hazlo, ymax=hazhi, group = Shape), linetype=0, alpha=0.1) +
  geom_point(data = cf.p, aes(x=mage, y=chaz, color = Shape), size = 4) + 
  geom_linerange(data = cf.p, aes(x = mage, y=chaz, ymax =chaz.hi, ymin = chaz.lo), size = .75) +
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  #scale_y_log10(name = "Mean cell number") + 
  scale_y_log10(name = bquote('Cancer hazard '(yr^-1)), limits = c(10^.5*1e-6,10^.5*1e-2),
                #breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  #scale_y_continuous(name = bquote('Cancer hazard '(yr^-1))) +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  scale_shape_manual(values = c(21, 16)) +
  guides(linetype="none", shape="none") + 
  theme(text = element_text(size=15),legend.position = c(.25,0.9)) 
#  + theme_bw()  # use a white background
print(fp.4)

#library(cowplot)
#plot_grid(fp.2,fp.4, nrow = 1)

setwd(plotdir)
hazfac <- 1e4
cf.tot <- subset(cf, Shape == "all")
cf.tot$pshp = "1"
fp.5 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = ec, aes(x=age, y=hazmn*hazfac, color = Shape), size = 1) +
  geom_ribbon(data = subset(ec, Shape == "all"), aes(x=age, ymin=hazlo*hazfac, ymax=hazhi*hazfac, group = Shape), linetype=0, alpha=0.1) +
  #geom_ribbon(data = subset(ec, Shape == "all shapes"), aes(x=age, ymin=hazlo, ymax=hazhi, group = Shape), linetype=0, alpha=0.1) +
  geom_point(data = cf.tot, aes(x=mage, y=chaz*hazfac, color = Shape, shape = pshp), size = 4) + 
  geom_linerange(data = cf.tot, aes(x = mage, y=chaz*hazfac, ymax =chaz.hi*hazfac, ymin = chaz.lo*hazfac), size = .75) +
  facet_wrap(Sex ~ ., ncol = 1, scales = "free_y") + 
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  scale_y_continuous(name = "Cancer cases in 10,000 persons per yr") + 
  #scale_y_log10(name = bquote('Cancer hazard '(yr^-1)), limits = c(10^.5*1e-7,10^.5*1e-4),
                #breaks = trans_breaks("log10", function(x) 10^x),
  #              labels = trans_format("log10", math_format(10^.x))) +
  #scale_color_manual(values=cbPalette[c(2,4,7)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  scale_color_manual(labels = c("all shapes","sessile","peduncular","flat"), values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  scale_shape_manual(values = c(21, 16)) +
  guides(linetype="none", shape="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.85)) 
#  + theme_bw()  # use a white background
print(fp.5)

#x <- 1:4
#y <- c(0, 0.0001, 0.0002, 0.0003)
#dd <- data.frame(x, y)

#ggplot(dd, aes(x, y)) + geom_point() +
#  scale_y_log10("y",
#                breaks = trans_breaks("log10", function(x) 10^x),
#                labels = trans_format("log10", math_format(10^.x)))

