#----------------------------------------------
# plot adeno enad + adr analysis
# 2022/05/25, jck
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="raw-agegrp-all-w-2d-K2-permut-atrend.Rdata")
s.w <- psf

load(file="raw-agegrp-all-m-2d-K2-permut-atrend.Rdata")
s.m <- psf

load(file="mdl-age-all-w-2d-K2-permut-atrend.Rdata")
m.w <- pmf

load(file="mdl-age-all-m-2d-K2-permut-atrend.Rdata")
m.m <- pmf


setwd(plotdir)
# build and adjust pf
# screening
pf.s <- rbind(s.w,s.m)
pf.s$q.mn[pf.s$quant == "ADR"] <- pf.s$q.mn[pf.s$quant == "ADR"]*100
pf.s$q.lo[pf.s$quant == "ADR"] <- pf.s$q.lo[pf.s$quant == "ADR"]*100
pf.s$q.hi[pf.s$quant == "ADR"] <- pf.s$q.hi[pf.s$quant == "ADR"]*100
pf.s$Sex <- fct_relevel(pf.s$Sex,"women","men")
pf.s$quant <- fct_relevel(pf.s$quant,"APC","ADR")
pf.s <- droplevels(pf.s)
summary(pf.s)

# model
pf.m <- rbind(m.w,m.m)
pf.m$q.mn[pf.m$quant == "ADR"] <- pf.m$q.mn[pf.m$quant == "ADR"]*100
pf.m$Sex <- fct_relevel(pf.m$Sex,"women","men")
pf.m$quant <- fct_relevel(pf.m$quant,"APC","ADR")
pf.early <- subset(pf.m, age < 55)
pf.early <- data.frame(pf.early,"early")
names(pf.early)[7] <- "Period"
pf.late <- subset(pf.m, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[7] <- "Period"

pf.m <- rbind(pf.early,pf.late)
summary(pf.m)

quant.labs <- c("Adenoma per colonoscopy", "Adenoma detection rate (%)")
names(quant.labs) <- c("APC", "ADR")

#legend_title <- "Shape"
fp.1 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf.m, aes(x=age, y=q.mn, linetype = Period), size = 1) +
  geom_point(data = pf.s, aes(x = age, y=q.mn, shape = Source), size = 4) + 
  geom_linerange(data = pf.s, aes(x = age, y=q.mn, ymax =q.hi, ymin = q.lo), size = .75) +
  facet_grid (quant ~ Sex, scales = "free_y", labeller = labeller(quant = quant.labs)) +
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape = "none", linetype = "none") +
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        axis.title.y=element_blank(),
        legend.position = c(0.18,0.9)) 
print(fp.1)

