#----------------------------------------------
# adeno: data set with negative screening results
# check age and sex dependence
# based on adenoma prevalence
# jck, 2022/04/06
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects 

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/colonlmu/adenoma" # project root directory
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
statdir 
datdir 

#----------------------------------------------------------
# prepare screening data
#----------------------------------------------------------
setwd("~/gsf/imodel/colonlmu/data_lmu/adenoma/")
load("adeno-ADR.Rdata")

dim(adeno)
# 258116     18
table(adeno$dad) # DIAGNOSEADENOMA
#     no    yes 
# 191884  66232 
names(adeno)
#[1] "patid"           "postcode"        "sex"             "byr"             "byrcat"          "age"             "agecat"         
#[8] "EXAMINATIONDATE" "QUARTAL"         "dad"             "lok"             "polypcount"      "polypsize"       "polypshape"     
#[15] "adenomhist"      "histkarzinom"    "adv_adenoma"     "adv_npl" 

summary(adeno)

#----------------------------------------------------------
# generate grouped patient data with adenoma
#----------------------------------------------------------

adeno$npat <- 1
npat.sum <- aggregate(adeno$npat,list(adeno$sex,
                                  adeno$agecat,
                                  adeno$dad), sum)

age.mean <- aggregate(adeno$age,list(adeno$sex,
                                  adeno$agecat,
                                  adeno$dad), mean)

df <- data.frame(age.mean,npat.sum$x)
headline <- c("sex","agecat","dad","age","npat")
names(df) <- headline

dim(df)
str(df)
summary(df)

sum(df$npat)
sum(df$npat[df$dad == "yes"])

#----------------------------------------------------------
# sex & age-specific assessment
#----------------------------------------------------------

adM <- subset(df, sex == "m")
adW <- subset(df, sex == "w")

npatADMtot <- aggregate(adM$npat,list(adM$agecat),sum)$x
npatADWtot <- aggregate(adW$npat,list(adW$agecat),sum)$x
npatADMyes <- aggregate(adM$npat[adM$dad == "yes"],list(adM$agecat[adM$dad == "yes"]),sum)$x
npatADWyes <- aggregate(adW$npat[adW$dad == "yes"],list(adW$agecat[adW$dad == "yes"]),sum)$x

npatADMyes/npatADMtot
npatADWyes/npatADWtot
sum(npatADMyes)/sum(npatADMtot)
sum(npatADWyes)/sum(npatADWtot)

nlevels <- length(levels(adM$dad))
help.m <- split(adM, adM$dad)
help.w <- split(adW, adW$dad)
for (i in 1:nlevels)
{
  help.m[[i]]$npatTot <- npatADMtot
  help.w[[i]]$npatTot <- npatADWtot
  help.m[[i]]$npatYes <- npatADMyes
  help.w[[i]]$npatYes <- npatADWyes
  help.m[[i]]$pNcat <- npatADMyes/npatADMtot
  help.w[[i]]$pNcat <- npatADWyes/npatADWtot
}
df.m <- help.m[[1]]
df.w <- help.w[[1]]
for (i in 2:nlevels){
  df.m <- rbind(df.m,help.m[[i]])
  df.w <- rbind(df.w,help.w[[i]])
}
df.m <- subset(df.m, dad == "no")
df.w <- subset(df.w, dad == "no")

df <- rbind(df.w,df.m)
colnames(df)[5] <- "npatNo"


#----------------------------------------------------------
# simulation of confidence intervals
#----------------------------------------------------------
nsim = 100
pdim <- length(df$age)
pdfNo <- list()
pdfYes <- list()
pdfpNcat <- list()
for(i in 1:pdim)
{
  pdfNo[[i]] <- rpois(nsim,df$npatNo[i])
  pdfYes[[i]] <- rpois(nsim,df$npatYes[i])
  pdfpNcat[[i]] <- pdfYes[[i]]/(pdfYes[[i]]+pdfNo[[i]])
} 

df$pNcat.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfpNcat[[i]], probs = 0.025))))
pNcat.md <- unlist(lapply(pdfpNcat,median))
df$pNcat.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfpNcat[[i]], probs = 0.975))))

#levels(x)[levels(x)=="beta"] <- "two"
levels(df$sex)[levels(df$sex)=="w"] <- "women"
levels(df$sex)[levels(df$sex)=="m"] <- "men"

df.scr <- data.frame("measured",df$sex,df$agecat,df$age,df$pNcat,df$pNcat.lo,df$pNcat.hi)
headline <- c("Source","Sex","AgeGroup","age","pNcat","pNcat.lo","pNcat.hi")
names(df.scr) <- headline
df.scr
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

setwd(curvdir)
load(file ="adr-meas-JCK.Rdata")
df.jck <- droplevels(df.jck)
df.imp <- data.frame("imputed",df.jck$Sex,df.jck$AgeGroup,df.jck$age,df.jck$pNcat,df.jck$pNcat.hi,df.jck$pNcat.lo)
names(df.imp) <- headline

pf <- rbind(df.scr,df.imp)
pf$pShape = "open"
summary(pf)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
#myPalette <- c(cbbPalette[2],cbbPalette[6])
myPalette <- c(cbPalette[2],cbPalette[4],cbPalette[7],cbPalette[1])

library(ggplot2)

fp.1 <- ggplot() + 
  #ggtitle(shp) +
  geom_point(data = pf, aes(x = age, y = pNcat*100, shape = pShape, color = Source), size = 4) + 
  geom_linerange(data = pf, aes(x = age, y = pNcat*100, ymin = pNcat.lo*100, ymax = pNcat.hi*100), size = 0.75) +
  #geom_line(data = pf.2.plus.tot, aes(x = age, y = pNcat*100, color = Shape, linetype = Period, alpha = Source), size = 1) + 
  facet_grid(. ~ Sex) +
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  scale_y_continuous(name = "Adenoma detection rate (%)", limits = c(0,50), breaks = seq(0,50,10)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape="none") + 
  theme(text = element_text(size=15),legend.position = c(0.18,0.85)) 
print(fp.1)

