#----------------------------------------------
# adeno pextinct
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
#shp <- "flat"
shp <- "sessile"
#shp <- "peduncular"

noad <- character()
#noad <- "wN0"
noad <- "noN0"

patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    df0$ymin <- 40
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}

sexc <- character()
#sexc <- "both"
sexc <- "m"
#sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K1"
mmname <- "K2"

meth <- character()
#meth <- "sum" # summation
meth <- "hyp" # hypergeometric function

# likelihood
likc <- character()
likc <- "posize"
#likc <- "dist"

mdv <- character()
mdv <- "atrend"
#mdv <- "std"

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,mdv,sep="-") 

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
#ymin <- unique(df$ylo[df$sizecat == "<0.5"])
#df$ymin <- ymin
df <- droplevels(df)

# calculate df$npat_age
ad <- df

#npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum, drop=FALSE)
npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum)
#npat_size_age <- aggregate(ad$npat, list(factor(ad$age),ad$sizecat), sum)
#npat_size_age$x[is.na(npat_size_age$x) == T] <- 0
age_sum <- aggregate(ad$npat*ad$age, list(ad$agecat,ad$sizecat), sum)
#age_sum <- aggregate(ad$npat*ad$age, list(factor(ad$age),ad$sizecat), sum)
age_mean <- age_sum$x/npat_size_age$x
ylo_uni <- aggregate(ad$ylo, list(ad$agecat,ad$sizecat), unique)
yhi_uni <- aggregate(ad$yhi, list(ad$agecat,ad$sizecat), unique)
ymin_uni <- aggregate(ad$ymin, list(ad$agecat,ad$sizecat), unique)
#ylo_uni <- aggregate(ad$ylo, list(factor(ad$age),ad$sizecat), unique)
#yhi_uni <- aggregate(ad$yhi, list(factor(ad$age),ad$sizecat), unique)
#ymin_uni <- aggregate(ad$ymin, list(factor(ad$age),ad$sizecat), unique)

df.h <- data.frame(shp,sexc,dims,age_mean,(age_mean-65)/10,npat_size_age,ylo_uni$x,yhi_uni$x,ymin_uni$x)

npat_age <- aggregate(ad$npat, list(ad$agecat), sum)
#npat_age <- aggregate(ad$npat, list(factor(ad$age)), sum)
help1 <- split(df.h, df.h$Group.1)
nlevels <- length(levels(df.h$Group.1))
for(i in 1:nlevels){
  help1[[i]]$npat_age <- npat_age$x[i]
}
df.r <- help1[[1]]
for (i in 2:nlevels){
  df.r <- rbind(df.r,help1[[i]])
}
#df.r <- data.frame(df.h)
dim(df.r)
names(df.r) <- c("shp","sex","dims","age","acen","agecat","sizecat","npat","ylo","yhi","ymin","npat_age")
aggregate(df.r$npat,list(df.r$agecat),sum)
unique(df.r$npat_age)
#df <- df.r

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(ad)[1]))
cat(sprintf("   All Npat: %d\n", sum(ad$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(ad$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

{
  if (dims == "2d"){
    if (shp != "peduncular"){
      Size1cm <- 1/sqrt(800)
      Ninf <- 3200
    }
    else {
      Size1cm <- 1/sqrt(200)
      Ninf <- 800
    }
    gdim <- 2
    
  }
  else if (dims == "3d"){
    if (shp != "peduncular"){
      Size1cm <- 1/3200^(1/3) # 1 cm
      Ninf <- 25600
    }
    else {
      Size1cm <-  1/400^(1/3)
      Ninf <- 3200 # not used
    }
    gdim <- 3
  }
}

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "atrend"){thispardir <- patrendpardir}
  else if (mdv == "std"){thispardir <- pstdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

upar <- dpar$parval

if(mdv == "std"){
  npar <- length(upar)
  upar[npar+1] <- 0
}

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-posize-size.R")

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
      Esize <- ymeanK0
      Pext <- PextK0
      }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
    Esize <- ymeanK1
    Pext <- PextK1.app # needs rho!
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.sum
    Thelohi <- theta_lohi_K1.sum
    #Theloho <- pnlohi_K1.sum
    Esize <- EsizeK1.sum
    Pext <- PextK1
    #Pext <- PextK1.app
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.sum
    Thelohi <- theta_lohi_K2.sum
    Esize <- EsizeK2.sum
    Pext <- PextK2
  }
  else
  {
    print("Not implemented\n")
  }
}

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
upar <- dpar$parval

# all, women
#upar[1] <- 10.045259484
#upar[2] <- 0.06796999
#upar[3] <- 0.004404143
#upar[4] <- -0.06989550

# all, men
upar[1] <- 11.693846195
upar[2] <- 0.06733671
upar[3] <- 0.002654502
upar[4] <-  -0.09267444
  
#--------------------------------
# model predictions
#--------------------------------
#ages <- seq(20,80,1)
ages <- 60
#ndim <- length(ages)
#delt <- 10
delt <- seq(1,10,1)
ndim <- length(delt)

#probK0 <- PextK0(ages,delt,upar)
#probK0
#probK0^nclone

#probK1app <- PextK1.app(ages,delt,upar) # needs rho!
#probK1app
#probK1app^nclone

#probK1 <- PextK1(ages,delt,upar)
#probK1
#probK1^nclone

#nclone <- ymedian(ages,upar,gb.ymin,1000)
#nclone <- 200
sizecm <- 1
nclone <- (sizecm/Size1cm)^gdim
prob <- unlist(lapply(1:ndim, function(i) Pext(ages,delt[i],upar)))
pext <- exp(log(prob)*nclone)
#-----------------------------------------
# build plot frame
#-----------------------------------------
{
  if (sexc == "w") {sexcc = "women"}
  else if (sexc == "m") {sexcc = "men"}
}

# Mode
mde <- character()
mde <- "60_70"
#mde <- "age65"

headline <- c("Shape","Sex","Dim","age","delt","ncell","sizecm","halfN","p0","pext")
pef25 <- data.frame(shp,sexcc,gdim,ages,delt,nclone,Size1cm*nclone^(1/gdim),-log(2)/log(prob),prob,pext)
names(pef25) <- headline
str(pef25)
pef50 <- data.frame(shp,sexcc,gdim,ages,delt,nclone,Size1cm*nclone^(1/gdim),-log(2)/log(prob),prob,pext)
names(pef50) <- headline
str(pef50)
pef100 <- data.frame(shp,sexcc,gdim,ages,delt,nclone,Size1cm*nclone^(1/gdim),-log(2)/log(prob),prob,pext)
names(pef100) <- headline
str(pef100)
pef200 <- data.frame(shp,sexcc,gdim,ages,delt,nclone,Size1cm*nclone^(1/gdim),-log(2)/log(prob),prob,pext)
names(pef200) <- headline
str(pef200)

pef <- rbind(pef50,pef100,pef200)
table(pef$sizecm)

# plot file saving
ffname <- paste("pext",mde,sep = "-")
ffname <- paste(ffname,fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
#setwd(statdir)
#setwd("pext")
#save(pef, file = fsavname)
