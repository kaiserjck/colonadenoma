#----------------------------------------------
# adeno OE analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)
library(forcats)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-------------------------------------------
# directory structure
#-------------------------------------------

shp <- character()
#shp <- "all"
#shp <- "flat"
#shp <- "sessile"
shp <- "peduncular"

sexc <- character()
#sexc <- "m"
sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K0"
#mmname <- "K1app"
mmname <- "K2"

# likelihood
likc <- character()
likc <- "permut"
#likc <- "dist"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,"-atrend",sep="") # age trend version

#-------------------------------------------------------------
# prepare observed data
#-------------------------------------------------------------
patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    df0$ymin <- 40
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ys <- df0$ys2d
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ys <- df0$ys3d
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}
#df0$yhi[df0$sizecat == ">2"] <- -1

# set detection limit boundaries for preferred models
{
  if (mdv == "pref"){
    if (shp == "sessile" | shp == "all") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
#    else if (shp == "peduncular") {
#      df0$ylo[df0$ylo == 50] <- 40
#      df0$ymin[df0$ymin == 50] <- 40}  
  }
}

df0 <- droplevels(df0)

df <- df0

ad <- subset(df0, shape != "none")

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
dim(sigma)[1]
sigma[1,2] <- sigma[2,1]
if(dim(sigma)[1] == 3)
{
 sigma[1,3] <- sigma[3,1]
 sigma[2,3] <- sigma[3,2]
}
if(dim(sigma)[1] == 4)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
}
if(dim(sigma)[1] == 5)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
  sigma[1,5] <- sigma[5,1]
  sigma[2,5] <- sigma[5,2]
  sigma[3,5] <- sigma[5,3]
  sigma[4,5] <- sigma[5,4]
}
cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov

if (all(1 == sign(eigen(sigma)$values)) == TRUE)
#if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
apply(Z,2,mean)
#apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

df.par[1:10,]

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-permut.R")

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.hyp
    Thelohi <- theta_lohi_K2.hyp
  }
  else
  {
    print("Not implemented\n")
  }
  
  if (likc == "bina"){
    Padeno <- Padeno_bin
  }
  else{
    Padeno <- Padeno_N
  }
}

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
upar <- dpar$parval
#upar[4] <- 0
#upar[5] <- 0
#upar[6] <- 0

#--------------------------------
# model predictions
#--------------------------------
# adenoma size
#--------------------------------
df <- subset(df0, sizecat != "<DL")
df <- droplevels(df)

df$sizecat <- fct_relevel(df$sizecat, "<0.5","0.5-1","1-2",">2")
df$countcat <- fct_relevel(df$countcat, "1","2-4",">=5")

sage.sum <- aggregate(df$age*df$npat, list(df$sizecat,df$countcat,df$agecat), sum, drop = F)
snpat.sum <- aggregate(df$npat, list(df$sizecat,df$countcat,df$agecat), sum, drop = F)
snpat.sum[is.na(snpat.sum)] <- 0
sage.mean <- sage.sum$x/snpat.sum$x
#ylo.sum <- aggregate(df$ylo*df$npat, list(df$sizecat,df$countcat,df$agecat), sum, drop = F)
#ylo.mean <- ylo.sum$x/snpat.sum$x
ylo.uni <- aggregate(df$ylo, list(df$sizecat,df$countcat,df$agecat), unique, drop = F)
ylo.uni$x[ylo.uni$Group.1 == "<0.5"] <- ylo.uni$x[ylo.uni$Group.1 == "<0.5" & ylo.uni$Group.3 == "55-59"]
ylo.uni$x[ylo.uni$Group.1 == "0.5-1"] <- ylo.uni$x[ylo.uni$Group.1 == "0.5-1" & ylo.uni$Group.3 == "55-59"]
ylo.uni$x[ylo.uni$Group.1 == "1-2"] <- ylo.uni$x[ylo.uni$Group.1 == "1-2" & ylo.uni$Group.3 == "55-59"]
ylo.uni$x[ylo.uni$Group.1 == ">2"] <- ylo.uni$x[ylo.uni$Group.1 == ">2" & ylo.uni$Group.3 == "55-59"]
#yhi.sum <- aggregate(df$yhi*df$npat, list(df$sizecat,df$countcat,df$agecat), sum, drop = F)
#yhi.mean <- yhi.sum$x/snpat.sum$x
yhi.uni <- aggregate(df$yhi, list(df$sizecat,df$countcat,df$agecat), unique, drop = F)
yhi.uni$x[yhi.uni$Group.1 == "<0.5"] <- yhi.uni$x[yhi.uni$Group.1 == "<0.5" & yhi.uni$Group.3 == "55-59"]
yhi.uni$x[yhi.uni$Group.1 == "0.5-1"] <- yhi.uni$x[yhi.uni$Group.1 == "0.5-1" & yhi.uni$Group.3 == "55-59"]
yhi.uni$x[yhi.uni$Group.1 == "1-2"] <- yhi.uni$x[yhi.uni$Group.1 == "1-2" & yhi.uni$Group.3 == "55-59"]
yhi.uni$x[yhi.uni$Group.1 == ">2"] <- yhi.uni$x[yhi.uni$Group.1 == ">2" & yhi.uni$Group.3 == "55-59"]

spno.sum <- aggregate(df$npat*df$pno, list(df$sizecat,df$countcat,df$agecat), sum, drop = F)
spno.sum[is.na(spno.sum)] <- 0
spno.sum$x/snpat.sum$x

psz <- data.frame(sage.sum$Group.1,sage.sum$Group.2,sage.sum$Group.3,snpat.sum$x,spno.sum$x,sage.mean,ylo.uni$x,yhi.uni$x)
names(psz) <- c("Size","Counts","AgeGroup","Npat","Npno","age","ylo","yhi")
psz
dim(psz) # 84 8
psz.org <- psz
aggregate(psz.org$Npno,list(psz.org$AgeGroup),sum)

# disentangle size categories
# create new data frames
#levels(x)[levels(x)=="beta"] <- "two"

psz.1.1 <- subset(psz, Size == "0.5-1" & Counts == "2-4")
levels(psz.1.1$Size)[levels(psz.1.1$Size) == "0.5-1"] <- "<1"
psz.1.1$Npno <- psz.1.1$Npat
psz.1.1$ylo <- gb.ymin

psz.1.2 <- subset(psz, Size == "0.5-1" & Counts == ">=5")
levels(psz.1.2$Size)[levels(psz.1.2$Size) == "0.5-1"] <- "<1"
psz.1.2$Npno <- 4*psz.1.2$Npat
psz.1.2$ylo <- gb.ymin  

psz.2.1 <- subset(psz, Size == "1-2" & Counts == "2-4")
levels(psz.2.1$Size)[levels(psz.2.1$Size) == "1-2"] <- "<2"
psz.2.1$Npno <- psz.2.1$Npat
psz.2.1$ylo <- gb.ymin

psz.2.2 <- subset(psz, Size == "1-2" & Counts == ">=5")
levels(psz.2.2$Size)[levels(psz.2.2$Size) == "1-2"] <- "<2"
psz.2.2$Npno <- 4*psz.2.2$Npat
psz.2.2$ylo <- gb.ymin

psz.3.1 <- subset(psz, Size == ">2" & Counts == "2-4")
levels(psz.3.1$Size)[levels(psz.3.1$Size) == ">2"] <- "any"
psz.3.1$Npno <- psz.3.1$Npat
psz.3.1$ylo <- gb.ymin

psz.3.2 <- subset(psz, Size == ">2" & Counts == ">=5")
levels(psz.3.2$Size)[levels(psz.3.2$Size) == ">2"] <- "any"
psz.3.2$Npno <- 4*psz.3.2$Npat
psz.3.2$ylo <- gb.ymin

# reduce Npat in Count classess
psz$Npno[psz$Size != "<0.5" & psz$Counts == "2-4"] <- psz$Npat[psz$Size != "<0.5" & psz$Counts == "2-4"]
psz$Npno[psz$Size != "<0.5" & psz$Counts == ">=5"] <- psz$Npat[psz$Size != "<0.5" & psz$Counts == ">=5"]

psz.extd <- rbind(psz,psz.1.1,psz.1.2,psz.2.1,psz.2.2,psz.3.1,psz.3.2)
dim(psz.extd) # 124 8  

psz.extd

# check if adenoma counts are conserved
aggregate(psz.extd$Npno,list(psz.extd$AgeGroup),sum)
aggregate(psz.org$Npno,list(psz.org$AgeGroup),sum)

# remove aggregate categories
psz.red <- subset(psz.extd, Size == "<0.5" | Size == "0.5-1" | Size == "1-2" | Size == ">2")
psz.red

# build columns of new data frame with size distribution
sepno.sum <- aggregate(psz.red$Npno,list(psz.red$Size,psz.red$AgeGroup), sum)
seage.sum <- aggregate(psz.red$age*psz.red$Npat,list(psz.red$Size,psz.red$AgeGroup), sum)
senpat.sum <- aggregate(psz.red$Npat, list(psz.red$Size,psz.red$AgeGroup), sum)
seage.mean <- seage.sum$x/senpat.sum$x
yelo.sum <- aggregate(psz.red$ylo*psz.red$Npat, list(psz.red$Size,psz.red$AgeGroup), sum)
yelo.mean <- yelo.sum$x/senpat.sum$x
yehi.sum <- aggregate(psz.red$yhi*psz.red$Npat, list(psz.red$Size,psz.red$AgeGroup), sum)
yehi.mean <- yehi.sum$x/senpat.sum$x

#psz.n <- data.frame(seage.sum$Group.1,seage.sum$Group.2,senpat.sum$x,sepno.sum$x,seage.mean,yelo.mean,yehi.mean)
psz.red.c <- data.frame(seage.sum$Group.1,seage.sum$Group.2,senpat.sum$x,sepno.sum$x,seage.mean,yelo.mean,yehi.mean)
names(psz.red.c) <- c("Size","AgeGroup","Npat","Npno","age","ylo","yhi")
psz.red.c
psz.red.c <- droplevels(psz.red.c)

# measured frequencies in age groups and size categories
npat.agrp <- aggregate(psz.red.c$Npat, list(psz.red.c$AgeGroup), sum)
npno.agrp <- aggregate(psz.red.c$Npno, list(psz.red.c$AgeGroup), sum)

help1 <- split(psz.red.c, psz.red.c$AgeGroup)
nlevels <- length(levels(psz.red.c$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- npat.agrp$x[i] 
  help1[[i]]$Npno_agrp <- npno.agrp$x[i] 
  n3 <- npno.agrp$x[i] - help1[[i]]$Npno[4]
  n2 <- npno.agrp$x[i] - help1[[i]]$Npno[4] - help1[[i]]$Npno[3]
  help1[[i]]$Npno_3 <- n3 
  help1[[i]]$Npno_3[4] <- 0
  help1[[i]]$Npno_2 <- n2
  help1[[i]]$Npno_2[3] <- 0
  help1[[i]]$Npno_2[4] <- 0
  help1[[i]]$MScat <- help1[[i]]$Npno/npno.agrp$x[i] 
  help1[[i]]$MScat_3 <- help1[[i]]$Npno/n3
  help1[[i]]$MScat_3[4] <- 0
  help1[[i]]$MScat_2 <- help1[[i]]$Npno/n2
  help1[[i]]$MScat_2[3] <- 0
  help1[[i]]$MScat_2[4] <- 0
}     

psz.h1 <- help1[[1]]
for (i in 2:nlevels){
  psz.h1 <- rbind(psz.h1,help1[[i]])
}
psz.h1

#-----------------------------------------------------
# split aggregate Npno into size categories
#-----------------------------------------------------
psz.2 <- subset(psz.extd, Size == "<1")
psz.3 <- subset(psz.extd, Size == "<2")
psz.a <- subset(psz.extd, Size == "any")

n.2 <- aggregate(psz.2$Npno, list(psz.2$AgeGroup),sum)$x
n.3 <- aggregate(psz.3$Npno, list(psz.3$AgeGroup),sum)$x
n.a <- aggregate(psz.a$Npno, list(psz.a$AgeGroup),sum)$x

# hack1: add zeros in oldest age category
l2 <- length(n.2)
l3 <- length(n.3)
la <- length(n.a)
lvec <- c(l2,l3,la)
isComplete <- all(nlevels-1 <= lvec) # check if at least nlevels-1 age categories present
isComplete
{
  if (l2 == (nlevels-1)){
    n.2[nlevels] <- 0
  }
  if (l3 == (nlevels-1)){
    n.3[nlevels] <- 0
  }
  if (la == (nlevels-1)){
    n.a[nlevels] <- 0
  }
}  


help2 <- split(psz.h1, psz.h1$AgeGroup)
nlevels <- length(levels(psz.h1$AgeGroup))
for(i in 1:nlevels){
  help2[[i]]$Napno_2_1 <- as.integer(help2[[i]]$MScat_2[1]*n.2[i]+.5)
  help2[[i]]$Napno_2_2 <- as.integer(help2[[i]]$MScat_2[2]*n.2[i]+.5)
  help2[[i]]$Napno_3_1 <- as.integer(help2[[i]]$MScat_3[1]*n.3[i]+.5)
  help2[[i]]$Napno_3_2 <- as.integer(help2[[i]]$MScat_3[2]*n.3[i]+.5)
  help2[[i]]$Napno_3_3 <- as.integer(help2[[i]]$MScat_3[3]*n.3[i]+.5)
  help2[[i]]$Napno_4_1 <- as.integer(help2[[i]]$MScat[1]*n.a[i]+.5)
  help2[[i]]$Napno_4_2 <- as.integer(help2[[i]]$MScat[2]*n.a[i]+.5)
  help2[[i]]$Napno_4_3 <- as.integer(help2[[i]]$MScat[3]*n.a[i]+.5)
  help2[[i]]$Napno_4_4 <- as.integer(help2[[i]]$MScat[4]*n.a[i]+.5)
}

psz.h2 <- help2[[1]]
for (i in 2:nlevels){
  psz.h2 <- rbind(psz.h2,help2[[i]])
}

psz.h2

#-----------------------------------------------------
# aggregate split Npno to size categories <0.5,..., >2
#-----------------------------------------------------
help3 <- split(psz.h2, psz.h2$AgeGroup)
nlevels <- length(levels(psz.h2$AgeGroup))
for(i in 1:nlevels){
  help3[[i]]$Napno_agg_1 <- help3[[i]]$Napno_2_1 + help3[[i]]$Napno_3_1 + help3[[i]]$Napno_4_1
  help3[[i]]$Napno_agg_1[2:4] <- 0
  help3[[i]]$Napno_agg_2 <- help3[[i]]$Napno_2_2 + help3[[i]]$Napno_3_2 + help3[[i]]$Napno_4_2
  help3[[i]]$Napno_agg_2[c(1,3,4)] <- 0
  help3[[i]]$Napno_agg_3 <- help3[[i]]$Napno_3_3 + help3[[i]]$Napno_4_3
  help3[[i]]$Napno_agg_3[c(1,2,4)] <- 0
  help3[[i]]$Napno_agg_4 <- help3[[i]]$Napno_4_4
  help3[[i]]$Napno_agg_4[1:3] <- 0
  help3[[i]]$Npno_add <- help3[[i]]$Napno_agg_1 + help3[[i]]$Napno_agg_2 + help3[[i]]$Napno_agg_3 + help3[[i]]$Napno_agg_4
  help3[[i]]$Npno_new <- help3[[i]]$Npno + help3[[i]]$Npno_add
}

psz.h3 <- help3[[1]]
for (i in 2:nlevels){
  psz.h3 <- rbind(psz.h3,help3[[i]])
}
psz.h3
names(psz.h3)

psz.n <- psz.h3[,c("Size","AgeGroup","age","ylo","yhi","Npno","Npno_add","Npno_new")]

npno.agrp <- aggregate(psz.n$Npno_new, list(psz.n$AgeGroup), sum)

help4 <- split(psz.n, psz.n$AgeGroup)
nlevels <- length(levels(psz.n$AgeGroup))
for(i in 1:nlevels){
  help4[[i]]$Npno_agrp <- npno.agrp$x[i] 
}
psz <- help4[[1]]
for (i in 2:nlevels){
  psz <- rbind(psz,help4[[i]])
}
names(psz) <- c("Size","AgeGroup","age","ylo","yhi","Npno_pur","Npno_add","Npno","Npno_agrp")
psz

# check for errors
checksum <- sum(abs(aggregate(psz.org$Npno,list(psz.org$AgeGroup),sum)$x-aggregate(psz$Npno,list(psz$AgeGroup),sum)$x))

psz <- psz[complete.cases(psz), ]
dim(psz)

# model predictions
# expectation value
lbd <- ENad(psz$age,upar,gb.ymin) 
# probabilities
# size category
pdim <- dim(psz)[1]
PScat <- unlist(lapply(1:pdim, function(i) Thelohi(psz$age[i],upar,psz$ylo[i],psz$yhi[i])/lbd[i]))

psz <- data.frame(psz,lbd,PScat)
psz$MScat <- psz$Npno/psz$Npno_agrp
psz$posdev <- -2*(dpois(psz$Npno,psz$PScat*psz$Npno_agrp, log = TRUE)-dpois(psz$Npno,psz$Npno, log = TRUE))

aggregate(psz$MScat, list(psz$AgeGroup), sum)
aggregate(psz$PScat, list(psz$AgeGroup), sum)

psz

# Poisson deviance for size cats
sposdev <- sum(psz$posdev)
sposdev 
dim(psz)[1]

#--------------------------------
# adenoma counts
#--------------------------------
df <- df0
#df$prevcat <- 0
#df$prevcat[df$countcat != "0"] <- 1
#df$prevcat <- factor(df$prevcat, levels = c(0,1), labels = c("no","yes"))
#table(df$prevcat,df$countcat)

cage.sum <- aggregate(df$age*df$npat, list(df$countcat,df$agecat), sum)
cage.len <- aggregate(df$npat, list(df$countcat,df$agecat), sum)
cage.mean <- cage.sum$x/cage.len$x

cnpat.sum <- aggregate(df$npat, list(df$countcat,df$agecat), sum)
cnpno.sum <- aggregate(df$npat*df$pno, list(df$countcat,df$agecat), sum)
cnpno.sum$x/cnpat.sum$x

pct <- data.frame(cage.sum$Group.1,cage.sum$Group.2,cnpat.sum$x,cnpno.sum$x,cage.mean)
names(pct) <- c("Count","AgeGroup","Npat","Npno","age")
pct
dim(pct) # 28 5
pdim <- dim(pct)[1]

# check age group normalization
#aggregate(pct$PNcat,list(pct$AgeGroup),sum)

# measured frequencies in age groups
cnpat.agrp <- aggregate(pct$Npat, list(pct$AgeGroup), sum)
cnpno.agrp <- aggregate(pct$Npno, list(pct$AgeGroup), sum)
help1 <- split(pct, pct$AgeGroup)
nlevels <- length(levels(pct$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- cnpat.agrp$x[i] 
  help1[[i]]$Npno_agrp <- cnpno.agrp$x[i]
}
pcf <- help1[[1]]
for (i in 2:nlevels){
  pcf <- rbind(pcf,help1[[i]])
}

# model predictions
# expectation value
lbd <- ENad(pct$age,upar,gb.ymin) 
# probabilities
PNcat <- unlist(lapply(1:pdim, function(i) Padeno(pct$Count[i],lbd[i]))) # count category


pcf <- data.frame(pcf,lbd)
pcf$ENad <- pcf$Npno_agrp/pcf$Npat_agrp
pcf <- data.frame(pcf,PNcat)
pcf$MNcat <- pcf$Npat/pcf$Npat_agrp

pcf$posdev <- -2*(dpois(pcf$Npat,pcf$PNcat*pcf$Npat_agrp, log = TRUE)-dpois(pcf$Npat,pcf$Npat, log = TRUE))
#pcf$posdev <- -2*(sum(dpois(pcf$Npno,pcf$PNcat*pcf$Npno_agrp, log = TRUE))-sum(dpois(pcf$Npno,pcf$Npno, log = TRUE)))
pcf

pcf.0 <- subset(pcf, Count == "0")

# Poisson deviance for count cats
cposdev <- sum(pcf.0$posdev)
cposdev

#----------------------------------------------------------
# Final results
#----------------------------------------------------------
{
  nlevels <- length(levels(psz$AgeGroup))
  if (checksum > nlevels){
    cat(sprintf("ERROR: Checksum %2d exceeds nlevels %2d\n", checksum, nlevels))
  } else {
    cat(sprintf("NOTE : Checksum %2d <= nlevels %2d ok\n", checksum, nlevels))
  }
  if (isComplete == F){
    cat(sprintf("ERROR: incomplete age categories\n"))
  }
}
cat(sprintf("fname '%s' with model version '%s' at gb.min %2d\n", fname, mdv, gb.ymin))
cat(sprintf("Npat %d, NPatAd %d, MeanAdno %6.3f\n", sum(pcf$Npat), sum(pcf$Npat[pcf$Count != "0"]), 
            sum(psz$Npno)/sum(pcf$Npat[pcf$Count != "0"])))
cat(sprintf("PosDev size: %6.1f counts: %6.1f, both: %6.1f\n", sposdev, cposdev, sposdev+cposdev))


