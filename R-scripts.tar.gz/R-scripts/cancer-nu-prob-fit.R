#----------------------------------------------
# adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#--------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)
library(corrplot)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-----------------------------------------------------------------------------
# read data
#-----------------------------------------------------------------------------
setwd(datdir)
load(file = "nu65fit-canag-20220215.Rdata")
#cf <- subset(cf, chaz > 0)
#names(cf)[1] <- "Shape"
#names(cf)[2] <- "Sex"
#cf$Sex[cf$Sex == "w"] <- "women"
#cf$Sex[cf$Sex == "m"] <- "men"
#cf$mage[cf$Shape == "flat"] <- cf$mage[cf$Shape == "flat"] - 1
#cf$mage[cf$Shape == "peduncular"] <- cf$mage[cf$Shape == "peduncular"] + 1
cf$Sex <- fct_rev(cf$Sex)
cf$pyr10k <- cf$pyr*1e-4
#names(cf)[5] <- "cases"
cf
#--------------------------------
# fitting simple descriptive models
#--------------------------------
af <- cf
af$lage65 <- log(af$mage/65)
# Attention: parametric byr, cyr models are dangerous
desc.0 <- glm(cases ~ lage65 + Sex + Shape, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.0) # AIC: 180.15
#summary(desc.0,corr=T)
desc.1 <- glm(cases ~ lage65, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.1) # AIC: 339

desc.2 <- glm(cases ~ sizecm, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.2) # AIC: 296.05

desc.3 <- glm(cases ~ Shape:(lage65+sizecm), family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.3) # AIC: 168.99

desc.4 <- glm(cases ~ Sex:Shape + lage65 - 1, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.4) # AIC: 171.01

desc.5 <- glm(cases ~ Sex:(sizecm + lage65), family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.5) # AIC: 172.58
#--------------------------------------------
# statistical analysis of descriptive models
#--------------------------------------------
#assign desc for statistical analysis
desc <- desc.3

# Npar
length(desc$coefficients)
# Poisson deviance
desc$aic - 2*length(desc$coefficients)
# Poisson, alternative method
rpos <- -dpois (cf$cases, predict (desc, type = "response"), log = TRUE)
2*sum(rpos)

# residual deviance
rd <- residuals(desc,type="deviance") 
sum (rd^2)

# dispersion parameter from Pearson residuals
rp <- residuals(desc,type="pearson")
sum(rp^2)/df.residual(desc)

# plot CIs from likelihood profile
confint(desc)

#--------------------------------
# TSCE model
#--------------------------------
tsce0 <- function(X0, gam0, del0) 
{ 
  age <- df$mage
  pyr <- df$pyr
  
  X <- exp(X0)
  gamma <- gam0
  d <- exp (del0)
  q <- 0.5*(sqrt(gamma^2+4*d)-gamma)
  
  haz0 <- X * (exp((gamma+2*q)*age)-1)/(gamma + q*(exp((gamma+2*q)*age)+1)) 
  
  return (pyr*haz0)
}
#-----------------------------------------------------
# age dependence of effective transformation rate nu_eff
#-----------------------------------------------------
nueffa <- function(nu0, nuAge) 
{ 
  age <- df$mage
  pyr <- df$pyr
  eCell <- df$eCell_0
  
  acen <- (age-65)/10

  hazard <- eCell*exp(nu0+nuAge*acen)

  return (pyr * hazard)
}

#----------------------------------------------------------
# Poisson fit
#----------------------------------------------------------
s.m <- subset(cf, Sex == "m" & Shape == "sessile")
s.m.p <- subset(cf,  Sex == "m" & Shape == "sessile" & agecat == "55-59")
s.w <- subset(cf, Sex == "w" & Shape == "sessile" )
s.w.p <- subset(cf,  Sex == "w" & Shape == "sessile" & agecat == "55-59")

p.m <- subset(cf, Sex == "m" & Shape == "peduncular")
p.m.p <- subset(cf,  Sex == "m" & Shape == "peduncular")
p.w <- subset(cf, Sex == "w" & Shape == "peduncular")
p.w.p <- subset(cf,  Sex == "w" & Shape == "peduncular")

f.m <- subset(cf, Sex == "m" & Shape == "flat")
f.m.p <- subset(cf,  Sex == "w" & Shape == "flat" & agecat == "55-59")
f.w <- subset(cf, Sex == "w" & Shape == "flat")
f.w.p <- subset(cf,  Sex == "w" & Shape == "flat" & agecat == "55-59")

df <- subset(cf, Sex == "w")
df.p <- s.m.p

upar <- vector()
upar[1] <- log(df.p$nu65)
upar[2] <- df.p$cacen
lambda <- nueffa (nu0 = upar[1], nuAge = upar[2])
#lambda
-2*sum(dpois (df$cases, lambda, log = TRUE))

mle.1 <- mle2(cases ~ dpois (lambda = nueffa(nu0, nuAge)), 
              start=list(nu0 = upar[1], nuAge = upar[2]), 
              parameters=list(nu0~1, nuAge~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.1)
AIC(mle.1)

# likelihood profiles
prf <- profile(mle.1)
plot(prf)
confint(prf)

# AIC
rn <- sum(dpois (df$cases, df$cases, log = TRUE))
npar <- length(coef(mle.1,exclude.fixed=T))
rd <- -2*(as.numeric(logLik(mle.1)) - rn)
rd
AICrd <- rd + 2*npar
AICrd

# Pearson residuals
res <- residuals(mle.1,type="pearson")
degf <- length(df$cases) - npar
pres <- sum(res^2)/degf
pres

#s.m <- df
#s.w <- df
#p.m <- df
#p.w <- df
#f.m <- df
#f.w <- df

#cf.new <- rbind(s.m,s.w,p.m,p.w,f.m,f.w)
#cf <- cf.new

#setwd(datdir)
#save(cf, file = "nu65fit-canag-20220215.Rdata")

# TSCE
tpar <- vector()
tpar[1] <- -15.54549
tpar[2] <- 0.05536532
tpar[3] <- -9.242768
mle.2 <- mle2(cases ~ dpois (lambda = tsce0(X0, gam0, del0)), 
              start=list(X0 = tpar[1], gam0 = tpar[2], del0 = tpar[3]), 
              parameters=list(X0~1, gam0~1, del0~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.2)
AIC(mle.2)

# likelihood profiles
prf <- profile(mle.2)
plot(prf)
confint(prf)

# AIC
rn <- sum(dpois (df$cases, df$cases, log = TRUE))
npar <- length(coef(mle.2,exclude.fixed=T))
rd <- -2*(as.numeric(logLik(mle.2)) - rn)
rd
AICrd <- rd + 2*npar
AICrd

# Pearson residuals
res <- residuals(mle.2,type="pearson")
degf <- length(df$cases) - npar
pres <- sum(res^2)/degf
pres

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
#sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names
sigma <- data.matrix(vcov(mle.1))

cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
pr <- coef(mle.1)

if (all(1 == sign(eigen(sigma)$values)) == TRUE)
  #if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
apply(Z,2,mean)
apply(Z,2,sd)

ages <- seq(60,70,1)
ndim <- length(ages)
numn <- vector()
nudist <- list()
nulo <- vector()
nuhi <- vector()
for (i in 1:ndim)
{
  acen <- (ages[i]-65)/10
  numn[i] <- exp(coef(mle.1)[1] + coef(mle.1)[2]*acen)
  nudist[[i]] <- exp(Z[,1] + Z[,2]*acen)
  nulo[i] <- quantile(nudist[[i]], probs = 0.025)
  nuhi[i] <- quantile(nudist[[i]], probs = 0.975)
}

#--------------------------------------------------------------------
# cancer probability
#--------------------------------------------------------------------
setwd(datdir)
load("prob55_85-can.Rdata")
prb

s.m <- subset(prb, sexc == "m" & shp == "sessile")
s.w <- subset(prb, sexc == "w" & shp == "sessile" )

p.m <- subset(prb, sexc == "m" & shp == "peduncular")
p.w <- subset(prb, sexc == "w" & shp == "peduncular")

f.m <- subset(prb, sexc == "m" & shp == "flat")
f.w <- subset(prb, sexc == "w" & shp == "flat")

ysess <- c(50,200,800,3200)
ypedu <- c(13,50,200,800)
yflat <- c(50,400,3200,25600)

pn.s.m <- vector()
pn.s.w <- vector()
pn.p.m <- vector()
pn.p.w <- vector()
pn.f.m <- vector()
pn.f.w <- vector()
for(i in 1: length(ysess)){
  pn.s.m <- ysess[4]*s.m$hCell*exp(-ysess[4]*s.m$hCum)
  pn.s.w <- ysess[4]*s.w$hCell*exp(-ysess[4]*s.w$hCum)
  pn.p.m <- ypedu[4]*p.m$hCell*exp(-ypedu[4]*p.m$hCum)
  pn.p.w <- ypedu[4]*p.w$hCell*exp(-ypedu[4]*p.w$hCum)
  pn.f.m <- yflat[4]*f.m$hCell*exp(-yflat[4]*f.m$hCum)
  pn.f.w <- yflat[4]*f.w$hCell*exp(-yflat[4]*f.w$hCum)
}



