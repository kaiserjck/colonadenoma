#----------------------------------------------
# adeno model fits
# jck, 2021/05/18
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
#shp <- "flat"
shp <- "sessile"
#shp <- "peduncular"

setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20210518.Rdata")
    df0 <- sadenoPG} 
  else if (shp == "sessile") {
    load(file = "sessPG-20210518.Rdata")
    df0 <- sess}
  else if (shp == "flat") {
    load(file = "flatPG-20210518.Rdata")
    df0 <- flat}
  else if (shp == "peduncular") {
    load(file = "peduPG-20210518.Rdata")
    df0 <- pedu}
}

df0$acen <- (df0$age-65)/10

ymin <- 50
{
  if (shp == "peduncular")
  {
    df0$ys1d <- 0
    #df0$ys1d[df0$sizecat == "<0.5"] <- 100
    df0$ys1d[df0$sizecat == "0.5-1"] <- 100
    df0$ys1d[df0$sizecat == "1-2"] <- 400
    df0$ys1d[df0$sizecat == ">2"] <- 1600

    df0$ylo1d <- 0
    #df0$ys1d[df0$sizecat == "<0.5"] <- 100
    df0$ylo1d[df0$sizecat == "0.5-1"] <- ymin
    df0$ylo1d[df0$sizecat == "1-2"] <- 100
    df0$ylo1d[df0$sizecat == ">2"] <- 200
  }
  else if (shp == "sessile" | shp == "flat")
  {
    df0$ys1d <- 0
    #df0$ys1d[df0$sizecat == "<0.5"] <- 100
    df0$ys1d[df0$sizecat == "0.5-1"] <- 100
    df0$ys1d[df0$sizecat == "1-2"] <- 400
    df0$ys1d[df0$sizecat == ">2"] <- 1600
    
    df0$ylo1d <- 0
    #df0$ys1d[df0$sizecat == "<0.5"] <- 100
    df0$ylo1d[df0$sizecat == "0.5-1"] <- ymin
    df0$ylo1d[df0$sizecat == "1-2"] <- 200
    df0$ylo1d[df0$sizecat == ">2"] <- 800
  }
}
{
  if (shp == "all") {
    adenoPG <- df0
    df0 <- adenoPG
    save(adenoPG, file = "adenoPG-20210608.Rdata")} 
  else if (shp == "sessile") {
    sess <- df0
    save(adenoPG, file = "sessPG-20210608.Rdata")}
  else if (shp == "flat") {
    flat <- df0
    save(adenoPG, file = "flatPG-20210608.Rdata")}
  else if (shp == "peduncular") {
    pedu <- df0
    save(adenoPG, file = "peduPG-20210608.Rdata")}
}

