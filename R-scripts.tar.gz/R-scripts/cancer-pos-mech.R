#----------------------------------------------
# cancer analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#--------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)
library(corrplot)
library(forcats)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#--------------------------------
# TSCE model
#--------------------------------
tsce0 <- function(X0, gam0, del0) 
{ 
  age <- df$mage
  pyr <- df$pyr
  
  X <- exp(X0)
  gamma <- gam0
  d <- exp (del0)
  q <- 0.5*(sqrt(gamma^2+4*d)-gamma)
  
  haz0 <- X * (exp((gamma+2*q)*age)-1)/(gamma + q*(exp((gamma+2*q)*age)+1)) 
  
  return (pyr*haz0)
}

#---------------------------------------------------------------
# 4sce
#---------------------------------------------------------------
# Meza et al. PNAS 2008, supplement
oneminusS2 <- function(u,t,rho,gam,del)
{
  srt <- sqrt(gam^2 + 4*del)
  p <- -0.5*(srt + gam)
  q <- 0.5*(srt - gam)
  dage <- (t-u)
  func <- (q-p)/(q*exp(-p*dage) - p*exp(-q*dage))
  
  return(1 - func^rho)
}

# cases for hybrid 4SCE model
c4sce0 <- function(X0, rho0, gam0, del0) 
{ 
  age <- df$mage
  pyr <- df$pyr
  # integrate 1-S2 Meza et al. PNAS 2008, supplement
  ndim <- length(age)
  intfunc <- vector()
  #  for(i in 1:ndim)
  #  {intfunc[i] <- integrate(oneminusS2, lower = 0, upper = age[i], t = age[i], rho=r_b, gam=g_b, del=exp(d_b))$value}
  intfunc <- unlist(lapply(1:ndim, 
                           function(i) integrate(oneminusS2, lower = 0, upper = age[i], t = age[i], 
                                                 rho=exp(rho0), gam=gam0, del=exp(del0))$value))
  #cat(sprintf("byrX: %f, cyrX: %f, X: %g, rho: %f, gam: %f, del: %g\n", byrX, cyrX, X, r_b, g_b, d_b))
  hazard <- exp(X0) * intfunc 
  return (pyr * hazard)
}

#-----------------------------------------------------------------------------
# read data
#-----------------------------------------------------------------------------
setwd(datdir)
load(file = "canag-20220614.Rdata")
head(df.canag)
str(df.canag)

# prepare subset
cf <- df.canag
cf <- subset(cf, Shape != "all" & agecat != "total" & Sex != "b")
cf$Sex[cf$Sex == "w"] <- "women"
cf$Sex[cf$Sex == "m"] <- "men"

#cf$Sex <- fct_rev(cf$Sex)
cf$pyr10k <- cf$pyr*1e-4
names(cf)[5] <- "cases"
cf
cf$Shape <- fct_relevel(cf$Shape, "sessile","peduncular","flat")
table(cf$Sex,cf$Shape)
#--------------------------------
# fitting simple descriptive models
#--------------------------------
af <- cf
af$lage65 <- log(af$mage/65)

desc.0 <- glm(cases ~ lage65 + Sex + Shape, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.0) # AIC: 161.41, Residual deviance:  18.524  on 37  degrees of freedom
#summary(desc.0,corr=T)
desc.1 <- glm(cases ~ lage65 + Sex, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.1) # AIC: 272.73

# sizecm: size of cancers
desc.2 <- glm(cases ~ lage65 + Sex + sizecm, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.2) # AIC: 253.96

desc.3 <- glm(cases ~ lage65 + Sex + Shape:sizecm, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.3) # AIC: 171.15, (4 observations deleted due to missingness), 
# Residual deviance:  26.265  on 32  degrees of freedom

desc.4 <- glm(cases ~ Sex:(sizecm + lage65) - 1, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.4) # AIC: 274.16, (4 observations deleted due to missingness)

desc.5 <- glm(cases ~ Sex:(Shape + lage65) - 1, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.5) # AIC: 166.4, Residual deviance:  17.516  on 34  degrees of freedom
#--------------------------------------------
# statistical analysis of descriptive models
#--------------------------------------------
#assign desc for statistical analysis
desc <- desc.0

# Npar
length(desc$coefficients)
# Poisson deviance
desc$aic - 2*length(desc$coefficients)
# Poisson, alternative method
rpos <- -dpois (af$cases, predict (desc, type = "response"), log = TRUE)
2*sum(rpos)

# residual deviance
rd <- residuals(desc,type="deviance") 
sum (rd^2)

# dispersion parameter from Pearson residuals
rp <- residuals(desc,type="pearson")
sum(rp^2)/df.residual(desc)

# plot CIs from likelihood profile
confint(desc)

#----------------------------------------------------------
# Poisson fit
#----------------------------------------------------------
cf <- df.canag
cf$pyr10k <- cf$pyr*1e-4
names(cf)[5] <- "cases"

a.m <- subset(cf, Sex == "m" & Shape == "all" & agecat != "total")
a.m.alp <- 11.693846195
a.w <- subset(cf, Sex == "w" & Shape == "all" & agecat != "total")
a.w.alp <- 10.045259484

s.m <- subset(cf, Sex == "m" & Shape == "sessile" & agecat != "total")
s.m.alp <- 4.6722524
s.w <- subset(cf, Sex == "w" & Shape == "sessile" & agecat != "total")
s.w.alp <- 0.9561774

p.m <- subset(cf, Sex == "m" & Shape == "peduncular" & agecat != "total")
p.m.alp <- 33.104989
p.w <- subset(cf, Sex == "w" & Shape == "peduncular" & agecat != "total")
p.w.alp <- 48.300343

f.m <- subset(cf, Sex == "m" & Shape == "flat" & agecat != "total")
f.m.alp <- 55.18283
f.w <- subset(cf, Sex == "w" & Shape == "flat" & agecat != "total")
f.w.alp <- 30.9454
f.b <- subset(cf, Sex == "b" & Shape == "flat" & agecat != "total")
f.b.alp <- (f.m.alp + f.w.alp)/2

df <- s.w
alpha <- s.w.alp

#---------------------------------------------------
# TSCE
#--------------------------------------------------
tpar <- vector()
tpar[1] <- -15.54549
tpar[2] <- 0.05536532
tpar[3] <- -9.242768
mle.2 <- mle2(cases ~ dpois (lambda = tsce0(X0, gam0, del0)), 
              start=list(X0 = tpar[1], gam0 = tpar[2], del0 = tpar[3]), 
              parameters=list(X0~1, gam0~1, del0~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.2)
AIC(mle.2)

# AIC
rn <- sum(dpois (df$cases, df$cases, log = TRUE))
npar <- length(coef(mle.2,exclude.fixed=T))
rd <- -2*(as.numeric(logLik(mle.2)) - rn)
rd
AICrd <- rd + 2*npar
AICrd

# Pearson residuals
res <- residuals(mle.2,type="pearson")
degf <- length(df$cases) - npar
pres <- sum(res^2)/degf
pres

#
#prf <- profile(mle.2)
#plot(prf)
#confint(prf)

delta <- coef(mle.2)[3]
nuTSCE <- exp(as.numeric(delta))/alpha
nuTSCE

#---------------------------------------------------
# 4SCE
#--------------------------------------------------
tpar <- vector()
tpar[1] <- -2.381826
tpar[2] <-  -7.1593
tpar[3] <- 0.108880
tpar[4] <- -14.6669
mle.3 <- mle2(cases ~ dpois (lambda = c4sce0(X0, rho0, gam0, del0)), 
              start=list(X0 = tpar[1], rho0 = tpar[2], gam0 = tpar[3], del0 = tpar[4]), 
              parameters=list(X0~1, rho0~1, gam0~1, del0~1),
              #fixed=list(rho0 = tpar[2], gam0 = tpar[3], del0 = tpar[4]),
              method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.3)
AIC(mle.3)

tpar <- coef(mle.3)

# AIC
rn <- sum(dpois (df$cases, df$cases, log = TRUE))
npar <- length(coef(mle.3,exclude.fixed=T))
rd <- -2*(as.numeric(logLik(mle.3)) - rn)
rd
AICrd <- rd + 2*npar
AICrd

# Pearson residuals
res <- residuals(mle.3,type="pearson")
degf <- length(df$cases) - npar
pres <- sum(res^2)/degf
pres

#
#prf <- profile(mle.3)
#plot(prf)
#confint(prf)

delta <- coef(mle.3)[4]
nu4SCE <- exp(as.numeric(delta))/alpha
nu4SCE

