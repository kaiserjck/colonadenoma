#----------------------------------------------
# adeno model fits
# complete data with nones
# jck, 2022/05/20
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------

#-------------------------------------------------------------
# libraries
#-------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)
# GAMs
library(mgcv)
# parallelisation
library(parallel)
library(doParallel)
library(foreach)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
shp <- "flat"
#shp <- "sessile"
#shp <- "peduncular"

noad <- character()
#noad <- "wN0"
noad <- "noN0"

patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}


sexc <- character()
#sexc <- "m"
sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K0"
mmname <- "K1app"

meth <- character()
meth <- "analytic"
#meth <- "sum" # summation
#meth <- "hyp" # hypergeometric function

# likelihood
likc <- character()
likc <- "posize"
#likc <- "dist"

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,"-atrend",sep="") # standard version

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
ymin <- unique(df$ylo[df$sizecat == "<0.5"])
df$ymin <- ymin
df <- droplevels(df)

# calculate df$npat_age
ad <- df

#npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum, drop=FALSE)
#npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum)
npat_size_age <- aggregate(ad$npat, list(factor(ad$age),ad$sizecat), sum)
#npat_size_age$x[is.na(npat_size_age$x) == T] <- 0
#age_sum <- aggregate(ad$npat*ad$age, list(ad$agecat,ad$sizecat), sum)
age_sum <- aggregate(ad$npat*ad$age, list(factor(ad$age),ad$sizecat), sum)
age_mean <- age_sum$x/npat_size_age$x
#ylo_uni <- aggregate(ad$ylo, list(ad$agecat,ad$sizecat), unique)
#yhi_uni <- aggregate(ad$yhi, list(ad$agecat,ad$sizecat), unique)
#ymin_uni <- aggregate(ad$ymin, list(ad$agecat,ad$sizecat), unique)
ylo_uni <- aggregate(ad$ylo, list(factor(ad$age),ad$sizecat), unique)
yhi_uni <- aggregate(ad$yhi, list(factor(ad$age),ad$sizecat), unique)
ymin_uni <- aggregate(ad$ymin, list(factor(ad$age),ad$sizecat), unique)

df.h <- data.frame(age_mean,(age_mean-65)/10,npat_size_age,ylo_uni$x,yhi_uni$x,ymin_uni$x)

#npat_age <- aggregate(ad$npat, list(ad$agecat), sum)
npat_age <- aggregate(ad$npat, list(factor(ad$age)), sum)
help1 <- split(df.h, df.h$Group.1)
nlevels <- length(levels(df.h$Group.1))
for(i in 1:nlevels){
  help1[[i]]$npat_age <- npat_age$x[i]
}
df.r <- help1[[1]]
for (i in 2:nlevels){
  df.r <- rbind(df.r,help1[[i]])
}
#df.r <- data.frame(df.h)
dim(df.r)
names(df.r) <- c("age","acen","agecat","sizecat","npat","ylo","yhi","ymin","npat_age")
aggregate(df.r$npat,list(df.r$agecat),sum)

df <- df.r

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(ad)[1]))
cat(sprintf("   All Npat: %d\n", sum(df$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(ad$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))
#----------------------------------------------------------
# likelihood regression
#----------------------------------------------------------
setwd(subdir)
{
  if (likc == "posize"){source("posizeK0K1K2atrend-permut.R")}
}

# parallelisation
#registerDoSEQ()
#getDoParWorkers()
#cl <- makeCluster(detectCores()-1)
#registerDoParallel(cl)
#clusterExport(cl, c("fAlpha0","fGamma0","fX0","td_sinteg_Gg_K0","td_sint_pn_K0","td_ainteg_Gg_K0","td_pn_K0_int"))
#getDoParWorkers() 

{ # this bracket is needed!
  if (mmname == "K0")
  {
    sdeviance <- sdevianceK0
    smloglik <- smloglikK0
    snloglik <- snloglikK0
  }
  else if (mmname == "K1app")
  {
    sdeviance <- sdevianceK1.app
    smloglik <- smloglikK1.app
    snloglik <- snloglikK1.app
  }
  else
  {
    print("Not implemented\n")
  }
}

# controls CI printing
has.profile <- FALSE
has.Hessian <- FALSE

#setwd(gstdpardir)
#setwd(pardir)
#parDF <- read.csv ("sessile-m-2d-K1app-posize-std_parms.csv")

setwd(dir)
setwd("./stats/saveparms")
parDF <- read.csv ("flat-w-2d-K1app-posize-std_parms.csv")

# skip X0
#npar <- length(as.numeric(parDF$parval))
#zpar <- vector()
#zpar <- as.numeric(parDF$parval)
upar <- vector()
#upar <- zpar[2:npar]
upar <- as.numeric(parDF$parval)
upar[3] <- 0
upar
#setwd(dir)
#setwd("./stats/bparms-grid/std/all/2d/K0/")
#parDF <- read.csv ("all-w-2d-K0-permut-std_parms.csv")
#npar <- length(as.numeric(parDF$parval))
#parDF <- read.csv ("sessile/3d/K0/sessile-all-w-3d-K0-dist-std_parms.csv")
#setwd(pardir)
#parDF <- read.csv ("all-w-2d-K1app-dist-std_parms.csv")
#zpar <- vector()
#zpar <- as.numeric(parDF$parval)
#upar <- vector()
#upar <- zpar[2:npar]
#upar
#upar[1] <- 0.1
#upar[2] <- 10
#upar[3] <- 0.05
#upar[1] <- upar[1]*upar[4]*upar[2]
#upar[1] <- upar[1]*1e-4*upar[2]

#---------------------------------------------------------------
# scoping calculations with nlminb
#---------------------------------------------------------------
mpar <- vector()
mpar <- upar[1:3]

#df0 <- df # save
#df <- subset(df0, pno == 5)
#df <- subset(df0, shape == "none")
#df1
#df <- df[1,] # select
#df # show
#df <- df0 # restore
mmcall <- 0
2*snloglik(mpar)

# model fit
par <- vector()
par <- mpar
mmcall <- 0
for (iter in 1:2)
{
  nlm.mdl <- nlminb(start = par, objective = snloglik, 
                    lower = c(1,-1,-0.5),
                    upper = c(3000,0.2,0.5)
  )
  par <- nlm.mdl$par
  nlm <- nlm.mdl
}

nlm$convergence
# deviance 
2*nlm.mdl$objective
# AIC
2*nlm.mdl$objective + 2*length(nlm.mdl$par)
# best estimate deviation
round((nlm.mdl$par - mpar)/mpar * 100,2)
# deviance difference
#round(2*nlm.mdl$objective - deviance(mle.1)[1],2)
# parameter
nlm.mdl$par

# calculation of Wald-based stdev, p-values and CI from Jonathan Gessendorfer
# Hessian matrix
mmcall <- 0
mdl_hessian <- hessian(func = snloglik, x = nlm.mdl$par)
has.Hessian <- is.positive.definite(mdl_hessian, tol=1e-8)
has.Hessian
upar <- as.numeric(nlm.mdl$par)

# covariance & correlation matrix
covm <- solve(mdl_hessian)
# test of positive definiteness
all(1 == sign(eigen(covm)$values))
cov2cor(covm)

# stdev for parameters (Wald-based)
stdev <- sqrt(diag(ginv(mdl_hessian)))

# z-transformation (t-value)
zval <- nlm.mdl$par/stdev

# p-value
pval <- 2*pnorm(-abs(zval))

# parameter CI 
upper <- nlm.mdl$par + qnorm(.975)*stdev
lower <- nlm.mdl$par - qnorm(.975)*stdev

# plot table
sum_tbl <- cbind(nlm.mdl$par, stdev, zval, pval, lower, upper)
colnames(sum_tbl) <- c("Estimate", "Std. Error", "z value", "Pr(>|z|)", "95% CI: LB", "95% CI: UB")
print(sum_tbl,digits = 4) 

#---------------------------------------------------------------
# final fitting with bbmle
#---------------------------------------------------------------

npar <- length(upar[upar != 0])
system.time(
  dev <- sdeviance(upar[1], upar[2], upar[3], df)
  )
dev 
dev+2*npar

# optimisation
mmcall = 0
durat<- system.time(
mle.1 <- mle2(minuslog = smloglik,
              start=list(alp = upar[1], gam = upar[2], ba = upar[3]), 
              parameters=list(alp~1, gam~1, ba~1), 
              fixed=list(
              alp = upar[1]
              #gam = upar[2]
              #ba = upar[3]
              ),
              lower = c(gam = -1, ba = -0.5),
              upper = c(gam = 0.2, ba = 0.5),
              #lower = c(alp = 1, gam = -1, ba = -0.5),
              #upper = c(alp = 2000, gam = 0.2, ba = 0.5),
              #lower = c(ba = -0.1),
              #upper = c(ba = 0.1),
              #lower = c(X0 = .001, gam = -0.1),
              #upper = c(X0 = 100, gam = 0.15),
              #lower = c(X0 = 0.005, alp = 3, gam =  0.02),
              #upper = c(X0 = 10, alp = 100, gam = 0.1),
              method = "L-BFGS-B",
              #method = "CG",
              #method = "Brent",
              data = df)
) # system.time
durat

cat(sprintf("Total calls: %d", mmcall))

summary(mle.1)
AIC(mle.1)

# deviance difference
round(dev - deviance(mle.1)[1],2)

# correlation matrix
#is.positive.definite(vcov(mle.1),tol = 1e-5)
cov2cor(vcov(mle.1))

rm <- round(vcov(mle.1),6)
#rm <- round(covm,6)
#eigen(covm)
#all(1 == sign(eigen(vcov(mle.1))$values))
#all(1 == sign(eigen(rm)$values))
is.positive.definite(vcov(mle.1), tol = 1e-10)
isPD <- all(1 == sign(eigen(vcov(mle.1))$values)) # check if all eigenvalues > 0
isPD

#park <- mle.1
#mle.1 <- park

upar <- coef(mle.1)

#deviance(mle.1)[1] - dev0

# likelihood profile and confidence intervals
mmcall = 0
pl <- profile(mle.1)
plot(pl)
#coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)
has.profile <- TRUE
#---------------------------------------------------------------
# write model parameters to file
#---------------------------------------------------------------
setwd(pardir)
parms <- data.frame (coef(mle.1))
names(parms)[c(1)] <- c("parval")
parms_adj <- data.frame(coef(mle.1,exclude.fixed=TRUE))
names(parms_adj)[c(1)] <- c("parval")

is.fixed <- !row.names(parms) %in% row.names(parms_adj) # create vector denoting fixed parameters 
fixpar <- data.frame (coef(mle.1)[is.fixed]) # fixed coefficients
names(fixpar)[c(1)] <- c("parval")

all(row.names(parms) %in% row.names(parms_adj))

ffname <- fname
f1 <- paste(ffname,"_parms.csv",sep="")
f2 <- paste(ffname,"_vcov.csv",sep="")
f3 <- paste(ffname,"_protocol.txt",sep="")

# parameters
write.csv(parms, file = f1, quote = F)

# covariance matrix
if (isPD == TRUE)
{
  cat(sprintf("--> write covariance matrix\n"))
  write.csv(vcov(mle.1), file = f2, quote = F)
  #  write.csv(vcov(mle.1), file = f2, quote = F)
}

# protocol
# start writing to file
sink(f3)

# write items
cat(sprintf("\n--> Model run: %s <-- using method: %s\n", ffname, meth))
cat(sprintf("    Data set: %s\n", patdata))
cat(sprintf("    All Npat: %d\n", sum(df$npat)))
cat(sprintf("    Mean age: %6.3f yr\n", sum(df$npat*df$age)/sum(df$npat)))
cat(sprintf("  Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf(" Mean Ad age: %6.3f yr\n", sum(ad$npat*ad$age)/sum(ad$npat)))
cat(sprintf("   Free Npat: %d\n", sum(df$npat)-sum(ad$npat)))
cat(sprintf("      MeanAd: %6.3f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("      MeanSz: %6.3f cm\n", sum(ad$size*ad$npat)/sum(ad$npat)))
cat(sprintf("\n Detection limit (Lnd spacing)\n          smin: %6.3f cm\n          ymin: %6d cells\n", gb.smin, gb.ymin))
cat(sprintf("       Sizecat:   ylo\n"))
for(i in 1:gb.nsc)
{cat(sprintf("       '%5s': %5d\n", levels(df$sizecat)[i], gb.ylo[i]))}
cat(sprintf("\n"))
summary(mle.1)

savpar <- coef(mle.1)
npar <- length(savpar[savpar != 0])
dev <- sdeviance(savpar[1], savpar[2], savpar[3], df)
oAIC <- dev+2*npar
#cat(sprintf("deviance: %8.1f\n", dev))
cat(sprintf("     AIC: %7.1f\n", oAIC))
cat(sprintf("isPosDef: %s\n", isPD))
{ # print 95% CI if available
  if (has.profile == TRUE)
  {
    cat(sprintf("\nLikelihood profile CI\n"))
    print(lp.CI)
  }
}
cat(sprintf("\n"))

if (all(row.names(parms) %in% row.names(parms_adj)) == FALSE)
{cat(sprintf("Fixed coefficients\n"))
  print(fixpar)}
if (all(row.names(parms) %in% row.names(parms_adj)) == FALSE){cat(sprintf("\n"))}

#cat(sprintf("\n"))
cat(sprintf(" Total calls:  %4d\n", mmcall))
eltime <- as.numeric(durat[3])/60
cat(sprintf("Elapsed time: %6.2f min\n    per call: %6.2g sec\n",eltime, eltime*60/mmcall)) 
cat(sprintf("   Timestamp: %s", Sys.time()))

# stop writing to file
sink()
    