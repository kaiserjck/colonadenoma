#----------------------------------------------
# test K1.app vs. K1.sum functions
# jck, 2021/08/31
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
# libraries
#library(gsl) # for hypergeometric function 2F1
#library(hypergeo) # for hypergeometric function 2F1
#library(BMS) # for hypergeometric function 2F1
#-------------------------------------------
# directory structure
#-------------------------------------------

one_minus_azeta <- function (s1,alp,gam,age)
{
  dage <- age - s1
  
  bet <- alp-gam
  
  zaehler <- exp(gam*dage) - 1
  nenner <- alp*exp(gam*dage) - bet
  zet <- zaehler/nenner
  
  return (1-alp*zet)
}

# functions for exact K1
# integrated sum of p_n(s,t)
# interchange of summation and integration
sum_pn <- function(s1,age,alp,gam,rho,y0)
{
  nind <- seq(0,y0,1)
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  sumbi <- vector()
  sumbi <- unlist(lapply(1:ndim, function(i) sum(dnbinom(nind,rho,one_minus_azeta(agei[i],alp,gam,age)))))
  return (sumbi)
}

intsum_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- integrate(sum_pn, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  
  return (t - P_y0) # integrated p_1^(1)(s1,t)
}

ainteg_Gg_K1.app <- function (s1, age, alp, gam, n)
{
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)
  return (s1*f2*(f1^n)) # linear age dependence on s1 in approximation
}

# vectorizable with lapply
pn_K1.app <- function (t,alp,gam,ymin) 
{
  ndim <- length(t)
  pnK1 <- vector()
  pnK1 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(ainteg_Gg_K1.app, lower = 0, upper = t[i], age = t[i], alp, gam, n = ymin)$value))
  return (pnK1)
}

personal_deviance_sum <- function(X0,alp,gam,rho,df)
{
  ages <- df$ages
  y0 <- df$y0
  yl <- df$yl
  yh <- df$yh
  pno <- df$pno
  npat <- df$npat
  
  lnP0 <- -X0*intsum_pn_K1(ages,alp,gam,rho,y0)
  
  p_pat <- intsum_pn_K1(ages,alp,gam,rho,yl)
  p_pat_ot <- intsum_pn_K1(ages,alp,gam,rho,y0)
  if (yh > -1)
  {
    p_pat <- p_pat-intsum_pn_K1(ages,alp,gam,rho,yh)
    p_pat_ot <- p_pat_ot-intsum_pn_K1(ages,alp,gam,rho,yh)
  }
  p_pat <- X0*p_pat
  p_pat_ot <- X0*p_pat_ot
  
  sino <- 0
  if (pno > 0) {sino <- (pno-1)*log(p_pat_ot) + log(p_pat)} # pno = 0,1,2,5; 0 for "none" not used
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0)
  return(-2*lnlik)
  
}

personal_deviance_app <- function(X0, alp, gam, df)
{
  ages <- df$ages
  y0 <- df$y0
  yl <- df$yl
  yh <- df$yh
  pno <- df$pno
  npat <- df$npat
  
  lnP0 <- -X0*pn_K1.app(ages,alp,gam,y0) 
  
  p_pat <- pn_K1.app(ages,alp,gam,yl)
  p_pat_ot <- pn_K1.app(ages,alp,gam,y0)
  if (yh > -1)
  {
    p_pat <- p_pat-pn_K1.app(ages,alp,gam,yh)
    p_pat_ot <- p_pat_ot-pn_K1.app(ages,alp,gam,yh)
  }
  p_pat <- X0*p_pat
  p_pat_ot <- X0*p_pat_ot
  
  sino <- 0
  if (pno > 0) {sino <- (pno-1)*log(p_pat_ot) + log(p_pat)} # pno = 0,1,2,5; 0 for "none" not used
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0)
  
  return (-2*lnlik)
}

#-----------------------------------
# parameters
#-----------------------------------
upar <- vector()
upar[1] <- 0.20966045
upar[2] <- 72.89139
upar[3] <- 0.02104299
#upar[4] <- 0.00810083
upar[4] <- 1e-4

X0 <- upar[1]
alp <- upar[2]
gam <- upar[3]
rho = upar[4]
X0app <- X0*alp*rho
#-----------------------------------------
# patient data
#-----------------------------------------
s1 <- 0
ages <- 69
y0 <- 50
yl <- 0
yh <- 0
pno <- 0
npat <- 2775
nvec <- seq(0,y0,1)

df <- data.frame(ages,y0,yl,yh,pno,npat)
df

#-----------------------------------------
# check of K1.app vs exact K1.sum functions
#-----------------------------------------

psum <- 1-sum_pn(s1,ages,alp,gam,rho,y0)
papp <- rho*alp*ainteg_Gg_K1.app(s1,ages,alp,gam,y0)
psum
papp
(papp - psum)/psum*100

pisum <- intsum_pn_K1(ages,alp,gam,rho,y0)
piapp <- rho*alp*pn_K1.app(ages,alp,gam,y0) 
piapp
pisum
(piapp - pisum)/pisum*100

pd_sum <- personal_deviance_sum(X0,alp,gam,rho,df)
pd_app <- personal_deviance_app(X0app,alp,gam,df)
pd_sum
pd_app
(pd_app - pd_sum)/pd_sum*100
  
  



