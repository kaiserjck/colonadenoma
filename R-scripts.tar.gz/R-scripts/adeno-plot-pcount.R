#----------------------------------------------
# plot adeno pcount analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="xpcount-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
pcf
headline <- c("Sex","Source","Count","AgeGroup","Age","Npno","Npat","eNad","share")
pf.w.md <- data.frame ("women","M",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(pf.w.md) <- headline
pf.w.ms <- data.frame ("women","S",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(pf.w.ms) <- headline

load(file="xpcount-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
pcf
pf.m.md <- data.frame ("men","M",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(pf.m.md) <- headline
pf.m.ms <- data.frame ("men","S",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(pf.m.ms) <- headline

# build and adjust pf
pf <- rbind(pf.w.md,pf.w.ms,pf.m.md,pf.m.ms)
pf$Source <- fct_rev(pf$Source)
#pf <- subset(pf, AgeGroup != ">84")
pf <- droplevels(pf)
summary(pf)
setwd(plotdir)

fp.1 <- ggplot(data = pf, aes(x=Count, y=share*100, fill = Source)) + 
  ggtitle("peduncular") + 
  geom_bar(stat="identity", position="dodge", width = 0.8) +
  geom_text(aes(x=Count, y=share*100, label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  geom_text(aes(x = 3.6, y = 70, label = sprintf("Npat = %d", Npat))) +
  #geom_text(aes(x = 2.9, y = 0.7, label = sprintf("N = %d", Npat))) +
  #geom_errorbar(aes(ymin=share.lo, ymax=share.hi), width=.2, position=position_dodge(.8)) +
  scale_fill_manual(values = myPalette) +
  xlab("Adenoma count") +
  facet_grid(AgeGroup ~ Sex) + 
  #facet_grid(.~AgeGroup) + 
  #scale_x_discrete(limits = levels(pf$Size), breaks = levels(pf$Size)) +
  #scale_y_continuous(name="Share in age group (%)", labels = scales::percent, limits=c(0,1.1), breaks = seq(0,1,0.5)) +
  scale_y_continuous(name="Share in age group (%)", limits=c(0,115), breaks = seq(0,100,50)) +
  #  scale_color_manual(values=cbbPalette[3:5]) +
  guides(fill=FALSE) + 
  theme(text = element_text(size=12)) 
#  + theme_bw()  # use a white background
print(fp.1)

pf$Countrev <- fct_rev(pf$Count)
legend_title <- "Source"
fp.2 <- ggplot(data=pf, aes(y= eNad, x = AgeGroup, color=Source)) +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  #geom_bar(stat="identity", position = "fill", width = 0.8) + 
  geom_point(size = 3) + 
  facet_grid (Sex ~ .) +
  scale_y_continuous(name="Mean number of adenoma") +
  scale_color_manual(values=cbPalette[c(1:3,8)]) +
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15)) 
print(fp.2)
