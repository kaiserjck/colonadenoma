#----------------------------------------------
# plot adeno pcount analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="xpcount-flat-all-w-3d-K2-dist-atrend.Rdata")
pcf
headline <- c("Sex","Source","Shape","Count","AgeGroup","Age","Npno","Npat","eNad","share")
f.w.md <- data.frame ("women","M","flat",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(f.w.md) <- headline
f.w.ms <- data.frame ("women","S","flat",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(f.w.ms) <- headline

load(file="xpcount-flat-all-m-3d-K2-dist-atrend.Rdata")
pcf
f.m.md <- data.frame ("men","M","flat",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(f.m.md) <- headline
f.m.ms <- data.frame ("men","S","flat",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(f.m.ms) <- headline

load(file="xpcount-sessile-all-w-2d-K2-dist-atrend.Rdata")
pcf
s.w.md <- data.frame ("women","M","sessile",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(s.w.md) <- headline
s.w.ms <- data.frame ("women","S","sessile",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(s.w.ms) <- headline

load(file="xpcount-sessile-all-m-2d-K2-dist-atrend.Rdata")
pcf
s.m.md <- data.frame ("men","M","sessile",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(s.m.md) <- headline
s.m.ms <- data.frame ("men","S","sessile",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(s.m.ms) <- headline

load(file="xpcount-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
pcf
p.w.md <- data.frame ("women","M","peduncular",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(p.w.md) <- headline
p.w.ms <- data.frame ("women","S","peduncular",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(p.w.ms) <- headline

load(file="xpcount-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
pcf
p.m.md <- data.frame ("men","M","peduncular",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$eNad,pcf$pNcat)
names(p.m.md) <- headline
p.m.ms <- data.frame ("men","S","peduncular",pcf$Count,pcf$AgeGroup,pcf$age,pcf$Npno_agrp,pcf$Npat_agrp,pcf$sNad,pcf$sNcat)
names(p.m.ms) <- headline

# build and adjust pf
pf <- rbind(s.w.md,s.w.ms,s.m.md,s.m.ms,p.w.ms,p.m.md,p.m.ms,p.w.md,f.w.md,f.w.ms,f.m.md,f.m.ms)
pf$Source <- fct_rev(pf$Source)
#pf <- subset(pf, AgeGroup != ">84")
pf <- droplevels(pf)
summary(pf)
setwd(plotdir)

pf$Countrev <- fct_rev(pf$Count)
pf$Shaperev <- fct_rev(pf$Shape)
pf$Sexrev <- fct_rev(pf$Sex)
pf <- subset(pf, Count == "1")
legend_title <- "Shape"
fp.1 <- ggplot(data=pf, aes(y= eNad, x = AgeGroup, color = Shaperev, shape = Source)) +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  #geom_bar(stat="identity", position = "fill", width = 0.8) + 
  geom_point(size = 4) + 
  facet_grid (Sexrev ~ .) +
  scale_y_continuous(name="Mean number of adenoma", limits = c(0,0.6), breaks = seq(0,0.6,0.1)) +
  scale_color_manual(legend_title, values=cbPalette[c(4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  xlab ("Age group (yr)") + 
  scale_shape_manual(values = c(21, 16)) +
  guides(shape = F) +
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.18,0.9)) 
print(fp.1)
