#----------------------------------------------
# cancer analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#--------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)
library(corrplot)
library(forcats)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-----------------------------------------------------------------------------
# read data
#-----------------------------------------------------------------------------
setwd(datdir)
load(file = "canag-ecell-20220615.Rdata")
head(ecf.canag)
str(ecf.canag)

# prepare subset
cf <- ecf.canag
cf <- subset(cf, Shape != "all" & agecat != "total")
cf$Sex[cf$Sex == "w"] <- "women"
cf$Sex[cf$Sex == "m"] <- "men"

#cf$Sex <- fct_rev(cf$Sex)
cf$pyr10k <- cf$pyr*1e-4
names(cf)[5] <- "cases"
cf <- subset(cf, Shape != "flat,3d")
cf
cf$Shape <- fct_relevel(cf$Shape, "sessile","peduncular","flat")
table(cf$Sex,cf$Shape)

#--------------------------------
# fitting simple descriptive models
#--------------------------------
af <- cf
af$lage65 <- log(af$mage/65)

desc.0 <- glm(cases ~ lage65 + Sex + Shape, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.0) # AIC: 161.41, Residual deviance:  18.524  on 37  degrees of freedom
#summary(desc.0,corr=T)
desc.1 <- glm(cases ~ lage65 + Sex, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.1) # AIC: 272.73

# sizecm: size of cancers
desc.2 <- glm(cases ~ lage65 + Sex + sizecm, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.2) # AIC: 253.96

desc.3 <- glm(cases ~ lage65 + Sex + Shape:sizecm, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.3) # AIC: 171.15, (4 observations deleted due to missingness), 
# Residual deviance:  26.265  on 32  degrees of freedom

desc.4 <- glm(cases ~ Sex:(sizecm + lage65) - 1, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.4) # AIC: 274.16, (4 observations deleted due to missingness)

desc.5 <- glm(cases ~ Sex:(Shape + lage65) - 1, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.5) # AIC: 166.4, Residual deviance:  17.516  on 34  degrees of freedom
#--------------------------------------------
# statistical analysis of descriptive models
#--------------------------------------------
#assign desc for statistical analysis
desc <- desc.0

# Npar
length(desc$coefficients)
# Poisson deviance
desc$aic - 2*length(desc$coefficients)
# Poisson, alternative method
rpos <- -dpois (af$cases, predict (desc, type = "response"), log = TRUE)
2*sum(rpos)

# residual deviance
rd <- residuals(desc,type="deviance") 
sum (rd^2)

# dispersion parameter from Pearson residuals
rp <- residuals(desc,type="pearson")
sum(rp^2)/df.residual(desc)

# plot CIs from likelihood profile
confint(desc)

#--------------------------------------------------
# fitting nu(age)
#--------------------------------------------------

nueffa <- function(nu0, nuAge) 
{ 
  age <- df$mage
  pyr <- df$pyr
  eCell <- df$eCad
  
  acen <- (age-65)/10

  hazard <- eCell*exp(nu0+nuAge*acen)

  return (pyr * hazard)
}

#----------------------------------------------------------
# Poisson fit
#----------------------------------------------------------
cf <- ecf.canag
cf <- subset(cf, agecat != "total")
str(cf)
names(cf)[5] <- "cases"
cf$Shape <- fct_relevel(cf$Shape, "sessile","peduncular","flat","flat,3d")
table(cf$Sex,cf$Shape)

a.m <- subset(cf, Sex == "m" & Shape == "all")
a.w <- subset(cf, Sex == "w" & Shape == "all")

s.m <- subset(cf, Sex == "m" & Shape == "sessile")
s.w <- subset(cf, Sex == "w" & Shape == "sessile")

p.m <- subset(cf, Sex == "m" & Shape == "peduncular")
p.w <- subset(cf, Sex == "w" & Shape == "peduncular")

f.m <- subset(cf, Sex == "m" & Shape == "flat")
f.w <- subset(cf, Sex == "w" & Shape == "flat")

f.m.3d <- subset(cf, Sex == "m" & Shape == "flat,3d")
f.w.3d <- subset(cf, Sex == "w" & Shape == "flat,3d")

#df<-a.m 
#df<-a.w 
#df<-s.m 
#df<-s.w 
#df<-p.m 
#df<-p.w 
#df<-f.m 
#df<-f.w
#df<-f.m.3d 
df<-f.w.3d 

upar <- vector()
upar[1] <- log(5e-6)
upar[2] <- 0.5
lambda <- nueffa (nu0 = upar[1], nuAge = upar[2])
#lambda
-2*sum(dpois (df$cases, lambda, log = TRUE))

mle.1 <- mle2(cases ~ dpois (lambda = nueffa(nu0, nuAge)), 
              start=list(nu0 = upar[1], nuAge = upar[2]), 
              parameters=list(nu0~1, nuAge~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.1)
AIC(mle.1)

round((upar[1] - coef(mle.1)[1])/coef(mle.1)[1]*100,1)
round((upar[2] - coef(mle.1)[2])/coef(mle.1)[2]*100,1)

# AIC
rn <- sum(dpois (df$cases, df$cases, log = TRUE))
npar <- length(coef(mle.1,exclude.fixed=T))
rd <- -2*(as.numeric(logLik(mle.1)) - rn)
rd
AICrd <- rd + 2*npar
AICrd

# Pearson residuals
res <- residuals(mle.1,type="pearson")
degf <- length(df$cases) - npar
pres <- sum(res^2)/degf
pres

#
prf <- profile(mle.1)
plot(prf)
confint(prf)

cov2cor(vcov(mle.1))
df$nu65 <- exp(coef(mle.1)[1])
df$cacen <- coef(mle.1)[2]

#a.m <- df
#a.w <- df
#s.m <- df
#s.w <- df
#p.m <- df
#p.w <- df
#f.m <- df
#f.w <- df
#f.m.3d <- df
f.w.3d <- df

cf.new <- rbind(a.m,a.w,s.m,s.w,p.m,p.w,f.m,f.w,f.m.3d,f.w.3d)
cf <- cf.new

setwd(datdir)
save(cf, file = "nuAgeFit-canag-ecell-20220616.Rdata")
