#----------------------------------------------
# plot extinction probability
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
#setwd("pext")

load(file="pext-60_70-sessile-w-2d-K2-permut-atrend.Rdata")
s.w <- pef
load(file="pext-60_70-sessile-m-2d-K2-permut-atrend.Rdata")
s.m <- pef

#load(file="pext-60_70-flat-w-3d-K2-permut-atrend.Rdata")
load(file="pext-delT0p01-60_70-flat-w-3d-K2-permut-atrend.Rdata")
pef$Shape <- "flat,3d"
f.3d.w <- pef
load(file="pext-60_70-flat-m-3d-K2-permut-atrend.Rdata")
pef$Shape <- "flat,3d"
f.3d.m <- pef
load(file="pext-60_70-flat-w-2d-K2-permut-atrend.Rdata")
pef$Shape <- "flat,2d"
f.2d.w <- pef
load(file="pext-60_70-flat-m-2d-K2-permut-atrend.Rdata")
pef$Shape <- "flat,2d"
f.2d.m <- pef

load(file="pext-60_70-peduncular-w-2d-K2-permut-atrend.Rdata")
p.w <- pef
load(file="pext-60_70-peduncular-m-2d-K2-permut-atrend.Rdata")
p.m <- pef

# build and adjust pf
# age group data
pf <- rbind(s.w,s.m,f.3d.w,f.3d.m,f.2d.w,f.2d.m,p.w,p.m)
pf$sizeLabel <- "0.25 cm"
pf$sizeLabel[pf$sizecm >  0.375] <- "0.5 cm"
pf$sizeLabel[pf$sizecm > 0.75] <- "1 cm"
pf$sizeLabel[pf$sizecm > 1.5 ] <- "2 cm"
table(pf$sizecm)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular","flat,2d", "flat,3d"))
summary(pf)
pf <- subset(pf, sizecm < 1.5)
table(pf$sizecm,pf$Shape)
pf <- droplevels(pf)

setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = age, y = pext*100, color = Shape, linetype = sizeLabel), size = 1) + 
  facet_grid(Sex ~ .) +
  scale_x_continuous(name = "Age (yr)", limits = c(60,70), breaks = seq(60,70,5)) +
  scale_y_continuous(name = "Extinction probability (%)", limits = c(0,100), breaks = seq(0,100,25)) +
  scale_color_manual(values=cbPalette[c(4,7,2,3)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape="none", linetype = "none") + 
  theme(text = element_text(size=15),legend.position = c(0.75,0.9)) 
print(fp.1)

# remove peduncular = 0.25 cm
pf.0 <- subset(pf, sizecm > 0.375)
pf.1 <- subset(pf, sizecm < 0.375 & Shape != "peduncular")
pf <- rbind(pf.0,pf.1)
str(pf)
pf <- droplevels(pf)
fp.2 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = age, y = pext*100, color = Shape), size = 1) + 
  facet_grid(Sex ~ sizeLabel) +
  scale_x_continuous(name = "Age (yr)", limits = c(60,70), breaks = seq(60,70,5)) +
  scale_y_continuous(name = "Extinction probability (%)", limits = c(0,100), breaks = seq(0,100,20)) +
  scale_color_manual(values=cbPalette[c(4,7,2,3)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  #guides(shape="none", linetype = "none", color = "none") + 
  theme(text = element_text(size=15),legend.position = c(0.8,0.75)) 
print(fp.2)

#library(cowplot)
#plot_grid(fp.2,fp.1,nrow = 2)
