#----------------------------------------------
# adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#--------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)
library(corrplot)
library(forcats)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-----------------------------------------------------------------------------
# read data
#-----------------------------------------------------------------------------
setwd(datdir)
load(file = "nuAgeFit-canag-ecell-20220616.Rdata")
#setwd(resdir)
#write.csv(cf,file = "cancer-nu.csv", sep = ",")
#cf <- subset(cf, chaz > 0)
#names(cf)[1] <- "Shape"
#names(cf)[2] <- "Sex"
#cf$Sex[cf$Sex == "w"] <- "women"
#cf$Sex[cf$Sex == "m"] <- "men"
#cf$mage[cf$Shape == "flat"] <- cf$mage[cf$Shape == "flat"] - 1
#cf$mage[cf$Shape == "peduncular"] <- cf$mage[cf$Shape == "peduncular"] + 1
cf$Sex <- fct_rev(cf$Sex)
cf$pyr10k <- cf$pyr*1e-4
#names(cf)[5] <- "cases"
cf
#--------------------------------------------------------------------
# cancer probability
#--------------------------------------------------------------------
setwd(curvdir)
load("prob60_70-can.Rdata")
prb
prb$acen <- (prb$ages-65)/10
prb$dacen <- (prb$delt-65)/10

a.m.p <- subset(cf, Sex == "m" & Shape == "all" & agecat == "55-59")
a.w.p <- subset(cf, Sex == "w" & Shape == "all" & agecat == "55-59")
s.m.p <- subset(cf, Sex == "m" & Shape == "sessile" & agecat == "55-59")
s.w.p <- subset(cf, Sex == "w" & Shape == "sessile" & agecat == "55-59")
p.m.p <- subset(cf, Sex == "m" & Shape == "peduncular" & agecat == "55-59")
p.w.p <- subset(cf, Sex == "w" & Shape == "peduncular" & agecat == "55-59")
f.m.p <- subset(cf, Sex == "m" & Shape == "flat" & agecat == "55-59")
f.w.p <- subset(cf, Sex == "w" & Shape == "flat" & agecat == "55-59")

a.m <- subset(prb, sexc == "m" & shp == "all")
a.m$ttfNu <- (a.m$eCell_0*exp(a.m.p$cacen*a.m$acen) - a.m$DeCell_0*exp(a.m.p$cacen*a.m$dacen))/
  (a.m$eCell_0[1]*exp(a.m.p$cacen*a.m$acen[1]))
a.w <- subset(prb, sexc == "w" & shp == "all" )
a.w$ttfNu <- (a.w$eCell_0*exp(a.w.p$cacen*a.w$acen) - a.w$DeCell_0*exp(a.w.p$cacen*a.w$dacen))/
  (a.w$eCell_0[1]*exp(a.w.p$cacen*a.w$acen[1]))

s.m <- subset(prb, sexc == "m" & shp == "sessile")
s.m$ttfNu <- (s.m$eCell_0*exp(s.m.p$cacen*s.m$acen) - s.m$DeCell_0*exp(s.m.p$cacen*s.m$dacen))/
  (s.m$eCell_0[1]*exp(s.m.p$cacen*s.m$acen[1]))
s.w <- subset(prb, sexc == "w" & shp == "sessile" )
s.w$ttfNu <- (s.w$eCell_0*exp(s.w.p$cacen*s.w$acen) - s.w$DeCell_0*exp(s.w.p$cacen*s.w$dacen))/
  (s.w$eCell_0[1]*exp(s.w.p$cacen*s.w$acen[1]))

p.m <- subset(prb, sexc == "m" & shp == "peduncular")
p.m$ttfNu <- (p.m$eCell_0*exp(p.m.p$cacen*p.m$acen) - p.m$DeCell_0*exp(p.m.p$cacen*p.m$dacen))/
  (p.m$eCell_0[1]*exp(p.m.p$cacen*p.m$acen[1]))
p.w <- subset(prb, sexc == "w" & shp == "peduncular")
p.w$ttfNu <- (p.w$eCell_0*exp(p.w.p$cacen*p.w$acen) - p.w$DeCell_0*exp(p.w.p$cacen*p.w$dacen))/
  (p.w$eCell_0[1]*exp(p.w.p$cacen*p.w$acen[1]))

f.m <- subset(prb, sexc == "m" & shp == "flat")
f.m$ttfNu <- (f.m$eCell_0*exp(f.m.p$cacen*f.m$acen) - f.m$DeCell_0*exp(f.m.p$cacen*f.m$dacen))/
  (f.m$eCell_0[1]*exp(f.m.p$cacen*f.m$acen[1]))
f.w <- subset(prb, sexc == "w" & shp == "flat")
f.w$ttfNu <- (f.w$eCell_0*exp(f.w.p$cacen*f.w$acen) - f.w$DeCell_0*exp(f.w.p$cacen*f.w$dacen))/
  (f.w$eCell_0[1]*exp(f.w.p$cacen*f.w$acen[1]))

prb <- rbind(a.w,a.m,s.w,s.m,f.w,f.m,p.w,p.m)
prb$hCell0 <- prb$hCell
prb$hCum0 <- prb$hCum
prb$sCell0 <- prb$sCell

# new with ttfNu
prb$hCell <- prb$hCell0/prb$ttf*prb$ttfNu

ndim <- length(prb$ages)
nage <- length(prb$ages[prb$shp == "sessile" & prb$sexc == "w"])
hS <- 0
for (i in 1:ndim)
{
  hS <- hS + prb$hCell[i]
  prb$hCum[i] <- hS
  prb$sCell[i] <- exp(-hS)
  if (i %% nage == 0) {hS <- 0}
}

round((prb$hCell-prb$hCell0)/prb$hCell*100,1)
round((prb$hCum-prb$hCum0)/prb$hCum*100,1)

a.m <- subset(prb, sexc == "m" & shp == "all")
a.w <- subset(prb, sexc == "w" & shp == "all" )

s.m <- subset(prb, sexc == "m" & shp == "sessile")
s.w <- subset(prb, sexc == "w" & shp == "sessile" )

p.m <- subset(prb, sexc == "m" & shp == "peduncular")
p.w <- subset(prb, sexc == "w" & shp == "peduncular")

f.m <- subset(prb, sexc == "m" & shp == "flat")
f.w <- subset(prb, sexc == "w" & shp == "flat")

ysess <- c(50,200,800,3200)
ypedu <- c(13,50,200,800)
yflat <- ysess
yall <- ysess

pn.a.m <- vector()
pn.a.w <- vector()
pn.s.m <- vector()
pn.s.w <- vector()
pn.p.m <- vector()
pn.p.w <- vector()
pn.f.m <- vector()
pn.f.w <- vector()
nind <- 1
for(i in 1: length(ysess)){
  pn.a.m <- yall[nind]*a.m$hCell*exp(-yall[nind]*s.m$hCum)
  pn.a.w <- yall[nind]*a.w$hCell*exp(-yall[nind]*s.w$hCum)
  pn.s.m <- ysess[nind]*s.m$hCell*exp(-ysess[nind]*s.m$hCum)
  pn.s.w <- ysess[nind]*s.w$hCell*exp(-ysess[nind]*s.w$hCum)
  pn.p.m <- ypedu[nind]*p.m$hCell*exp(-ypedu[nind]*p.m$hCum)
  pn.p.w <- ypedu[nind]*p.w$hCell*exp(-ypedu[nind]*p.w$hCum)
  pn.f.m <- yflat[nind]*f.m$hCell*exp(-yflat[nind]*f.m$hCum)
  pn.f.w <- yflat[nind]*f.w$hCell*exp(-yflat[nind]*f.w$hCum)
}
a.m <- data.frame(a.m,pn.a.m)
a.w <- data.frame(a.w,pn.a.w)
s.m <- data.frame(s.m,pn.s.m)
s.w <- data.frame(s.w,pn.s.w)
p.m <- data.frame(p.m,pn.p.m)
p.w <- data.frame(p.w,pn.p.w)
f.m <- data.frame(f.m,pn.f.m)
f.w <- data.frame(f.w,pn.f.w)

nind <- 2
for(i in 1: length(ysess)){
  pn.a.m <- yall[nind]*a.m$hCell*exp(-yall[nind]*s.m$hCum)
  pn.a.w <- yall[nind]*a.w$hCell*exp(-yall[nind]*s.w$hCum)
  pn.s.m <- ysess[nind]*s.m$hCell*exp(-ysess[nind]*s.m$hCum)
  pn.s.w <- ysess[nind]*s.w$hCell*exp(-ysess[nind]*s.w$hCum)
  pn.p.m <- ypedu[nind]*p.m$hCell*exp(-ypedu[nind]*p.m$hCum)
  pn.p.w <- ypedu[nind]*p.w$hCell*exp(-ypedu[nind]*p.w$hCum)
  pn.f.m <- yflat[nind]*f.m$hCell*exp(-yflat[nind]*f.m$hCum)
  pn.f.w <- yflat[nind]*f.w$hCell*exp(-yflat[nind]*f.w$hCum)
}
a.m <- data.frame(a.m,pn.a.m)
a.w <- data.frame(a.w,pn.a.w)
s.m <- data.frame(s.m,pn.s.m)
s.w <- data.frame(s.w,pn.s.w)
p.m <- data.frame(p.m,pn.p.m)
p.w <- data.frame(p.w,pn.p.w)
f.m <- data.frame(f.m,pn.f.m)
f.w <- data.frame(f.w,pn.f.w)

nind <- 3
for(i in 1: length(ysess)){
  pn.a.m <- yall[nind]*a.m$hCell*exp(-yall[nind]*s.m$hCum)
  pn.a.w <- yall[nind]*a.w$hCell*exp(-yall[nind]*s.w$hCum)
  pn.s.m <- ysess[nind]*s.m$hCell*exp(-ysess[nind]*s.m$hCum)
  pn.s.w <- ysess[nind]*s.w$hCell*exp(-ysess[nind]*s.w$hCum)
  pn.p.m <- ypedu[nind]*p.m$hCell*exp(-ypedu[nind]*p.m$hCum)
  pn.p.w <- ypedu[nind]*p.w$hCell*exp(-ypedu[nind]*p.w$hCum)
  pn.f.m <- yflat[nind]*f.m$hCell*exp(-yflat[nind]*f.m$hCum)
  pn.f.w <- yflat[nind]*f.w$hCell*exp(-yflat[nind]*f.w$hCum)
}
a.m <- data.frame(a.m,pn.a.m)
a.w <- data.frame(a.w,pn.a.w)
s.m <- data.frame(s.m,pn.s.m)
s.w <- data.frame(s.w,pn.s.w)
p.m <- data.frame(p.m,pn.p.m)
p.w <- data.frame(p.w,pn.p.w)
f.m <- data.frame(f.m,pn.f.m)
f.w <- data.frame(f.w,pn.f.w)

nind <- 4
for(i in 1: length(ysess)){
  pn.a.m <- yall[nind]*a.m$hCell*exp(-yall[nind]*s.m$hCum)
  pn.a.w <- yall[nind]*a.w$hCell*exp(-yall[nind]*s.w$hCum)
  pn.s.m <- ysess[nind]*s.m$hCell*exp(-ysess[nind]*s.m$hCum)
  pn.s.w <- ysess[nind]*s.w$hCell*exp(-ysess[nind]*s.w$hCum)
  pn.p.m <- ypedu[nind]*p.m$hCell*exp(-ypedu[nind]*p.m$hCum)
  pn.p.w <- ypedu[nind]*p.w$hCell*exp(-ypedu[nind]*p.w$hCum)
  pn.f.m <- yflat[nind]*f.m$hCell*exp(-yflat[nind]*f.m$hCum)
  pn.f.w <- yflat[nind]*f.w$hCell*exp(-yflat[nind]*f.w$hCum)
}
a.m <- data.frame(a.m,pn.a.m)
a.w <- data.frame(a.w,pn.a.w)
s.m <- data.frame(s.m,pn.s.m)
s.w <- data.frame(s.w,pn.s.w)
p.m <- data.frame(p.m,pn.p.m)
p.w <- data.frame(p.w,pn.p.w)
f.m <- data.frame(f.m,pn.f.m)
f.w <- data.frame(f.w,pn.f.w)
names(f.w)

headline <-  c("shp","sexc","ages","delt","eSize_0","DeSize_0","eN_0","DeN_0","eCell_0","DeCell_0",
               "nuAge","ttf","hCell","hCum","sCell","acen","dacen","ttfNu","hCell0","hCum0","sCell0", 
               "pn025","pn05","pn1","pn2")
names(a.m) <- headline
names(a.w) <- headline
names(s.m) <- headline
names(s.w) <- headline
names(p.m) <- headline
names(p.w) <- headline
names(f.m) <- headline
names(f.w) <- headline

prb <- rbind(a.m,a.w,s.m,s.w,p.m,p.w,f.m,f.w)

kdf <- prb[c("shp","sexc","ages","delt","eCell_0","DeCell_0","nuAge","ttfNu","hCell","hCum","sCell",
             "pn025","pn05","pn1","pn2")] # 
names(kdf) <- c("Shape","Sex","ages","delt","eCell_0","DeCell_0","nuAge","ttfNu","hCell","hCum","sCell",
                "pn025","pn05","pn1","pn2")
str(kdf)

kdf.1 <- kdf[c("Shape","Sex","ages","delt","eCell_0","DeCell_0","nuAge","ttfNu","hCell","hCum","sCell","pn025")]
names(kdf.1)[12] <- "pCanc"
kdf.1$Size <- "0.25"
kdf.2 <- kdf[c("Shape","Sex","ages","delt","eCell_0","DeCell_0","nuAge","ttfNu","hCell","hCum","sCell","pn05")]
names(kdf.2)[12] <- "pCanc"
kdf.2$Size <- "0.5"
kdf.3 <- kdf[c("Shape","Sex","ages","delt","eCell_0","DeCell_0","nuAge","ttfNu","hCell","hCum","sCell","pn1")]
names(kdf.3)[12] <- "pCanc"
kdf.3$Size <- "1"
kdf.4 <- kdf[c("Shape","Sex","ages","delt","eCell_0","DeCell_0","nuAge","ttfNu","hCell","hCum","sCell","pn2")]
names(kdf.4)[12] <- "pCanc"
kdf.4$Size <- "2"

#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------
pf <- rbind(kdf.1,kdf.2,kdf.3,kdf.4)
pf <- subset(pf, Size != "0.25")
pf$Size[pf$Size == "0.5"] <- "0.5 cm"
pf$Size[pf$Size == "1"] <- "1 cm"
pf$Size[pf$Size == "2"] <- "2 cm"
pf$Sex[pf$Sex == "w"] <- "women"
pf$Sex[pf$Sex == "m"] <- "men"
pf$Shape <- fct_relevel(pf$Shape,c("all","sessile","peduncular","flat"))
pf$Sex <- fct_rev(pf$Sex)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)

legend_title = "Size (cm)"
fp.1 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= pCanc*100, x = ages, color = Shape), size = 1.2) + 
  facet_grid (Sex ~ Size) +
  #scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,100), breaks = seq(0,100,20)) +
  scale_x_continuous(name = "Age (yr)", limits = c(60,70), breaks = seq(60,70,5)) +
  #scale_x_continuous(name = "Age (yr)", limits = c(55,75), breaks = seq(55,75,5)) +
  scale_y_continuous(name="Cancer probability (%)", limits = c(0,2.5), breaks = seq(0,3,.5)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(legend_title, values = c("dotdash","solid","twodash","dotted")) +
  #guides(linetype = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.11,0.27)) 
print(fp.1)

fp.2 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y= pCanc*100, x = ages, color = Shape, linetype = Size), size = 1.2) + 
  facet_grid (Sex ~ .) +
  #scale_x_continuous(name = "Adenoma detection rate (%)", limits = c(0,100), breaks = seq(0,100,20)) +
  scale_x_continuous(name = "Age (yr)", limits = c(60,70), breaks = seq(60,70,5)) +
  #scale_y_continuous(name="Cancer probability (%)", limits = c(0,2.5), breaks = seq(0,3,.5)) +
  scale_y_log10(name="Cancer probability (%)") +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(legend_title, values = c("dotted","twodash","solid","dotted")) +
  guides(linetype = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.15,0.5)) 
print(fp.2)

