#----------------------------------------------
# adeno OE analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-------------------------------------------
# adenoma data reading
#-------------------------------------------

shp <- character()
#shp <- "all"
#shp <- "flat"
#shp <- "sessile"
shp <- "peduncular"

noad <- character()
noad <- "wN0"
#noad <- "noN0"

loca <- character()
loca <- "all"

sexc <- character()
sexc <- "m"
#sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K0"
mmname <- "K1app"
#mmname <- "K2"

# likelihood
likc <- character()
#likc <- "sing"
#likc <- "unif"
likc <- "dist"
#likc <- "bina"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,"-atrend",sep="") # age trend version

#-------------------------------------------------------------
# prepare observed data
#-------------------------------------------------------------
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20210915.Rdata")
    df0 <- sadenoPG} 
  else if (shp == "sessile") {
    load(file = "sessPG-20210915.Rdata")
    df0 <- sess}
  else if (shp == "flat") {
    load(file = "flatPG-20210915.Rdata")
    df0 <- flat}
  else if (shp == "peduncular" & mdv == "grid") {
    load(file = "peduPG-20210915.Rdata")
    df0 <- pedu
    patdata <- "peduPG-20210915.Rdata"}
  else if (shp == "peduncular" & mdv == "pref") {
    load(file = "peduPG-20211103.Rdata")
    levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
    pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
    df0 <- pedu
    patdata <- "peduPG-20211103.Rdata"}
}

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  # location
  if (loca == "distboth") {
    df0 <- subset(df0, loca == "distboth" | loca == "none")} 
  else if (loca == "proximal") {
    df0 <- subset(df0, loca == "proximal" | loca == "none")}
  
  if (dims == "2d") {
    df0$ys <- df0$ys2d
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ys <- df0$ys3d
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}
df0$yhi[df0$sizecat == ">2"] <- -1

# set detection limit boundaries for preferred models
{
  if (mdv == "pref"){
    if (shp == "sessile") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "peduncular") {
      df0$ylo[df0$ylo == 50] <- 40
      df0$ymin[df0$ymin == 50] <- 40}  
  }
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
df0 <- droplevels(df0)

ad <- subset(df0, shape != "none")

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 100
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
dim(sigma)[1]
sigma[1,2] <- sigma[2,1]
if(dim(sigma)[1] == 3)
{
 sigma[1,3] <- sigma[3,1]
 sigma[2,3] <- sigma[3,2]
}
if(dim(sigma)[1] == 4)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
}

cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov

if (all(1 == sign(eigen(sigma)$values)) == TRUE)
#if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
apply(Z,2,mean)
#apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

df.par[1:10,]

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
source("pAdenoK0K1K2atrend-distrib.R")

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.hyp
    Thelohi <- theta_lohi_K2.hyp
  }
  else
  {
    print("Not implemented\n")
  }
  
  if (likc == "bina"){
    Padeno <- Padeno_bin
  }
  else{
    Padeno <- Padeno_N
    PadenoTop <- Padeno_Nmaxprob
  }
}

#--------------------------------
# model predictions
#--------------------------------
upar <- dpar$parval
#--------------------------------
# adenoma counts with estimated ad.frees
#--------------------------------
df <- df0

cage.sum <- aggregate(df$age*df$npat, list(df$countcat,df$agecat), sum)
cage.len <- aggregate(df$npat, list(df$countcat,df$agecat), sum)
cage.mean <- cage.sum$x/cage.len$x

cnpat.sum <- aggregate(df$npat, list(df$countcat,df$agecat), sum)
cnpno.sum <- aggregate(df$npat*df$pno, list(df$countcat,df$agecat), sum)
cnpno.sum$x/cnpat.sum$x

pct <- data.frame(cage.sum$Group.1,cage.sum$Group.2,cnpat.sum$x,cnpno.sum$x,cage.mean)
names(pct) <- c("Count","AgeGroup","Npat","Npno","age")
pct
dim(pct) # 28 5
pdim <- dim(pct)[1]

# check age group normalization
#aggregate(pct$PNcat,list(pct$AgeGroup),sum)

# measured frequencies in age groups
cnpat.agrp <- aggregate(pct$Npat, list(pct$AgeGroup), sum)
cnpno.agrp <- aggregate(pct$Npno, list(pct$AgeGroup), sum)
help1 <- split(pct, pct$AgeGroup)
nlevels <- length(levels(pct$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- cnpat.agrp$x[i] 
  help1[[i]]$Npno_agrp <- cnpno.agrp$x[i]
}
pcf <- help1[[1]]
for (i in 2:nlevels){
  pcf <- rbind(pcf,help1[[i]])
}

# model predictions
# expectation value
eNad <- ENad(pct$age,upar,gb.ymin) 
# probabilities
pNcat <- unlist(lapply(1:pdim, function(i) Padeno(pct$Count[i],eNad[i]))) # count category

pcf <- data.frame(pcf,eNad)
sNad <- pcf$Npno_agrp/pcf$Npat_agrp # screened rel. freq. (based on Npno approximation)
pcf <- data.frame(pcf,pNcat)
sNcat <- pcf$Npat/pcf$Npat_agrp # screened rel. freq. (from exact Npat)

#pcf$sNcatLBD <- unlist(lapply(1:pdim, function(i) Padeno(pct$Count[i],pcf$sNad[i])))

# check integrity
aggregate(pcf$pNcat, list(pcf$AgeGroup), sum)
aggregate(pcf$sNcat, list(pcf$AgeGroup), sum)

#-------------------------------------------------------------
# adenoma count uncertainties
#-------------------------------------------------------------
pdfsNcat <- list()
pdim <- length(pcf$age)
ctdim <- length(levels(pcf$Count))
agdim <- length(levels(pcf$AgeGroup))
for(i in 1:pdim)
{
  pdfsNcat[[i]] <- rpois(nsim,pcf$Npat[i])
} 

pdfsNagroup <- list()
j = 1
for(i in seq(1,pdim,ctdim))
{
  pdfsNagroup[[j]] <- pdfsNcat[[i]] +  pdfsNcat[[i+1]] +  pdfsNcat[[i+2]] +  pdfsNcat[[i+3]]
  j <- j+1
}

# frequencies in categories
j <- 0
pdfsFreqCat <- list()
for(i in 1:pdim)
{
  if (i%%ctdim == 1){j <- j+1}
  cat(sprintf("i,j = %2d,%2d\n", i,j))
  pdfsFreqCat[[i]] <- pdfsNcat[[i]]/pdfsNagroup[[j]]
} 

sNcat.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfsFreqCat[[i]], probs = 0.025))))
sNcat.md <- unlist(lapply(pdfsFreqCat,median))
sNcat.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfsFreqCat[[i]], probs = 0.975))))

# expectation value
count <- c(1,2,5,0)
pdfsCount <- list()
sNad <- vector()
j = 1
for(i in seq(1,pdim,ctdim))
{
  sNad[j] <- pcf$Npno_agrp[i]/pcf$Npat_agrp[i] # screened rel. freq. (based on Npno approximation)
  pdfsCount[[j]] <- count[1]*pdfsFreqCat[[i]] +  count[2]*pdfsFreqCat[[i+1]] +  count[3]*pdfsFreqCat[[i+2]] +  count[4]*pdfsFreqCat[[i+3]]
  j <- j+1
}

sNad.lo <- as.numeric(unlist(lapply(1:agdim,function (i) quantile(pdfsCount[[i]], probs = 0.025))))
sNad.md <- unlist(lapply(pdfsCount,median))
sNad.hi <- as.numeric(unlist(lapply(1:agdim,function (i) quantile(pdfsCount[[i]], probs = 0.975))))

# Poisson deviance
sum(-2*(dpois(pcf$Npat,pcf$pNcat*pcf$Npat_agrp, log = TRUE)-dpois(pcf$Npat,pcf$Npat, log = TRUE)))

#-------------------------------------------------------------
#  crude rate-related mixed functions
#-------------------------------------------------------------
tpar <- vector()
tpar[1] <- -2.4
tpar[2] <- 1

expx <- function(x,meanlog,sdlog){
  retarg <- x*dlnorm(x,meanlog,sdlog)
}
integrate(expx, lower = 0, upper = Inf, tpar[1], tpar[2])$value
exp(tpar[1]+0.5*tpar[2]^2)

integrand_mixPDk <- function(x,k,meanlog,sdlog){
  retarg <- dpois(k,x)*dlnorm(x,meanlog,sdlog)
  return(retarg)
}
mixPDk <- function(k,meanlog,sdlog){
  retarg <- integrate(integrand_mixPDk, lower = 0, upper = Inf, k, meanlog, sdlog)$value
  return(retarg)
}

likeli_count <- function(Count,meanlog,sdlog){
  
  n2_4 <- c(2:4)
  n0_4 <- c(0:4)
  countcat <- as.character(Count)
  switch(countcat,
         "0"={lik <- mixPDk(0,meanlog,sdlog)},
         "1"={lik <- mixPDk(1,meanlog,sdlog)},
         "2-4"={lik <- mixPDk(2,meanlog,sdlog)+mixPDk(3,meanlog,sdlog)+mixPDk(4,meanlog,sdlog)},
         ">=5"={lik <- 1-mixPDk(0,meanlog,sdlog)-mixPDk(1,meanlog,sdlog)-mixPDk(2,meanlog,sdlog)-mixPDk(3,meanlog,sdlog)-mixPDk(4,meanlog,sdlog)} 
         #"2-4"={lik <- sum(mixPDk(n2_4,meanlog,sdlog))},
         #">=5"={lik <- 1-sum(mixPDk(n0_4,meanlog,sdlog))} 
  )
  return (lik)
}

smdeviance_count <- function(meanlog,sdlog){
  ndim <- length(Count)
  mixpNcat <- unlist(lapply(1:ndim, function(i) likeli_count(Count[i],meanlog,sdlog) ))
  retarg <- -(dpois(Npat,mixpNcat*Npat_agrp, log = TRUE)-dpois(Npat,Npat, log = TRUE))
  return (sum(retarg))
}

sdeviance_count <- function(meanlog,sdlog, df){
  
  ndim <- length(df$Count)
  mixpNcat <- unlist(lapply(1:ndim, function(i) likeli_count(df$Count[i],meanlog,sdlog) ))
  retarg <- -2*(dpois(df$Npat,mixpNcat*df$Npat_agrp, log = TRUE)-dpois(df$Npat,df$Npat, log = TRUE))
  return (sum(retarg))
}

smdeviance_model <- function(meanlog,sdlog){
  ndim <- length(Count)
  
  mixpNcat <- unlist(lapply(1:ndim, function(i) likeli_count(Count[i],meanlog,sdlog) ))
  retarg <- -(dpois(Npat,mixpNcat*Npat_agrp, log = TRUE)-dpois(Npat,Npat, log = TRUE))
  return (sum(retarg))
}

mixPDk(0,tpar[1],tpar[2])
pcf$sNcat[4]
mixPDk(1,tpar[1],tpar[2])
pcf$sNcat[2]
mixPDk(2,tpar[1],tpar[2])+mixPDk(3,tpar[1],tpar[2])+mixPDk(4,tpar[1],tpar[2])
1-(mixPDk(0,tpar[1],tpar[2])+mixPDk(1,tpar[1],tpar[2])+mixPDk(2,tpar[1],tpar[2])+mixPDk(3,tpar[1],tpar[2])+mixPDk(4,tpar[1],tpar[2]))

kvec <- seq(0,100,1)
ndim <- length(kvec)
sum(unlist(lapply(1: ndim, function (i) kvec[i]*mixPDk(kvec[i],tpar[1],tpar[2])) ))

#---------------------------------------------------------
# fitting inter-individual variability: model-related mixed functions
#---------------------------------------------------------
dpois_model <- function(Count, eNad){
  # probabilities
  # count category
  #cat(sprintf("%d %s %d %g\n",nCount, Count, neNad, eNad))
  pNcat <-  Padeno(Count,eNad)
  
  return (pNcat)
}

integrand_mixPDk_model <- function(x,Count,lbd_const,meanlog,sdlog){
  #ndim <- length(lbd_const)
  #eNad <- unlist(lapply(1:ndim, function(i) x*lbd_const[i] ))
  #retarg <- unlist(lapply(1:ndim, function(i) dpois_model(Count[i], eNad[i])*dlnorm(eNad[i],meanlog,sdlog) ))
  ndim <- length(x)
  eNad <- unlist(lapply(1:ndim, function(i) x[i]*lbd_const ))
  
  #cat(sprintf("%g %g %g\n", x, lbd_const, eNad))
  #unlist(lapply(1:ndim, function(i) cat(sprintf("%g %g\n", dpois_model(Count, eNad[i]), dlnorm(eNad[i],meanlog,sdlog))) ))
  #retarg <- unlist(lapply(1:ndim, function(i) dlnorm(eNad[i],meanlog,sdlog) ))
  retarg <- unlist(lapply(1:ndim, function(i) dpois_model(Count, eNad[i])*dlnorm(eNad[i],meanlog,sdlog) ))
  return(retarg*lbd_const)
}

mixPDk_model <- function(Count,age,meanlog,sdlog){
  # model predictions
  # expectation value
  ndim <- length(age)
  #cat(sprintf("%g %d\n",age, gb.ymin))
  lbd_x <- unlist(lapply(1:ndim, function(i) ENad(age[i],gb.upar,gb.ymin) ))
  lbd_const <- lbd_x/gb.upar[1] # age-dependent part does not depend on X0
  #cat(sprintf("%g %g %g\n",lbd_x, gb.upar[1], lbd_const))
  #retarg <- integrate(integrand_mixPDk_model, lower = 0, upper = Inf, Count, lbd_const, meanlog, sdlog)$value
  retarg <- unlist(lapply(1:ndim, function(i) integrate(integrand_mixPDk_model, lower = 0, upper = Inf, Count[i], lbd_const[i], meanlog, sdlog)$value ))
  return(retarg)
}


sdeviance_model <- function(meanlog,sdlog,df){
  ndim <- length(df$age)
  #mixpNcat <- unlist(lapply(1:ndim, function(i) mixPDk_model(df$Count[i],df$age[i],meanlog,sdlog) ))
  mixpNcat <- mixPDk_model(df$Count,df$age,meanlog,sdlog)
  retarg <- -2*(dpois(df$Npat,mixpNcat*df$Npat_agrp, log = TRUE)-dpois(df$Npat,df$Npat, log = TRUE))
  return (sum(retarg))
}

smdeviance_model <- function(meanlog,sdlog){
  ndim <- length(age)
  mixpNcat <- mixPDk_model(Count,age,meanlog,sdlog)
  #mixpNcat <- unlist(lapply(1:ndim, function(i) mixPDk_model(Count[i],age[i],meanlog,sdlog) ))
  retarg <- -(dpois(Npat,mixpNcat*Npat_agrp, log = TRUE)-dpois(Npat,Npat, log = TRUE))
  return (sum(retarg))
}

integrand_mixPDk_model_atrend <- function(x,Count,lbd_const,meanlog,sdlog){
  #ndim <- length(lbd_const)
  #eNad <- unlist(lapply(1:ndim, function(i) x*lbd_const[i] ))
  #retarg <- unlist(lapply(1:ndim, function(i) dpois_model(Count[i], eNad[i])*dlnorm(eNad[i],meanlog,sdlog) ))
  ndim <- length(x)
  eNad <- unlist(lapply(1:ndim, function(i) x[i]*lbd_const ))
  
  #cat(sprintf("%g %g %g\n", x, lbd_const, eNad))
  #unlist(lapply(1:ndim, function(i) cat(sprintf("%g %g\n", dpois_model(Count, eNad[i]), dlnorm(eNad[i],meanlog,sdlog))) ))
  #retarg <- unlist(lapply(1:ndim, function(i) dlnorm(eNad[i],meanlog,sdlog) ))
  retarg <- unlist(lapply(1:ndim, function(i) dpois_model(Count, eNad[i])*dlnorm(eNad[i],meanlog,sdlog) ))
  return(retarg*lbd_const)
}

mixPDk_model_atrend <- function(Count,age,meanlog,sdlog){
  # model predictions
  # expectation value
  ndim <- length(age)
  #cat(sprintf("%g %d\n",age, gb.ymin))
  lbd_x <- unlist(lapply(1:ndim, function(i) ENad(age[i],gb.upar,gb.ymin) ))
  lbd_const <- lbd_x/gb.upar[1] # age-dependent part does not depend on X0
  #cat(sprintf("%g %g %g\n",lbd_x, gb.upar[1], lbd_const))
  #retarg <- integrate(integrand_mixPDk_model_atrend, lower = 0, upper = Inf, Count, lbd_const, meanlog, sdlog)$value
  retarg <- unlist(lapply(1:ndim, function(i) 
    integrate(integrand_mixPDk_model_atrend, lower = 0, upper = Inf, Count[i], lbd_const[i], meanlog[i], sdlog[i])$value ))
  return(retarg)
}

sdeviance_model_atrend <- function(meanlog,sdlog,tmean,tsd,df){
  ndim <- length(df$age)
  acen <- (df$age-65)/10
  ameanlog <- meanlog*exp(tmean*acen)
  asdlog <- sdlog*exp(tsd*acen)
  #cat(sprintf("%g %g\n", ameanlog, asdlog))
  #mixpNcat <- unlist(lapply(1:ndim, function(i) mixPDk_model(df$Count[i],df$age[i],meanlog,sdlog) ))
  mixpNcat <- mixPDk_model_atrend(df$Count,df$age,ameanlog,asdlog)
  retarg <- -2*(dpois(df$Npat,mixpNcat*df$Npat_agrp, log = TRUE)-dpois(df$Npat,df$Npat, log = TRUE))
  return (sum(retarg))
}

smdeviance_model_atrend <- function(meanlog,sdlog,tmean,tsd){
  ndim <- length(age)
  acen <- (age-65)/10
  ameanlog <- meanlog*exp(tmean*acen)
  asdlog <- sdlog*exp(tsd*acen)
  #mixpNcat <- unlist(lapply(1:ndim, function(i) mixPDk_model(df$Count[i],df$age[i],meanlog,sdlog) ))
  mixpNcat <- mixPDk_model_atrend(Count,age,ameanlog,asdlog)
  retarg <- -(dpois(Npat,mixpNcat*Npat_agrp, log = TRUE)-dpois(Npat,Npat, log = TRUE))
  return (sum(retarg))
}

#------------------------------------------------------------------------------
# mixed Poisson fitting
#------------------------------------------------------------------------------
library(bbmle) # mle2 fitting with functions similar to glm fitting

mde <- character()
#mde <- "count"
#mde <- "model"
mde <- "model_atrend"

{
  if (mde == "count") {
    sdeviance <- sdeviance_count
    smdeviance <- smdeviance_count
  }
  else if (mde == "model"){
    sdeviance <- sdeviance_model
    smdeviance <- smdeviance_model
  }
  else if (mde == "model_atrend"){
    sdeviance <- sdeviance_model_atrend
    smdeviance <- smdeviance_model_atrend
  }
}

upar <- vector()
upar[1] <- -6.500066
upar[2] <- 3.440061
upar[3] <- -0.051805
upar[4] <- -0.006885

#integrate(integrand_mixPDk_model_atrend, lower = 0, upper = Inf, "1", 0.335355, upar[1], upar[2])

#ff <- subset(pcf, AgeGroup == "75-79")
ff <- pcf
#ff <- pcf[1:2,]
dev <- sdeviance(upar[1],upar[2],upar[3],upar[4],ff)
#dev <- sdeviance(upar[1],upar[2],ff)
dev

mle.1 <- mle2(minuslog = smdeviance,
              start=list(meanlog = upar[1], sdlog = upar[2], tmean = upar[3], tsd = upar[4]), 
              parameters=list(meanlog~1, sdlog~1, tmean~1, tsd~1), 
              fixed=list(
              #tmean = 0,
              tsd = 0
              ),
              #lower = c(meanlog = -8.5, sdlog = 3, tmean = -.1, tsd = -.1),
              #upper = c(meanlog = -7.5, sdlog = 4, tmean = 0, tsd = 0.1),
              #lower = c(meanlog = -8.5, sdlog = 3, tmean = -.1),
              #upper = c(meanlog = -7.5, sdlog = 4, tmean = 0),
              #lower = c(meanlog = -8.5, sdlog = 3),
              #upper = c(meanlog = -7.5, sdlog = 4),
              method = "L-BFGS-B",
              #method = "CG",
              #method = "Brent",
              data = ff)

summary(mle.1)
#AIC(mle.1)


# deviance difference
#round(2*nlm.mdl$objective - deviance(mle.1)[1],2)
round(dev - deviance(mle.1)[1],2)

cov2cor(vcov(mle.1))

rm <- round(vcov(mle.1),6)
#rm <- round(covm,6)
#eigen(covm)
#all(1 == sign(eigen(vcov(mle.1))$values))
#all(1 == sign(eigen(rm)$values))
is.positive.definite(vcov(mle.1), tol = 1e-10)
isPD <- all(1 == sign(eigen(vcov(mle.1))$values)) # check if all eigenvalues > 0
isPD

#park <- mle.1
#mle.1 <- park

upar <- coef(mle.1)

pl <- profile(mle.1)
plot(pl)
coef(pl)
upar <- coef(pl)
lp.CI <- confint(pl)
round(lp.CI,5)

# results for mde == "count"
# "peduncular-all-w-2d-K1app-dist-atrend" -7.194627 3.252447
# "peduncular-all-m-2d-K1app-dist-atrend" -6.516768 3.445601 1059.981 25115.36
# "flat-all-w-3d-K2-dist-atrend" -7.994053 3.509440  488.8306 12664.95
# "flat-all-m-3d-K2-dist-atrend" -7.98459 3.85126 791.6047 19639.81
# "sessile-all-w-2d-K2-dist-atrend" -2.903987 1.919383 1670.704 23266.32
# "sessile-all-m-2d-K2-dist-atrend" -2.246659 1.894337 2442.532 33703.73

#ndim <- length(ff$Count)
#mixPDk_model
#mixpNcat <- unlist(lapply(1:ndim, function(i) likeli_count(ff$Count[i],upar[1],upar[2]) ))
#mixpNcat

# build pNcativ with inter individual variability
pNcativ <- vector()
pdim <- length(ff$age)
for (i in 1:pdim){
  acen <- (ff$age[i]-65)/10
  meanlog <- upar[1]*exp(upar[3]*acen)
  sdlog <- upar[2]*exp(upar[4]*acen) 
  pNcativ[i] <- mixPDk_model(ff$Count[i],ff$age[i],meanlog,sdlog)
}
pNcativ

#-----------------------------------------
# build plot frame
#-----------------------------------------
{
  if (sexc == "w") {sexcc = "women"}
  else if (sexc == "m") {sexcc = "men"}
}
headline <- c("Shape","Sex","Source","Npat",
              "Count","AgeGroup","age",
              "enad","enad.lo","enad.hi",
              "pNcat","pNcat.lo","pNcat.hi")

pcf.m <- data.frame(shp,sexcc,"M",pcf$Npat,pcf$Count,pcf$AgeGroup,pcf$age,eNad,0,0,pNcat,1,1)
names(pcf.m) <- headline
pcf.miv <- data.frame(shp,sexcc,"Miv",pcf$Npat,pcf$Count,pcf$AgeGroup,pcf$age,eNad,0,0,pNcativ,1,1)
names(pcf.miv) <- headline
pcf.s <- data.frame(shp,sexcc,"S",pcf$Npat,pcf$Count,pcf$AgeGroup,pcf$age,0,0,0,sNcat,sNcat.hi,sNcat.lo)
names(pcf.s) <- headline
#pcf.s <- subset(pcf.s, Count == "0")

help2 <- split(pcf.s, pcf.s$AgeGroup)
nlevels <- length(levels(pcf.s$AgeGroup))
for(i in 1:nlevels){
  help2[[i]]$enad <- sNad[i] 
  help2[[i]]$enad.lo <- sNad.lo[i]
  help2[[i]]$enad.hi <- sNad.hi[i]
}
pcf.s.s <- help2[[1]]
for (i in 2:nlevels){
  pcf.s.s <- rbind(pcf.s.s,help2[[i]])
}

pif <- rbind(pcf.s.s,pcf.m,pcf.miv)
#prf <- subset(dum.1, Count == "0")
#prf$pNcat <- 1 - prf$pNcat
#prf$pNcat.lo <- 1 - prf$pNcat.lo
#prf$pNcat.hi <- 1 - prf$pNcat.hi
pif

# plot file saving
fname
ffname <- paste("pcount-iiv-agroup",fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
setwd(curvdir)
save(pif, file = fsavname)

#----------------------------------------------------------------------------------------------
# age dependence of model predictions
#----------------------------------------------------------------------------------------------
{
  if (sexc == "w") {sexcc = "women"}
  else if (sexc == "m") {sexcc = "men"}
}
headline <- c("Shape","Sex","Source",
              "Count","age",
              "enad","pNcat")

ages <- seq(20,90,1)
ndim <- length(ages)
# expectation value
mNad <- ENad(ages,gb.upar,gb.ymin) 
mNcat <- unlist(lapply(1:ndim, function(i) Padeno("0",mNad[i]))) # count category

mNcativ <- vector()
pdim <- length(ages)
for (i in 1:pdim){
  acen <- (ages[i]-65)/10
  meanlog <- upar[1]*exp(upar[3]*acen)
  sdlog <- upar[2]*exp(upar[4]*acen) 
  mNcativ[i] <- mixPDk_model("0",ages[i],meanlog,sdlog)
}
mNcativ

praf.M <- data.frame(shp,sexcc,"M","0",ages,mNad,1-mNcat)
names(praf.M) <- headline
head(praf.M)

praf.Miv <- data.frame(shp,sexcc,"Miv","0",ages,mNad,1-mNcativ)
names(praf.Miv) <- headline
head(praf.Miv)

praf <- rbind(praf.M,praf.Miv)

# plot file saving
fname
ffname <- paste("prev-iiv-age",fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
setwd(curvdir)
save(praf, file = fsavname)

