#----------------------------------------------
# plot adeno enad analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="enad-flat-all-w-3d-K2-dist-atrend.Rdata")
f.w <- enf

load(file="enad-flat-all-m-3d-K2-dist-atrend.Rdata")
f.m <- enf

load(file="enad-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.w <- enf

load(file="enad-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.m <- enf

load(file="enad-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
p.w <- enf

load(file="enad-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
p.m <- enf

# read model prediction from age 20,90
load(file="enad-age-flat-all-w-3d-K2-dist-atrend.Rdata")
f.age.w <- eaf

load(file="enad-age-flat-all-m-3d-K2-dist-atrend.Rdata")
f.age.m <- eaf

load(file="enad-age-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.age.w <- eaf

load(file="enad-age-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.age.m <- eaf

load(file="enad-age-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
p.age.w <- eaf

load(file="enad-age-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
p.age.m <- eaf

# build and adjust pf
pf <- rbind(f.w,f.m,s.w,s.m,p.w,p.m)
pf$Sex <- fct_rev(pf$Sex)
pf$Source <- fct_rev(pf$Source)
pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular","flat"))
#pf <- subset(pf, AgeGroup != ">84")
pf <- droplevels(pf)
summary(pf)
setwd(plotdir)

# with uncertainties and age extrapolation
# build and adjust pf
pf <- rbind(f.w,f.m,s.w,s.m,p.w,p.m)
pf$Sex <- fct_rev(pf$Sex)
pf$Source <- fct_rev(pf$Source)
pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular","flat"))
pf <- subset(pf, Source == "S")
pf <- droplevels(pf)
summary(pf)

pf.2 <- rbind(f.age.w,f.age.m,s.age.w,s.age.m,p.age.w,p.age.m)
pf.early <- subset(pf.2, age < 55)
pf.early <- data.frame(pf.early,"early")
names(pf.early)[6] <- "Period"
pf.late <- subset(pf.2, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[6] <- "Period"

pf.2 <- rbind(pf.early,pf.late)
pf.2$Sex <- fct_rev(pf.2$Sex)
pf.2$Shape <- fct_relevel(pf.2$Shape,c("peduncular","flat","sessile"))
summary(pf.2)

legend_title <- "Shape"
fp.3 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_point(data = pf, aes(y= enad, x = age, color = Shape, shape = Source), size = 4) + 
  geom_linerange(data = pf, aes(x = age, y=enad, ymax =enad.hi, ymin = enad.lo), size = .75) +
  geom_line(data = pf.2, aes(x=age, y=enad, color = Shape, linetype = Period), size = 1) +
  facet_grid (Sex ~ .) +
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name="Adenoma per colonoscopy", limits = c(0,0.6), breaks = seq(0,0.6,0.1)) +
  scale_color_manual(legend_title, values=cbPalette[c(4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape="none", linetype = "none", color = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=12),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.18,0.9)) 
print(fp.3)

# add total enad
pf.tot <- pf
pf.tot <- subset(pf.tot, Shape == "sessile")
pf.tot <- droplevels(pf.tot)
levels(pf.tot$Shape)[levels(pf.tot$Shape)=="sessile"] <- "all shapes"
str(pf.tot)
pf.tot$enad <- pf$enad[pf$Shape == "sessile"] + pf$enad[pf$Shape == "flat"] + pf$enad[pf$Shape == "peduncular"]
pf.tot$enad.lo <- pf$enad.lo[pf$Shape == "sessile"] + pf$enad.lo[pf$Shape == "flat"] + pf$enad.lo[pf$Shape == "peduncular"]
pf.tot$enad.hi <- pf$enad.hi[pf$Shape == "sessile"] + pf$enad.hi[pf$Shape == "flat"] + pf$enad.hi[pf$Shape == "peduncular"]
pf.plus <- rbind(pf,pf.tot)
pf.plus$Shape <- fct_relevel(pf.plus$Shape,c("all shapes","sessile","peduncular","flat"))
# manual jitter
pf.plus$age[pf.plus$AgeGroup == ">84" & pf.plus$Shape == "total"] <- pf.plus$age[pf.plus$AgeGroup == ">84" & pf.plus$Shape == "total"] +.4
pf.plus$age[pf.plus$AgeGroup == ">84" & pf.plus$Shape == "peduncular"] <- pf.plus$age[pf.plus$AgeGroup == ">84" & pf.plus$Shape == "peduncular"] +.4

pf.2.tot <- pf.2
pf.2.tot <- subset(pf.2.tot, Shape == "sessile")
pf.2.tot <- droplevels(pf.2.tot)
levels(pf.2.tot$Shape)[levels(pf.2.tot$Shape)=="sessile"] <- "all shapes"
str(pf.2.tot)
pf.2.tot$enad <- pf.2$enad[pf.2$Shape == "sessile"] + pf.2$enad[pf.2$Shape == "flat"] + pf.2$enad[pf.2$Shape == "peduncular"]
pf.2.plus <- rbind(pf.2,pf.2.tot)
pf.2.plus$Shape <- fct_relevel(pf.2.plus$Shape,c("all shapes","sessile","peduncular","flat"))

#pf.2.plus <- subset(pf.2.plus, Shape == "total")
#pf.plus <- subset(pf.plus, Shape == "total")

fp.4 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_point(data = pf.plus, aes(y= enad, x = age, color = Shape, shape = Source), size = 4) + 
  geom_linerange(data = pf.plus, aes(x = age, y=enad, ymax =enad.hi, ymin = enad.lo), size = .75) +
  geom_line(data = pf.2.plus, aes(x=age, y=enad, color = Shape, linetype = Period), size = 1) +
  facet_grid (Sex ~ .) +
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name="Adenoma per colonoscopy", limits = c(0,1), breaks = seq(0,1,0.2)) +
  scale_color_manual(legend_title, values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape="none", linetype = "none") + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.2,0.88)) 
print(fp.4)

pf.2.plus$Group <- "separate"
pf.2.plus$Group[pf.2.plus$Shape == "total"] <- "all shapes"
pf.plus$Group <- "separate"
pf.plus$Group[pf.plus$Shape == "total"] <- "all shapes"

fp.5 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_point(data = pf.plus, aes(y= enad, x = age, color = Shape, shape = Source), size = 4) + 
  geom_linerange(data = pf.plus, aes(x = age, y=enad, ymax =enad.hi, ymin = enad.lo), size = .75) +
  geom_line(data = pf.2.plus, aes(x=age, y=enad, color = Shape, linetype = Period), size = 1) +
  facet_grid (Sex ~ Group) +
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name="Adenoma per colonoscopy", limits = c(0,1), breaks = seq(0,1,0.2)) +
  scale_color_manual(legend_title, values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F) + 
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        legend.position = c(0.2,0.88)) 
print(fp.5)
