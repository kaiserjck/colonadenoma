#----------------------------------------------
# plot adeno prevalence
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)


    load(file="prev-X0opt-agroup-sessile-all-w-2d-K2-dist-atrend.Rdata")
    s.g.w <- prf
    load(file="prev-X0opt-agroup-sessile-all-m-2d-K2-dist-atrend.Rdata")
    s.g.m <- prf
    load(file="prev-X0opt-age-sessile-all-w-2d-K2-dist-atrend.Rdata")
    s.a.w <- praf
    load(file="prev-X0opt-age-sessile-all-m-2d-K2-dist-atrend.Rdata")
    s.a.m <- praf

    load(file="prev-X0opt-agroup-flat-all-w-3d-K2-dist-atrend.Rdata")
    f.g.w <- prf
    load(file="prev-X0opt-agroup-flat-all-m-3d-K2-dist-atrend.Rdata")
    f.g.m <- prf
    load(file="prev-X0opt-age-flat-all-w-3d-K2-dist-atrend.Rdata")
    f.a.w <- praf
    load(file="prev-X0opt-age-flat-all-m-3d-K2-dist-atrend.Rdata")
    f.a.m <- praf   

    load(file="prev-X0opt-agroup-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
    p.g.w <- prf
    load(file="prev-X0opt-agroup-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
    p.g.m <- prf
    load(file="prev-X0opt-age-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
    p.a.w <- praf
    load(file="prev-X0opt-age-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
    p.a.m <- praf  


# build and adjust pf
# age group data
pf.g <- rbind(s.g.w,s.g.m,f.g.w,f.g.m,p.g.w,p.g.m)
pf.g$Source <- fct_rev(pf.g$Source)
pf.g$Sex <- fct_rev(pf.g$Sex)
pf.g <- subset(pf.g, Source == "S")
pf.g$Shape <- fct_relevel(pf.g$Shape,c("sessile", "peduncular","flat"))
pf.g <- droplevels(pf.g)
summary(pf.g)

# prev-age data
pf.a <- rbind(s.a.w,s.a.m,f.a.w,f.a.m,p.a.w,p.a.m)
pf.a$Sex <- fct_rev(pf.a$Sex)

pf.early <- subset(pf.a, age < 55)
pf.early <- data.frame(pf.early,"early")
nnme <- length(names(pf.early))
names(pf.early)[nnme] <- "Period"
pf.late <- subset(pf.a, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[nnme] <- "Period"

pf.2 <- rbind(pf.early,pf.late)
pf.2$Sex <- fct_rev(pf.2$Sex)
pf.2$Shape <- fct_relevel(pf.2$Shape,c("peduncular","flat","sessile"))
pf.2 <- subset(pf.2, Source == "Mopt")
pf.2 <- droplevels(pf.2)
summary(pf.2)

setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle(shp) +
  geom_point(data = pf.g, aes(x = age, y = pNcat*100, shape = Source, color = Shape), size = 3) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  geom_linerange(data = pf.g, aes(x = age, y = pNcat*100, ymin = pNcat.lo*100, ymax = pNcat.hi*100)) +
  geom_line(data = pf.2, aes(x = age, y = pNcat*100, color = Shape, linetype = Period)) + 
  facet_grid(Sex ~ .) +
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name = "Prevalence (%)") +
  scale_color_manual(values=cbPalette[c(4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F) + 
  theme(text = element_text(size=15),legend.position = c(0.18,0.9)) 
print(fp.1)

# add total prevalence
pf.g.tot <- pf.g
pf.g.tot <- subset(pf.g.tot, Shape == "sessile")
pf.g.tot <- droplevels(pf.g.tot)
levels(pf.g.tot$Shape)[levels(pf.g.tot$Shape)=="sessile"] <- "total"
str(pf.g.tot)
pf.g.tot$pNcat <- pf.g$pNcat[pf.g$Shape == "sessile"] + pf.g$pNcat[pf.g$Shape == "flat"] + pf.g$pNcat[pf.g$Shape == "peduncular"]
pf.g.tot$pNcat.lo <- pf.g$pNcat.lo[pf.g$Shape == "sessile"] + pf.g$pNcat.lo[pf.g$Shape == "flat"] + pf.g$pNcat.lo[pf.g$Shape == "peduncular"]
pf.g.tot$pNcat.hi <- pf.g$pNcat.hi[pf.g$Shape == "sessile"] + pf.g$pNcat.hi[pf.g$Shape == "flat"] + pf.g$pNcat.hi[pf.g$Shape == "peduncular"]
pf.g.plus <- rbind(pf.g,pf.g.tot)
pf.g.plus$Shape <- fct_relevel(pf.g.plus$Shape,c("total","sessile","peduncular","flat"))
# manual jitter
pf.g.plus$age[pf.g.plus$AgeGroup == ">84" & pf.g.plus$Shape == "total"] <- pf.g.plus$age[pf.g.plus$AgeGroup == ">84" & pf.g.plus$Shape == "total"] +.4
pf.g.plus$age[pf.g.plus$AgeGroup == ">84" & pf.g.plus$Shape == "peduncular"] <- pf.g.plus$age[pf.g.plus$AgeGroup == ">84" & pf.g.plus$Shape == "peduncular"] +.4

pf.2.tot <- pf.2
pf.2.tot <- subset(pf.2.tot, Shape == "sessile")
pf.2.tot <- droplevels(pf.2.tot)
levels(pf.2.tot$Shape)[levels(pf.2.tot$Shape)=="sessile"] <- "total"
str(pf.2.tot)
pf.2.tot$pNcat <- pf.2$pNcat[pf.2$Shape == "sessile"] + pf.2$pNcat[pf.2$Shape == "flat"] + pf.2$pNcat[pf.2$Shape == "peduncular"]
pf.2.plus <- rbind(pf.2,pf.2.tot)
pf.2.plus$Shape <- fct_relevel(pf.2.plus$Shape,c("total","sessile","peduncular","flat"))

fp.1 <- ggplot() + 
  #ggtitle(shp) +
  geom_point(data = pf.g.plus, aes(x = age, y = pNcat*100, shape = Source, color = Shape), size = 4) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  geom_linerange(data = pf.g.plus, aes(x = age, y = pNcat*100, ymin = pNcat.lo*100, ymax = pNcat.hi*100), size = 0.75) +
  geom_line(data = pf.2.plus, aes(x = age, y = pNcat*100, color = Shape, linetype = Period), size = 1) + 
  facet_grid(Sex ~ .) +
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name = "Prevalence (%)") +
  scale_color_manual(values=cbPalette[c(1,4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F) + 
  theme(text = element_text(size=15),legend.position = c(0.18,0.85)) 
print(fp.1)

