#----------------------------------------------
# adeno: add outpatients with N=0
# and streamline data set
# based on adenoma prevalence
# jck, 2021/09/16
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects 

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma" # project root directory
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
statdir 
datdir 

#----------------------------------------------------------------------------------
# adenoma prevalence from 
# Corley et al. Clin Gastroenterol Hepatol 2013 11(2), 172-180
# Table 2
#----------------------------------------------------------------------------------
prev.m <- c(0.25,0.29,0.31,0.34,0.385,0.385,0.385)
prev.w <- c(0.15,0.18,0.22,0.24,0.26,0.26,0.26)
prev.age <- c(52.5,57.5,62.5,67.5,72.5,75,94)
prev.raw <- data.frame(prev.age,prev.m,prev.w)
prev.raw
npts <- dim(prev.raw)[1]
mt.m <- vector()
mt.w <- vector()
for (i in 1:(npts-1)){
  mt.m[i] <- (prev.m[i+1]-prev.m[i])/(prev.age[i+1]-prev.age[i])
  mt.w[i] <- (prev.w[i+1]-prev.w[i])/(prev.age[i+1]-prev.age[i])
}
ages <- seq(55,94,1)
prev.raw.a.m <- vector()
prev.raw.a.w <- vector()
for(i in 1:3){
  prev.raw.a.m[i] <- prev.m[1]+mt.m[1]*(ages[i]-prev.age[1])
  prev.raw.a.w[i] <- prev.w[1]+mt.w[1]*(ages[i]-prev.age[1])
}
for(i in 4:8){
  prev.raw.a.m[i] <- prev.m[2]+mt.m[2]*(ages[i]-prev.age[2])
  prev.raw.a.w[i] <- prev.w[2]+mt.w[2]*(ages[i]-prev.age[2])
}
for(i in 9:13){
  prev.raw.a.m[i] <- prev.m[3]+mt.m[3]*(ages[i]-prev.age[3])
  prev.raw.a.w[i] <- prev.w[3]+mt.w[3]*(ages[i]-prev.age[3])
}
for(i in 14:18){
  prev.raw.a.m[i] <- prev.m[4]+mt.m[4]*(ages[i]-prev.age[4])
  prev.raw.a.w[i] <- prev.w[4]+mt.w[4]*(ages[i]-prev.age[4])
}
for(i in 19:21){
  prev.raw.a.m[i] <- prev.m[5]+mt.m[5]*(ages[i]-prev.age[5])
  prev.raw.a.w[i] <- prev.w[5]+mt.w[5]*(ages[i]-prev.age[5])
}
for(i in 22:length(ages)){
  prev.raw.a.m[i] <- prev.m[6]+mt.m[6]*(ages[i]-prev.age[6])
  prev.raw.a.w[i] <- prev.w[6]+mt.w[6]*(ages[i]-prev.age[6])
}
prev.raw.a.m
prev.raw.a.w
plot(x=ages,y=prev.raw.a.m)
plot(x=ages,y=prev.raw.a.w)
mean(prev.raw.a.m)
mean(prev.raw.a.w)
mean(prev.raw.a.m+prev.raw.a.w)/2

#----------------------------------------------------------
# prepare screening data
#----------------------------------------------------------
setwd("~/imodel/colonlmu/data_lmu/adenoma/")
load("adenoJCK2.RData")
adeno <- adenoJCK2

dim(adeno)
# 66232    20
names(adeno)
#[1] "patid"            "sex"              "byr"              "byrcat"           "age"              "agecat"          
#[7] "EXAMINATIONDATE"  "QUARTAL"          "DIAGNOSECOLONCA"  "DIAGNOSEREKTUMCA" "histkarzinom"     "PATIENTRISIKOFAM"
#[13] "PATIENTRISIKOHER" "adenomhist"       "polypcount"       "polypsize"        "polypshape"       "lok"             
#[19] "adv_adenoma"      "adv_npl"          "pscat"   

summary(adeno)

# no cancers in 2009
table(adeno$histkarzinom,adeno$QUARTAL)
#adeno <- adeno[adeno$QUARTAL < 20091,]
adeno <- adeno[adeno$histkarzinom < 1,]
dim(adeno)
# 65761    21

#adeno <- adeno[complete.cases(adeno),] 
#dim(adeno) # 32415    20

# location should be known
#adeno <- adeno[complete.cases(adeno[ , c(18)]),] 
#dim(adeno) # 51843    20

# location, shape, histo should be known
adeno <- adeno[complete.cases(adeno[ , c("adenomhist","polypcount","polypsize","polypshape","lok")]),] 
#adeno <- adeno[complete.cases(adeno[ , c(15,16,17,18)]),] 
dim(adeno) # 50649    21
#summary(adeno)

# adjust age to range of survival data 55-94
table(adeno$agecat)
adeno$age[adeno$age > 94] <- 94

# concatenate location 
adeno$lok2 <- "proximal"
adeno$lok2[adeno$lok == "both"] <- "distboth"
adeno$lok2[adeno$lok == "distal"] <- "distboth"
adeno$lok2 <- as.factor(adeno$lok2)
#adeno$lok2 <- factor(adeno$lok2, levels = c(1:2), labels = c("proximal","distboth"))
table(adeno$lok,adeno$lok2)

# add column with number of patients
adeno$npat <- 1

#----------------------------------------------------------
# generate grouped patient data with adenoma
#----------------------------------------------------------

adpg <- aggregate(adeno$npat,list(adeno$sex,
                                  adeno$age,
                                  adeno$agecat,
                                  adeno$polypshape,
                                  adeno$lok2,
                                  #adeno$adenomhist,
                                  adeno$polypcount,
                                  adeno$pscat), sum)
is.data.frame(adpg)
headline <- c("sex","age","agecat","shape","loca","countcat","sizecat","npat")
names(adpg) <- headline

dim(adpg)
str(adpg)
summary(adpg)

sum(adpg$npat[adpg$sex == "m"])
sum(adpg$npat[adpg$sex == "w"])

#----------------------------------------------------------
# sex & age-specific assignment of patients without adenoma
#----------------------------------------------------------

adM <- subset(adpg, sex == "m")
adW <- subset(adpg, sex == "w")

npatADM <- aggregate(adM$npat,list(adM$age),sum)$x
npatADW <- aggregate(adW$npat,list(adW$age),sum)$x
# adjust for empty age group
npatADW[39] <- 0 # age 93 not present
npatADW[40] <- 2

prev.a.m <- 0.94*prev.raw.a.m # adjustment for Germany
prev.a.w <- 0.94*prev.raw.a.w # adjustment for Germany
plot(x=ages,y=prev.a.m)
plot(x=ages,y=prev.a.w)
prev.mean.w <- sum(prev.a.w*npatADW)/sum(npatADW)
prev.mean.m <- sum(prev.a.m*npatADM)/sum(npatADM)
prev.mean <- (sum(npatADW)*prev.mean.w+sum(npatADM)*prev.mean.m)/(sum(npatADW)+sum(npatADM))
prev.mean.m
prev.mean.w
prev.mean

ntot.a.m <- as.integer(npatADM/prev.a.m+.5)
ntot.a.w <- as.integer(npatADW/prev.a.w+.5)
nfree.a.m <- ntot.a.m - npatADM 
nfree.a.w <- ntot.a.w - npatADW 

sum(npatADM)/sum(ntot.a.m)
sum(npatADW)/sum(ntot.a.w)
sum(npatADM+npatADW)/sum(ntot.a.m+ntot.a.w) #  # should be about 25%

# build agecat
levels(adM$agecat)
agecat <- rep(1,40)
agecat[ages > 59] <- 2
agecat[ages > 64] <- 3
agecat[ages > 69] <- 4
agecat[ages > 74] <- 5
agecat[ages > 79] <- 6
agecat[ages > 84] <- 7
agecat <- factor(agecat, levels = 1:7, labels = levels(adM$agecat))
agecat

adN0M <- data.frame("m",ages,agecat,"none","none","0","<DL",nfree.a.m)
names(adN0M) <- headline
adN0W <- data.frame("w",ages,agecat,"none","none","0","<DL",nfree.a.w)
names(adN0W) <- headline

adN0 <- rbind(adN0M,adN0W)
adN0$sex <- as.factor(adN0$sex)
adN0$shape <- as.factor(adN0$shape)
adN0$loca <- as.factor(adN0$loca)
adN0$countcat <- as.factor(adN0$countcat)
adN0$sizecat <- as.factor(adN0$sizecat)

str(adN0)

#----------------------------------------------------------
# build complete data frame with/without adenoma
#----------------------------------------------------------
adenoN0 <- rbind(adpg,adN0)
dim(adenoN0)
str(adenoN0)
summary(adenoN0)

#----------------------------------------------------------
# count assignment
#----------------------------------------------------------
adenoN0$pno <- 0
adenoN0$pno[adenoN0$countcat == "1"] <- 1
adenoN0$pno[adenoN0$countcat == "2-4"] <- 2 # most probable number
adenoN0$pno[adenoN0$countcat == ">=5"] <- 5 # most probable number

#----------------------------------------------------------
# size (cm) assignment
#----------------------------------------------------------
sizemin <-  exp((log(0.25)+log(0.5))/2)
adenoN0$size <- 0
adenoN0$size[adenoN0$sizecat == "<0.5"] <- sizemin
adenoN0$size[adenoN0$sizecat == "0.5-1"] <- sizemin*2
adenoN0$size[adenoN0$sizecat == "1-2"] <- sizemin*4
adenoN0$size[adenoN0$sizecat == ">2"] <- sizemin*8

#----------------------------------------------------------
# build central age: acen
#----------------------------------------------------------
adenoN0$acen <- (adenoN0$age-65)/10

#----------------------------------------------------------
# cell size assignment
#----------------------------------------------------------
ymin <- 50
adenoN0$ymin <- ymin # physical DL
sefl <- subset(adenoN0, shape == "sessile" | shape == "flat")
pedu <- subset(adenoN0, shape == "peduncular")

none <- subset(adenoN0, shape == "none")
none$ylo2d <- 0
none$ys2d <- 0
none$yhi2d <- 0
none$ylo3d <- 0
none$ys3d <- 0
none$yhi3d <- 0

sefl$ys2d <- 0
sefl$ys2d[sefl$sizecat == "<0.5"] <- 100
sefl$ys2d[sefl$sizecat == "0.5-1"] <- 400
sefl$ys2d[sefl$sizecat == "1-2"] <- 1600
sefl$ys2d[sefl$sizecat == ">2"] <- 6400

sefl$ylo2d <- 0
sefl$ylo2d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo2d[sefl$sizecat == "0.5-1"] <- 200
sefl$ylo2d[sefl$sizecat == "1-2"] <- 800
sefl$ylo2d[sefl$sizecat == ">2"] <- 3200

sefl$yhi2d <- 0
sefl$yhi2d[sefl$sizecat == "<0.5"] <- 200
sefl$yhi2d[sefl$sizecat == "0.5-1"] <- 800
sefl$yhi2d[sefl$sizecat == "1-2"] <- 3200
sefl$yhi2d[sefl$sizecat == ">2"] <- 12800

sefl$ys3d <- 0
sefl$ys3d[sefl$sizecat == "<0.5"] <- 141
sefl$ys3d[sefl$sizecat == "0.5-1"] <- 1131
sefl$ys3d[sefl$sizecat == "1-2"] <- 9051
sefl$ys3d[sefl$sizecat == ">2"] <- 72408

sefl$ylo3d <- 0
sefl$ylo3d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo3d[sefl$sizecat == "0.5-1"] <- 400
sefl$ylo3d[sefl$sizecat == "1-2"] <- 3200
sefl$ylo3d[sefl$sizecat == ">2"] <- 25600

sefl$yhi3d <- 0
sefl$yhi3d[sefl$sizecat == "<0.5"] <- 400
sefl$yhi3d[sefl$sizecat == "0.5-1"] <- 3200
sefl$yhi3d[sefl$sizecat == "1-2"] <- 25600
sefl$yhi3d[sefl$sizecat == ">2"] <- 204800

# set very small pedu's to zero
pedu$ys2d <- 0
pedu$ys2d[pedu$sizecat == "<0.5"] <- 25
pedu$ys2d[pedu$sizecat == "0.5-1"] <- 100
pedu$ys2d[pedu$sizecat == "1-2"] <- 400
pedu$ys2d[pedu$sizecat == ">2"] <- 1600

pedu$ylo2d <- 0
pedu$ys2d[pedu$sizecat == "<0.5"] <- 13
pedu$ylo2d[pedu$sizecat == "0.5-1"] <- 50
pedu$ylo2d[pedu$sizecat == "1-2"] <- 200
pedu$ylo2d[pedu$sizecat == ">2"] <- 800

pedu$yhi2d <- 0
pedu$ys2d[pedu$sizecat == "<0.5"] <- 50
pedu$yhi2d[pedu$sizecat == "0.5-1"] <- 200
pedu$yhi2d[pedu$sizecat == "1-2"] <- 800
pedu$yhi2d[pedu$sizecat == ">2"] <- 3200

pedu$ys3d <- 0
pedu$ys3d[pedu$sizecat == "<0.5"] <- 18
pedu$ys3d[pedu$sizecat == "0.5-1"] <- 141
pedu$ys3d[pedu$sizecat == "1-2"] <- 1131
pedu$ys3d[pedu$sizecat == ">2"] <- 9051

pedu$ylo3d <- 0
pedu$ys3d[pedu$sizecat == "<0.5"] <- 6
pedu$ylo3d[pedu$sizecat == "0.5-1"] <- 50
pedu$ylo3d[pedu$sizecat == "1-2"] <- 400
pedu$ylo3d[pedu$sizecat == ">2"] <- 3200

pedu$yhi3d <- 0
pedu$ys3d[pedu$sizecat == "<0.5"] <- 50
pedu$yhi3d[pedu$sizecat == "0.5-1"] <- 400
pedu$yhi3d[pedu$sizecat == "1-2"] <- 3200
pedu$yhi3d[pedu$sizecat == ">2"] <- 25600

pedu$sizecat[pedu$ys2d == 0] <- "<DL"
pedu$shape[pedu$ys2d == 0] <- "none"
pedu$loca[pedu$ys2d == 0] <- "none"
pedu$countcat[pedu$ys2d == 0] <- "0"

#summary(pedu)
#--------------------------------------------------------
# check shares
#--------------------------------------------------------
ef <- rbind(sefl,pedu,none)
dim(ef)
str(ef)
summary(ef)

mADW <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[1:3])
mN0W <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[4])
mADM <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[5:7])
mN0M <- sum(aggregate(ef$npat,list(ef$shape,ef$sex),sum)$x[8])

round(mADW/(mADW+mN0W),3) # 0.204
round(mN0W/(mADW+mN0W),3) # 0.796
round(mADM/(mADM+mN0M),3) # 0.305
round(mN0M/(mADM+mN0M),3) # 0.695
round((mADM+mADW)/(mADM+mN0M+mADW+mN0W),3) # 0.251
round((mN0M+mN0W)/(mADM+mN0M+mADW+mN0W),3) # 0.749

#--------------------------------------------------------
# prepare shape data with optimal patient groups: sessile
#--------------------------------------------------------
adenoPG <- ef
justsess <- subset(adenoPG, shape == "sessile")
notsess <- subset(adenoPG, shape != "sessile")

notsess$sizecat <- "<DL"
notsess$shape <- "none"
notsess$loca <- "none"
notsess$countcat <- "0"
notsess$pno <- 0
notsess$size <- 0
notsess$ylo2d <- 0
notsess$ys2d <- 0
notsess$yhi2d <- 0
notsess$ylo3d <- 0
notsess$ys3d <- 0
notsess$yhi3d <- 0

resess <- rbind(justsess,notsess)
resess <- droplevels(resess)
str(resess)
table(resess$shape)
names(resess)
newline <- c("sex","age","agecat","shape","loca","countcat","sizecat","pno","size","ymin","ylo2d","ys2d","yhi2d","ylo3d","ys3d","yhi3d","npat")
sess <- with(resess,aggregate(npat,list(sex,age,agecat,shape,loca,countcat,sizecat,pno,size,ymin,ylo2d,ys2d,yhi2d,ylo3d,ys3d,yhi3d),sum))
names(sess) <- newline

dim(justsess)
dim(notsess)
dim(resess)
dim(sess)
str(sess)
aggregate(sess$npat,list(sess$agecat),sum)
sum(sess$npat)
sum(justsess$npat)+sum(notsess$npat)

#--------------------------------------------------------
# prepare shape data with optimal patient groups: flat
#--------------------------------------------------------
justflat <- subset(adenoPG, shape == "flat")
notflat <- subset(adenoPG, shape != "flat")

notflat$sizecat <- "<DL"
notflat$shape <- "none"
notflat$loca <- "none"
notflat$countcat <- "0"
notflat$pno <- 0
notflat$size <- 0
notflat$ylo2d <- 0
notflat$ys2d <- 0
notflat$yhi2d <- 0
notflat$ylo3d <- 0
notflat$ys3d <- 0
notflat$yhi3d <- 0

reflat <- rbind(justflat,notflat)
reflat <- droplevels(reflat)
str(reflat)
table(reflat$shape)
names(reflat)
newline <- c("sex","age","agecat","shape","loca","countcat","sizecat","pno","size","ymin","ylo2d","ys2d","yhi2d","ylo3d","ys3d","yhi3d","npat")
flat <- with(reflat,aggregate(npat,list(sex,age,agecat,shape,loca,countcat,sizecat,pno,size,ymin,ylo2d,ys2d,yhi2d,ylo3d,ys3d,yhi3d),sum))
names(flat) <- newline

dim(justflat)
dim(notflat)
dim(reflat)
dim(flat)
str(flat)
aggregate(flat$npat,list(flat$agecat),sum)
sum(flat$npat)
sum(justflat$npat)+sum(notflat$npat)

#--------------------------------------------------------
# prepare shape data with optimal patient groups: pedu
#--------------------------------------------------------
justpedu <- subset(adenoPG, shape == "peduncular")
notpedu <- subset(adenoPG, shape != "peduncular")

notpedu$sizecat <- "<DL"
notpedu$shape <- "none"
notpedu$loca <- "none"
notpedu$countcat <- "0"
notpedu$pno <- 0
notpedu$size <- 0
notpedu$ylo2d <- 0
notpedu$ys2d <- 0
notpedu$yhi2d <- 0
notpedu$ylo3d <- 0
notpedu$ys3d <- 0
notpedu$yhi3d <- 0

repedu <- rbind(justpedu,notpedu)
repedu <- droplevels(repedu)
str(repedu)
table(repedu$shape)
names(repedu)
newline <- c("sex","age","agecat","shape","loca","countcat","sizecat","pno","size","ymin","ylo2d","ys2d","yhi2d","ylo3d","ys3d","yhi3d","npat")
pedu <- with(repedu,aggregate(npat,list(sex,age,agecat,shape,loca,countcat,sizecat,pno,size,ymin,ylo2d,ys2d,yhi2d,ylo3d,ys3d,yhi3d),sum))
names(pedu) <- newline

dim(justpedu)
dim(notpedu)
dim(repedu)
dim(pedu)
str(pedu)
aggregate(pedu$npat,list(pedu$agecat),sum)
sum(pedu$npat)
sum(justpedu$npat)+sum(notpedu$npat)

#----------------------------------------------------
# check patient numbers
#----------------------------------------------------
sum(sess$npat) #201690
aggregate(sess$npat,list(sess$shape,sess$sex),sum)
sum(aggregate(sess$npat,list(sess$shape,sess$sex),sum)$x)
sum(pedu$npat) # 201690
aggregate(pedu$npat,list(pedu$shape,pedu$sex),sum)
sum(aggregate(pedu$npat,list(pedu$shape,pedu$sex),sum)$x)
sum(flat$npat) # 201690
aggregate(flat$npat,list(flat$shape,flat$sex),sum)
sum(aggregate(flat$npat,list(flat$shape,flat$sex),sum)$x)

sum(adenoPG$npat) # 201690
aggregate(adenoPG$npat,list(adenoPG$shape,adenoPG$sex),sum)
sum(aggregate(adenoPG$npat,list(adenoPG$shape,adenoPG$sex),sum)$x)

round(1 - aggregate(sess$npat,list(sess$shape),sum)$x[2]/sum(sess$npat),4) # 0.181
round(1 - aggregate(pedu$npat,list(pedu$shape),sum)$x[2]/sum(pedu$npat),4) # 0.041
round(1 - aggregate(flat$npat,list(flat$shape),sum)$x[2]/sum(flat$npat),4) # 0.0292
round(aggregate(adenoPG$npat,list(adenoPG$shape),sum)$x[4]/sum(adenoPG$npat),4) # 0.7489

# write data files into project directory
#setwd(datdir)
save(adenoPG, file = "adenoPG-20211103-raw.Rdata")
#save(sess, file = "sessPG-20210915.Rdata")
#save(flat, file = "flatPG-20210915.Rdata")
save(pedu, file = "peduPG-2021103-raw.Rdata")

#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

pf <- adenoPG
summary(pf)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
#myPalette <- c(cbbPalette[2],cbbPalette[6])
myPalette <- c(cbPalette[2],cbPalette[4],cbPalette[7],cbPalette[1])

library(ggplot2)

fp.1 <- ggplot() + 
  ggtitle("Age & sex specific patient numbers, 2021/11/04") + 
  geom_bar(data = pf, aes(x=agecat, y=npat+1, fill=shape), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = surv, aes(x=agecat, y=npat,fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(sex ~ .) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  scale_y_continuous(name="No. of patients", trans = 'log10') +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12)) 
#  + theme_bw()  # use a white background
print(fp.1)

#-----------------------------------------
# reproduce imposed prevalence and plot
#-----------------------------------------

pf.prev <- aggregate(pf$npat,list(pf$sex,pf$shape,pf$agecat),sum)
names(pf.prev) <- c("Sex","Shape","agecat","npat")
help1 <- split(pf.prev,pf.prev$Sex)
pf.w <- help1[[1]]
pf.m <- help1[[2]]
sum(pf.w$npat)
sum(pf.m$npat)

pf.ac.m <- aggregate(pf.m$npat,list(pf.m$agecat),sum)
pf.ac.w <- aggregate(pf.w$npat,list(pf.w$agecat),sum)

help2.m <- split(pf.m,pf.m$agecat)
help2.w <- split(pf.w,pf.w$agecat)

for(i in 1:7){
  help2.m[[i]]$nagrp <- pf.ac.m$x[i] 
  help2.w[[i]]$nagrp <- pf.ac.w$x[i] 
}

pf.p.m <- help2.m[[1]]
pf.p.w <- help2.w[[1]]
for(i in 2:7){
  pf.p.m <- rbind(pf.p.m,help2.m[[i]])
  pf.p.w <- rbind(pf.p.w,help2.w[[i]])
}
pf.p <- rbind(pf.p.m,pf.p.w)
pf.p$ppat <- pf.p$npat/pf.p$nagrp
pf.p$ppat[pf.p$Shape == "none"] <- 1 - pf.p$ppat[pf.p$Shape == "none"]
levels(pf.p$Shape)[4] <- "all"
pf.p

fp.2 <- ggplot() + 
  ggtitle("Age & sex specific prevalence, 2021/11/04") + 
  geom_bar(data = pf.p, aes(x=agecat, y = ppat, fill=Shape), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = surv, aes(x=agecat, y=npat,fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(Sex ~ .) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  scale_y_continuous(name="Prevalence") +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12)) 
#  + theme_bw()  # use a white background
print(fp.2)


