#----------------------------------------------
# plot nu pardep age
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-----------------------------------------------------
# read nu pardep with model uncertainties
#------------------------------------------------------
setwd(curvdir)
# read model prediction from age 20,90
load(file="pardep-nu-unc-a55_90.Rdata")

ec$Shape[ec$Shape == "all"] <- "all shapes"
ec$Shape <- fct_relevel(ec$Shape, "all shapes","sessile","peduncular", "flat,2d","flat,3d")
ec$Sex <- fct_relevel(ec$Sex, "women","men")
ec

#--------------------------------------
# start plotting
#--------------------------------------

setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(aes(y=ncell, color = Shape, linetype = Sex), size = 1) +
  geom_line(data = ec, aes(x=age, y=numn, color = Shape), size = 1) +
  geom_ribbon(data = subset(ec, Shape == "all"), aes(x=age, ymin=nulo, ymax=nuhi, group = Shape), linetype=0, alpha=0.1) +
  #geom_line(data = ec, aes(x=age, y=haz, color = Shape), size = 1) +
  #geom_ribbon(data = ec, aes(x=age, ymin=hazlo, ymax=hazhi, group = Shape), linetype=0, alpha=0.1) +
  #geom_point(data = cf.age, aes(x=mage, y=chaz, color = Shape, shape = Sex), size = 4) + 
  #geom_linerange(data = cf.age, aes(x = mage, y=chaz, ymax = chaz.hi, ymin = chaz.lo), size = .75) +
  facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  #scale_y_log10(name = bquote('Hazard '(yr^-1)),
                #breaks = trans_breaks("log10", function(x) 10^x),
  #              labels = trans_format("log10", math_format(10^.x))) +
  scale_y_continuous(name="parameter \u03BD [1/yr]") +
  scale_color_manual(values=cbPalette[c(1,4,7,2,3)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.85)) 
#  + theme_bw()  # use a white background
print(fp.1)

fp.2 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(aes(y=ncell, color = Shape, linetype = Sex), size = 1) +
  geom_line(data = ec, aes(x=age, y=numn*1e6, color = Shape), size = 1) +
  geom_ribbon(data = subset(ec, Shape == "all"), aes(x=age, ymin=nulo*1e6, ymax=nuhi*1e6, group = Shape), linetype=0, alpha=0.1) +
  #geom_line(data = ec, aes(x=age, y=haz, color = Shape), size = 1) +
  #geom_ribbon(data = ec, aes(x=age, ymin=hazlo, ymax=hazhi, group = Shape), linetype=0, alpha=0.1) +
  #geom_point(data = cf.age, aes(x=mage, y=chaz, color = Shape, shape = Sex), size = 4) + 
  #geom_linerange(data = cf.age, aes(x = mage, y=chaz, ymax = chaz.hi, ymin = chaz.lo), size = .75) +
  facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  #scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(60,90,10), 
                     sec.axis = sec_axis(~. -2007, name = "Birth year", 
                                         labels = c("1950","1940","1930","1920"), breaks = seq(-1950,-1920,10))) +
  scale_y_log10(name="Transformation rate \u03BD per 10⁶ yr") +
  #scale_y_continuous(expression('Parameter \u03BD per 10⁶ yr' ^ -1)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2,3)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.48)) 
#  + theme_bw()  # use a white background
print(fp.2)

fp.3 <- ggplot() + 
  #ggtitle("flat, pref") +
  #geom_line(aes(y=ncell, color = Shape, linetype = Sex), size = 1) +
  geom_line(data = ec, aes(x=age, y=numn, color = Shape), size = 1) +
  geom_ribbon(data = subset(ec, Shape == "all"), aes(x=age, ymin=nulo, ymax=nuhi, group = Shape), linetype=0, alpha=0.1) +
  #geom_line(data = ec, aes(x=age, y=haz, color = Shape), size = 1) +
  #geom_ribbon(data = ec, aes(x=age, ymin=hazlo, ymax=hazhi, group = Shape), linetype=0, alpha=0.1) +
  #geom_point(data = cf.age, aes(x=mage, y=chaz, color = Shape, shape = Sex), size = 4) + 
  #geom_linerange(data = cf.age, aes(x = mage, y=chaz, ymax = chaz.hi, ymin = chaz.lo), size = .75) +
  facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  #scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(55,90,5)) +
  scale_x_continuous(name = "Age (yr)", limits = c(55,90), breaks = seq(60,90,10), 
                     sec.axis = sec_axis(~. -2007, name = "Birth year", 
                                         labels = c("1950","1940","1930","1920"), breaks = seq(-1950,-1920,10))) +
  scale_y_log10(name="Transformation rate \u03BD per yr") +
  #scale_y_continuous(expression('Parameter \u03BD per 10⁶ yr' ^ -1)) +
  scale_color_manual(values=cbPalette[c(1,4,7,2,3)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.49)) 
#  + theme_bw()  # use a white background
print(fp.3)


