#----------------------------------------------
# adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#--------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)
library(corrplot)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

shp <- character()
#shp <- "all"
#shp <- "flat"
shp <- "sessile"
#shp <- "peduncular"

noad <- character()
noad <- "wN0"
#noad <- "noN0"

loca <- character()
loca <- "all"

sexc <- character()
#sexc <- "m"
sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K0"
#mmname <- "K1app"
mmname <- "K2"

# likelihood
likc <- character()
likc <- "dist"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,"-atrend",sep="") # age trend version
#fname <- paste(fname,"-std",sep="") # std version

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

atr <- "atrend"
# set pardir
{
  if (mdv == "grid" & atr =="atrend"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
  else if (mdv == "grid" & atr == "std"){thispardir <- gstdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#-----------------------------------------------------------------------------
# read data
#-----------------------------------------------------------------------------
setwd(datdir)
load(file = "nu65fit-canag.Rdata")
cf <- subset(cf, Shape != "flat,2d")
#cf <- subset(cf, chaz > 0)
#names(cf)[1] <- "Shape"
#names(cf)[2] <- "Sex"
#cf$Sex[cf$Sex == "w"] <- "women"
#cf$Sex[cf$Sex == "m"] <- "men"
#cf$mage[cf$Shape == "flat"] <- cf$mage[cf$Shape == "flat"] - 1
#cf$mage[cf$Shape == "peduncular"] <- cf$mage[cf$Shape == "peduncular"] + 1
cf$Sex <- fct_rev(cf$Sex)
cf$pyr10k <- cf$pyr*1e-4
names(cf)[5] <- "cases"
cf
#--------------------------------
# fitting simple descriptive models
#--------------------------------
af <- subset(cf, agecat != "total")
af$lage65 <- log(af$mage/65)
# Attention: parametric byr, cyr models are dangerous
desc.0 <- glm(cases ~ lage65 + Sex + Shape, family = poisson(link = "log"), offset = log(pyr10k), data = af)
summary(desc.0) # AIC: 180.15
#summary(desc.0,corr=T)
#--------------------------------------------
# statistical analysis of descriptive models
#--------------------------------------------
#assign desc for statistical analysis
desc <- desc.0

# Npar
length(desc$coefficients)
# Poisson deviance
desc$aic - 2*length(desc$coefficients)
# Poisson, alternative method
rpos <- -dpois (ff$ncanc, predict (desc, type = "response"), log = TRUE)
2*sum(rpos)

# residual deviance
rd <- residuals(desc,type="deviance") 
sum (rd^2)

# dispersion parameter from Pearson residuals
rp <- residuals(desc,type="pearson")
sum(rp^2)/df.residual(desc)

# plot CIs from likelihood profile
confint(desc)

#--------------------------------
# TSCE model
#--------------------------------
tsce0 <- function(X0, gam0, del0) 
{ 
  age <- df$mage
  pyr <- df$pyr
  
  X <- exp(X0)
  gamma <- gam0
  d <- exp (del0)
  q <- 0.5*(sqrt(gamma^2+4*d)-gamma)
  
  haz0 <- X * (exp((gamma+2*q)*age)-1)/(gamma + q*(exp((gamma+2*q)*age)+1)) 
  
  return (pyr*haz0)
}

#---------------------------------------------------------------
# 4sce
#---------------------------------------------------------------
# Meza et al. PNAS 2008, supplement
oneminusS2 <- function(u,t,rho,gam,del)
{
  srt <- sqrt(gam^2 + 4*del)
  p <- -0.5*(srt + gam)
  q <- 0.5*(srt - gam)
  dage <- (t-u)
  func <- (q-p)/(q*exp(-p*dage) - p*exp(-q*dage))
 
  return(1 - func^rho)
}

# cases for hybrid 4SCE model
c4sce0 <- function(X0, rho0, gam0, del0) 
{ 
  age <- df$mage
  pyr <- df$pyr
  # integrate 1-S2 Meza et al. PNAS 2008, supplement
  ndim <- length(age)
  intfunc <- vector()
#  for(i in 1:ndim)
#  {intfunc[i] <- integrate(oneminusS2, lower = 0, upper = age[i], t = age[i], rho=r_b, gam=g_b, del=exp(d_b))$value}
  intfunc <- unlist(lapply(1:ndim, 
                           function(i) integrate(oneminusS2, lower = 0, upper = age[i], t = age[i], 
                                                 rho=exp(rho0), gam=gam0, del=exp(del0))$value))
  #cat(sprintf("byrX: %f, cyrX: %f, X: %g, rho: %f, gam: %f, del: %g\n", byrX, cyrX, X, r_b, g_b, d_b))
  hazard <- exp(X0) * intfunc 
  return (pyr * hazard)
}

nueffa <- function(nu0, nuAge) 
{ 
  age <- df$mage
  pyr <- df$pyr
  eCell <- df$eCell_0
  
  acen <- (age-65)/10

  hazard <- eCell*exp(nu0+nuAge*acen)

  return (pyr * hazard)
}

#----------------------------------------------------------
# Poisson fit
#----------------------------------------------------------
df <- subset(cf, Sex == sexc & Shape == shp & agecat != "total")
df.p <- subset(cf, Sex == sexc & Shape == shp & agecat == "55-59")
upar <- vector()
upar[1] <- log(df.p$nu65)
upar[2] <- df.p$cacen
lambda <- nueffa (nu0 = upar[1], nuAge = upar[2])
#lambda
-2*sum(dpois (df$cases, lambda, log = TRUE))

mle.1 <- mle2(cases ~ dpois (lambda = nueffa(nu0, nuAge)), 
              start=list(nu0 = upar[1], nuAge = upar[2]), 
              parameters=list(nu0~1, nuAge~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.1)
AIC(mle.1)

# AIC
rn <- sum(dpois (df$cases, df$cases, log = TRUE))
npar <- length(coef(mle.1,exclude.fixed=T))
rd <- -2*(as.numeric(logLik(mle.1)) - rn)
AICrd <- rd + 2*npar
AICrd

# Pearson residuals
res <- residuals(mle.1,type="pearson")
degf <- length(df$cases) - npar
pres <- sum(res^2)/degf
pres

#
prf <- profile(mle.1)
plot(prf)
confint(prf)

# TSCE
tpar <- vector()
tpar[1] <- -15.54549
tpar[2] <- 0.05536532
tpar[3] <- -9.242768
mle.2 <- mle2(cases ~ dpois (lambda = tsce0(X0, gam0, del0)), 
              start=list(X0 = tpar[1], gam0 = tpar[2], del0 = tpar[3]), 
              parameters=list(X0~1, gam0~1, del0~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.2)
AIC(mle.2)

# 4SCE
tpar <- vector()
tpar[1] <- exp(dpar$parval[1])
tpar[2] <- exp(dpar$parval[4])
tpar[3] <- dpar$parval[3]
tpar[4] <- -9
mle.3 <- mle2(cases ~ dpois (lambda = c4sce0(X0, rho0, gam0, del0)), 
              start=list(X0 = tpar[1], rho0 = tpar[2], gam0 = tpar[3], del0 = tpar[4]), 
              parameters=list(X0~1, rho0~1, gam0~1, del0~1),
              fixed=list(rho0 = tpar[2]),
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.3)
AIC(mle.3)

#---------------------------------------
# alternative method
#---------------------------------------
# X0 <- -15.54549
# gam0 <- 0.05536532
# del0 <- -9.242768
tsce0 <- function(par) 
{ 
  X0 <- par[1]
  gam0 <- par[2]
  del0 <- par[3]
  
  age <- df$mage
  pyr <- df$pyr10k
  
  X <- exp(X0)
  gamma <- gam0
  d <- exp (del0)
  q <- 0.5*(sqrt(gamma^2+4*d)-gamma)
  
  haz0 <- X * (exp((gamma+2*q)*age)-1)/(gamma + q*(exp((gamma+2*q)*age)+1)) 
  
  return (pyr*haz0)
}

c4sce_2 <- function(par) 
{ 
  X0 <- par[1]
  rho0 <-  par[2]
  gam0 <- par[3]
  del0 <- par[4]
  
  age <- df$mage
  pyr <- df$pyr10k
  
  X <- exp(X0)
  d <- exp (del0)
  
  # integrate 1-S2 Meza et al. PNAS 2008, supplement
  ndim <- length(age)
  intfunc <- vector()
  #  for(i in 1:ndim)
  #  {intfunc[i] <- integrate(oneminusS2, lower = 0, upper = age[i], t = age[i], rho=r_b, gam=g_b, del=exp(d_b))$value}
  intfunc <- unlist(lapply(1:ndim, 
                           function(i) integrate(oneminusS2, lower = 0, upper = age[i], t = age[i], 
                                                 rho = rho0, gam = gam0, del = d)$value))
  #cat(sprintf("byrX: %f, cyrX: %f, X: %g, rho: %f, gam: %f, del: %g\n", byrX, cyrX, X, r_b, g_b, d_b))
  hazard <- X * intfunc 
  return (pyr * hazard)
}

nueffa_2 <- function(par) 
{ 
  nu65 <- par[1]
  cacen <- par[2]
  
  age <- df$mage
  pyr <- df$pyr10k
  
  eCell <- df$eCell_0
  acen <- (age-65)/10
  
  hazard <- eCell*nu65*exp(cacen*acen)
  
  return (pyr * hazard)
}

# assign model  
model_2 <- nueffa_2

# -log(likelihood)
mloglik <- function(par)
{
  return (-sum(dpois (ff$ncanc, model_2 (par), log = TRUE)))
}

tpar <- upar
-2*sum(dpois (ff$ncanc, model_2 (tpar), log = TRUE))

# model fit
for (i in 1:2)
{
  nlm.1 <- nlminb(start = tpar, objective = mloglik, lower = -Inf, upper = Inf)
}

tpar <- nlm.1$par
#names(nlm.1)

nlm.1$convergence
#nlm.1$iterations
#nlm.1$evaluations

# Poisson deviance from tpmdl
2*nlm.1$objective
# Poisson deviance, direct method
res <- -dpois (ff$ncanc, nueffa_2 (nlm.1$par), log = TRUE)
2*sum(res)
# AIC
2*nlm.1$objective + 2*length(nlm.1$par)
# best estimate deviation
#(nlm.1$par - x[,-1])/x[,-1] * 100

# calculation of Wald-based stdev, p-values and CI from Jonathan Gessendorfer
# Hessian matrix
mdl_hessian <- hessian(func = mloglik, x = nlm.1$par)
is.positive.definite(mdl_hessian, tol=1e-8)

# covariance matrix
covm <- solve(mdl_hessian)

# stdev for parameters (Wald-based)
stdev <- sqrt(diag(ginv(mdl_hessian)))

# z-transformation (t-value)
zval <- nlm.1$par/stdev

# p-value
pval <- 2*pnorm(-abs(zval))

# parameter CI 
upper <- nlm.1$par + qnorm(.975)*stdev
lower <- nlm.1$par - qnorm(.975)*stdev

# plot table
sum_tbl <- cbind(nlm.1$par, stdev, zval, pval, lower, upper)
colnames(sum_tbl) <- c("Estimate", "Std. Error", "z value", "Pr(>|z|)", "95% CI: LB", "95% CI: UB")
print(sum_tbl,digits = 4)

LL <- function(beta, z, x){
  -sum(stats::dpois(x, lambda = exp(z %*% beta), log = TRUE))
}

set.seed(2)
age <- round(exp(rnorm(5000, mean = 2.37, sd = 0.78) - 1))
claim <- rpois(5000, lambda = 0.07)

z1 <- model.matrix(claim ~ 1)
optim(par = 0, fn = LL, z = z1, x = claim)

z2 <- model.matrix(claim ~ age)
optim(par = c(0, 0), fn = LL, z = z2, x = claim)

mle2(minuslogl = function(beta){ LL(beta = beta, z = z1, x = claim) },
     start = list(beta = 0))

mle2(claim~dpois(exp(loglambda)),     ## use log link/exp inverse-link
     data=data.frame(claim,age),      ## need to specify as data frame
     parameters=list(loglambda~age),  ## linear model for loglambda
     start=list(loglambda=0))         ## start values for *intercept*

