#----------------------------------------------
# plot extinction probability
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(statdir)
setwd("pext")

load(file="pext-age65-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.age65.w <- pef
load(file="pext-age65-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.age65.m <- pef

load(file="pext-age65-flat-all-w-3d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 3d"
f.age65.3d.w <- pef
load(file="pext-age65-flat-all-m-3d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 3d"
f.age65.3d.m <- pef
load(file="pext-age65-flat-all-w-2d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 2d"
f.age65.2d.w <- pef
load(file="pext-age65-flat-all-m-2d-K2-dist-atrend.Rdata")
pef$Shape <- "flat, 2d"
f.age65.2d.m <- pef

load(file="pext-age65-peduncular-all-w-2d-K1-dist-atrend.Rdata")
p.age65.w <- pef
load(file="pext-age65-peduncular-all-m-2d-K1-dist-atrend.Rdata")
p.age65.m <- pef

# build and adjust pf
# age group data
pf <- rbind(s.age65.w,s.age65.m,f.age65.3d.w,f.age65.3d.m,f.age65.2d.w,f.age65.2d.m,p.age65.w,p.age65.m)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular","flat, 2d", "flat, 3d"))
pf <- droplevels(pf)
summary(pf)

setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = sizecm, y = pext*100, color = Shape), size = 1) + 
  facet_grid(Sex ~ .) +
  scale_x_continuous(name = "Size (cm)", limits = c(0.2,1.5), breaks = seq(0.2,1.4,0.2)) +
  scale_y_continuous(name = "Extinction probability (%)", limits = c(0,100), breaks = seq(0,100,25)) +
  scale_color_manual(values=cbPalette[c(4,7,3,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F) + 
  theme(text = element_text(size=15),legend.position = c(0.75,0.9)) 
print(fp.1)

fp.2 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = ncell, y = pext*100, color = Shape), size = 1) + 
  facet_grid(Sex ~ .) +
  scale_x_continuous(name = "No. of cells", limits = c(0,1000), breaks = seq(0,1000,200)) +
  scale_y_continuous(name = "Extinction probability (%)", limits = c(0,100), breaks = seq(0,100,25)) +
  scale_color_manual(values=cbPalette[c(4,7,3,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F) + 
  theme(text = element_text(size=15),legend.position = c(0.75,0.9)) 
print(fp.2)
