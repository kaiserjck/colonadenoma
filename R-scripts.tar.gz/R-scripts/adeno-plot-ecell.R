#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(datdir)
df.cancer <- read.csv(file = "cancernu-20220123.csv")

setwd(statdir)
setwd("sizeexp")

headline <- c("Shape","Sex","refage","age","ncell")
p.age.m <- read.csv(file = "ecell-peduncular-pref-age-m.csv")
p.age.m <- data.frame("peduncular","men","trend",p.age.m$age,p.age.m$ncell)
names(p.age.m) <- headline
p.age.w <- read.csv(file = "ecell-peduncular-pref-age-f.csv")
p.age.w <- data.frame("peduncular","women","trend",p.age.w$age,p.age.w$ncell)
names(p.age.w) <- headline

f.age.m <- read.csv(file = "ecell-flat-pref-age-m.csv")
f.age.m <- data.frame("flat","men","trend",f.age.m$age,f.age.m$ncell)
names(f.age.m) <- headline
f.age.w <- read.csv(file = "ecell-flat-pref-age-f.csv")
f.age.w <- data.frame("flat","women","trend",f.age.w$age,f.age.w$ncell)
names(f.age.w) <- headline

f2d.age.m <- read.csv(file = "ecell-flat-2d-age-m.csv")
f2d.age.m <- data.frame("flat,2d","men","trend",f2d.age.m$age,f2d.age.m$ncell)
names(f2d.age.m) <- headline
f2d.age.w <- read.csv(file = "ecell-flat-2d-age-w.csv")
f2d.age.w <- data.frame("flat,2d","women","trend",f2d.age.w$age,f2d.age.w$ncell)
names(f2d.age.w) <- headline

s.age.m <- read.csv(file = "ecell-sessile-pref-age-m.csv")
s.age.m <- data.frame("sessile","men","trend",s.age.m$age,s.age.m$ncell)
names(s.age.m) <- headline
s.age.w <- read.csv(file = "ecell-sessile-pref-age-f.csv")
s.age.w <- data.frame("sessile","women","trend",s.age.w$age,s.age.w$ncell)
names(s.age.w) <- headline

p.a65.m <- read.csv(file = "ecell-peduncular-pref-a65-m.csv")
p.a65.m <- data.frame("peduncular","men","age65",p.a65.m$age,p.a65.m$ncell)
names(p.a65.m) <- headline
p.a65.w <- read.csv(file = "ecell-peduncular-pref-a65-f.csv")
p.a65.w <- data.frame("peduncular","women","age65",p.a65.w$age,p.a65.w$ncell)
names(p.a65.w) <- headline

f.a65.m <- read.csv(file = "ecell-flat-pref-a65-m.csv")
f.a65.m <- data.frame("flat","men","age65",f.a65.m$age,f.a65.m$ncell)
names(f.a65.m) <- headline
f.a65.w <- read.csv(file = "ecell-flat-pref-a65-f.csv")
f.a65.w <- data.frame("flat","women","age65",f.a65.w$age,f.a65.w$ncell)
names(f.a65.w) <- headline

f2d.a65.m <- read.csv(file = "ecell-flat-2d-a65-m.csv")
f2d.a65.m <- data.frame("flat,2d","men","age65",f2d.a65.m$age,f2d.a65.m$ncell)
names(f2d.a65.m) <- headline
f2d.a65.w <- read.csv(file = "ecell-flat-2d-a65-w.csv")
f2d.a65.w <- data.frame("flat,2d","women","age65",f2d.a65.w$age,f2d.a65.w$ncell)
names(f2d.a65.w) <- headline

s.a65.m <- read.csv(file = "ecell-sessile-pref-a65-m.csv")
s.a65.m <- data.frame("sessile","men","age65",s.a65.m$age,s.a65.m$ncell)
names(s.a65.m) <- headline
s.a65.w <- read.csv(file = "ecell-sessile-pref-a65-f.csv")
s.a65.w <- data.frame("sessile","women","age65",s.a65.w$age,s.a65.w$ncell)
names(s.a65.w) <- headline

# build and adjust pf
pf.age <- rbind(f.age.w,f.age.m,f2d.age.w,f2d.age.m,s.age.w,s.age.m,p.age.w,p.age.m)
pf.a65 <- rbind(f.a65.w,f.a65.m,f2d.a65.w,f2d.a65.m,s.a65.w,s.a65.m,p.a65.w,p.a65.m)
pf <- pf.age
summary(pf)
pf <- droplevels(pf)
#pf$Source <- fct_rev(pf$Source)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("flat","flat,2d","sessile","peduncular"))
#summary(pf)
str(pf)
setwd(plotdir)

#---------------------------------------
# create hazard estimate
#---------------------------------------
pf$haz <- -1
pf$haz[pf$Sex == "men" & pf$Shape == "flat"] <- pf$ncell[pf$Sex == "men" & pf$Shape == "flat"]*
  df.cancer$nu65[df.cancer$sex == "m" & df.cancer$shape == "flat_3d"]
pf$haz[pf$Sex == "women" & pf$Shape == "flat"] <- pf$ncell[pf$Sex == "women" & pf$Shape == "flat"]*
  df.cancer$nu65[df.cancer$sex == "w" & df.cancer$shape == "flat_3d"]
pf$haz[pf$Sex == "men" & pf$Shape == "flat,2d"] <- pf$ncell[pf$Sex == "men" & pf$Shape == "flat,2d"]*
  df.cancer$nu65[df.cancer$sex == "m" & df.cancer$shape == "flat_2d"]
pf$haz[pf$Sex == "women" & pf$Shape == "flat,2d"] <- pf$ncell[pf$Sex == "women" & pf$Shape == "flat,2d"]*
  df.cancer$nu65[df.cancer$sex == "w" & df.cancer$shape == "flat_2d"]
pf$haz[pf$Sex == "men" & pf$Shape == "sessile"] <- pf$ncell[pf$Sex == "men" & pf$Shape == "sessile"]*
  df.cancer$nu65[df.cancer$sex == "m" & df.cancer$shape == "sessile"]
pf$haz[pf$Sex == "women" & pf$Shape == "sessile"] <- pf$ncell[pf$Sex == "women" & pf$Shape == "sessile"]*
  df.cancer$nu65[df.cancer$sex == "w" & df.cancer$shape == "sessile"]
pf$haz[pf$Sex == "men" & pf$Shape == "peduncular"] <- pf$ncell[pf$Sex == "men" & pf$Shape == "peduncular"]*
  df.cancer$nu65[df.cancer$sex == "m" & df.cancer$shape == "peduncular"]
pf$haz[pf$Sex == "women" & pf$Shape == "peduncular"] <- pf$ncell[pf$Sex == "women" & pf$Shape == "peduncular"]*
  df.cancer$nu65[df.cancer$sex == "w" & df.cancer$shape == "peduncular"]


fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf, aes(x=age, y=ncell, color = Shape, linetype = Sex), size = 1) +
  #geom_line(data = pf.2, aes(x = age, y =sizecm, color = Shape)) +
  #facet_grid(Sex ~ .) + 
  #facet_grid(.~AgeGroup) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,85), breaks = seq(40,80,10)) +
  scale_y_continuous(name = "Mean cell number", trans = "log10", labels = scales::scientific) + 
  #scale_y_continuous(name="Mean cell number", limits=c(0.4,1.25), breaks = seq(0.4,1.25,0.2)) +
  #scale_color_manual(values=cbPalette[c(2,4,7)]) +
  scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_linetype_manual(values = c(21, 16)) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.85)) 
#  + theme_bw()  # use a white background
print(fp.1)

# plot with age extrapolation marked
pf.early <- subset(pf, age < 55)
pf.early <- data.frame(pf.early,"early")
names(pf.early)[6] <- "Period"
pf.late <- subset(pf, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[6] <- "Period"

pf.2 <- rbind(pf.early,pf.late)

fp.3 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf.2, aes(x=age, y=ncell, color = Shape,linetype = Period), size = 1) +
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name = "Mean cell number", trans = "log10", labels = scales::scientific) + 
  #scale_color_manual(values=cbPalette[c(2,4,7)]) +
  scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.15,0.9)) 
#  + theme_bw()  # use a white background
print(fp.3)

x <- 1:4
y <- c(0, 0.0001, 0.0002, 0.0003)
dd <- data.frame(x, y)

ggplot(dd, aes(x, y)) + geom_point() +
  scale_y_log10("y",
                breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x)))

x <- 2:4
fp.4 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_line(data = pf.2, aes(x=age, y=ncell, color = Shape,linetype = Period), size = 1) +
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  #scale_y_log10(name = "Mean cell number") + 
  scale_y_log10(name = "Mean cell number",
                #breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  #scale_color_manual(values=cbPalette[c(2,4,7)]) +
  scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(linetype="none") + 
  theme(text = element_text(size=15),legend.position = c(.2,0.37)) 
#  + theme_bw()  # use a white background
print(fp.4)

library(cowplot)
plot_grid(fp.2,fp.4)

