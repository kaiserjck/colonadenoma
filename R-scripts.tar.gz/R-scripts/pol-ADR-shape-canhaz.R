#----------------------------------------------
# adeno: data set with negative screening results
# check age and sex dependence
# based on adenoma prevalence
# keep shape information
# jck, 2022/05/18
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects 

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma" # project root directory
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
statdir 
datdir 

#----------------------------------------------------------
# prepare screening data
#----------------------------------------------------------
setwd("~/imodel/colonlmu/data_lmu/adenoma/")
load("adeno-ADR.Rdata")

dim(adeno)
# 258116     19
table(adeno$dad) # DIAGNOSEADENOMA
#     no    yes 
# 191884  66232 
names(adeno)
#[1] "patid"           "postcode"        "sex"             "byr"             "byrcat"          "age"             "agecat"         
#[8] "pscat"           "EXAMINATIONDATE" "QUARTAL"         "dad"             "lok"             "polypcount"      "polypsize"      
#[15] "polypshape"      "adenomhist"      "histkarzinom"    "adv_adenoma"     "adv_npl" 

adeno <- droplevels(adeno)
str(adeno)
summary(adeno)

# no cancers in 2009
table(adeno$histkarzinom,adeno$QUARTAL, useNA = "ifany")

signif(mean(adeno$age[adeno$histkarzinom == 1 & adeno$QUARTAL < 20091]), 3) # 68.4
adeno <- adeno[adeno$QUARTAL < 20091,]
mean(adeno$age[adeno$histkarzinom == 1])
#adeno <- adeno[adeno$histkarzinom < 1,]
dim(adeno)

#adeno <- adeno[adeno$QUARTAL < 20091,]
length(adeno$dad[adeno$dad == "yes"]) # 47232
sum(adeno$histkarzinom) # 1919
table(adeno$histkarzinom)
#      0      1 
# 256197   1919 

table(adeno$adenomhist[adeno$dad == "yes"],useNA = "always")
# dysplasia          none       tubular tubulovillous       villous          <NA> 
#      1175             0         38039          6465           525          1028 
table(adeno$polypcount[adeno$dad == "yes"],useNA = "always")
#   >=5     0     1   2-4  <NA> 
#  3753     0 22594 20661   224 
table(adeno$polypsize[adeno$dad == "yes"],useNA = "always")
#   0.25  0.75   1.5     2   2.5     4  <NA> 
#  20528 16573  4910  2606  1947   435   233 
table(adeno$polypshape[adeno$dad == "yes"],useNA = "always")
#  flat       none peduncular    sessile       <NA> 
#  5135          0       8117      33741        239 
table(adeno$lok[adeno$dad == "yes"],useNA = "always")
#   both   distal     none proximal     <NA> 
#  12861     8196        0    11940    14235 

dim(adeno)

help1 <- split(adeno,adeno$dad)

acc.org <- help1[[2]] # with adenoma
# complete cases for adenoma
acc <- acc.org[complete.cases(acc.org[ , c("adenomhist","polypcount","polypsize","polypshape","lok","histkarzinom")]),]
dim(acc) # 32415    19
dim(acc.org)[1]- dim(acc)[1] # 14817 records with incomplete information removed
round(dim(acc)[1]/dim(acc.org)[1]*100,1)  # 68.6% remain
table(acc$dad,useNA="always")
# no   yes  <NA> 
#  0 32415     0 

# calculate reduction factor for age and sex
# limit to maximal age
noad <- help1[[1]] # no adenoma
table(noad$dad,useNA="always")
a.o <- subset(acc.org, age < 93)
a.r <- subset(acc, age < 93)
n.o <- subset(noad, age < 93)
a.o$npat <- 1
a.o <- aggregate(a.o$npat,list(a.o$sex,a.o$age), sum)
a.r$npat <- 1
a.r <- aggregate(a.r$npat,list(a.r$sex,a.r$age), sum)
n.o$npat <- 1
n.o <- aggregate(n.o$npat,list(n.o$sex,n.o$age), sum)
# data frame with with reduced number of patients without adenoma
n.r <- n.o
n.r$x <- as.integer(a.r$x/a.o$x*n.o$x+.5)

# concatenate location
table(acc$lok)
acc$lok2 <- "proximal"
acc$lok2[acc$lok == "both"] <- "distboth"
acc$lok2[acc$lok == "distal"] <- "distboth"
acc$lok2 <- as.factor(acc$lok2)
#acc$lok2 <- factor(acc$lok2, levels = c(1:2), labels = c("proximal","distboth"))
table(acc$lok,acc$lok2)

#----------------------------------------------------------
# generate grouped patient data with adenoma
#----------------------------------------------------------
# add column with number of patients
acc$npat <- 1

acc.r <- aggregate(acc$npat,list(acc$sex,
                                  acc$age,
                                  acc$agecat,
                                  acc$histkarzinom,
                                  acc$polypshape,
                                  #acc$lok2,
                                  acc$polypcount,
                                  acc$pscat), sum)
headline <- c("sex","age","agecat","cancer","shape","countcat","sizecat","npat")
names(acc.r) <- headline

dim(acc.r)
str(acc.r)
summary(acc.r)

noad$npat <- 1
noad.o <- aggregate(noad$npat,list(noad$sex,noad$age,noad$agecat), sum)
noad.r <- data.frame(noad.o$Group.1,noad.o$Group.2,noad.o$Group.3,0,"none","0","<DL",noad.o$x)
names(noad.r) <- headline

# replace with reduced number of patients
noad.r$npat[1:76] <- n.r$x # leave age counts >= 93
round(sum(noad.r$npat)/sum(noad.o$x)*100,1) # 68.6%
round(dim(acc)[1]/dim(acc.org)[1]*100,1)  # 68.6% remain

dim(noad.r)
str(noad.r)
summary(noad.r)

adpg <- rbind(acc.r,noad.r)

dim(adpg)
str(adpg)
summary(adpg)

sum(adpg$npat[adpg$sex == "m"]) # 57593
sum(adpg$npat[adpg$sex == "w"]) # 70084
sum(adpg$npat*adpg$cancer) # 296

adpg$pno <- NA
adpg$pno[adpg$countcat == "0"] <- 0
adpg$pno[adpg$countcat == "1"] <- 1
adpg$pno[adpg$countcat == "2-4"] <- 2 # most probable number
adpg$pno[adpg$countcat == ">=5"] <- 5 # most probable number
table(adpg$pno,useNA="always")

sizemin <-  exp((log(0.25)+log(0.5))/2)
adpg$size <- NA
adpg$size[adpg$sizecat == "<DL"] <- 0
adpg$size[adpg$sizecat == "<0.5"] <- sizemin
adpg$size[adpg$sizecat == "0.5-1"] <- sizemin*2
adpg$size[adpg$sizecat == "1-2"] <- sizemin*4
adpg$size[adpg$sizecat == ">2"] <- sizemin*8
table(adpg$size,useNA="always")

#----------------------------------------------------------
# cell size assignment
#----------------------------------------------------------
ymin <- 50
adpg$ymin <- ymin # physical DL

none <- subset(adpg, sizecat == "<DL")
none$ylo2d <- 0
#none$ys2d <- 0
none$yhi2d <- 0
none$ylo3d <- 0
#none$ys3d <- 0
none$yhi3d <- 0


onad <- subset(adpg, sizecat != "<DL")

#onad$ys2d <- 0
#onad$ys2d[onad$sizecat == "<0.5"] <- 100
#onad$ys2d[onad$sizecat == "0.5-1"] <- 400
#onad$ys2d[onad$sizecat == "1-2"] <- 1600
#onad$ys2d[onad$sizecat == ">2"] <- 6400

onad$ylo2d <- 0
onad$ylo2d[onad$sizecat == "<0.5"] <- ymin
onad$ylo2d[onad$sizecat == "0.5-1"] <- 200
onad$ylo2d[onad$sizecat == "1-2"] <- 800
onad$ylo2d[onad$sizecat == ">2"] <- 3200

onad$yhi2d <- 0
onad$yhi2d[onad$sizecat == "<0.5"] <- 200
onad$yhi2d[onad$sizecat == "0.5-1"] <- 800
onad$yhi2d[onad$sizecat == "1-2"] <- 3200
onad$yhi2d[onad$sizecat == ">2"] <- -1

#onad$ys3d <- 0
#onad$ys3d[onad$sizecat == "<0.5"] <- 141
#onad$ys3d[onad$sizecat == "0.5-1"] <- 1131
#onad$ys3d[onad$sizecat == "1-2"] <- 9051
#onad$ys3d[onad$sizecat == ">2"] <- 72408

onad$ylo3d <- 0
onad$ylo3d[onad$sizecat == "<0.5"] <- ymin
onad$ylo3d[onad$sizecat == "0.5-1"] <- 400
onad$ylo3d[onad$sizecat == "1-2"] <- 3200
onad$ylo3d[onad$sizecat == ">2"] <- 25600

onad$yhi3d <- 0
onad$yhi3d[onad$sizecat == "<0.5"] <- 400
onad$yhi3d[onad$sizecat == "0.5-1"] <- 3200
onad$yhi3d[onad$sizecat == "1-2"] <- 25600
onad$yhi3d[onad$sizecat == ">2"] <- -1

#--------------------------------------------------------
# check shares
#--------------------------------------------------------
ef <- rbind(onad,none)

# DIAGNOSEADENOMA
#ef$dad <- "yes"
#ef$dad[ef$sizecat == "<DL"] <- "no"
#ef$dad <- as.factor(ef$dad)

# control for likelihood
#ef$shape <- "all"
#ef$shape[ef$sizecat == "<DL"] <- "none"
#ef$shape <- as.factor(ef$shape)

dim(ef)
str(ef)
summary(ef)

mADW <- sum(aggregate(ef$npat[ef$sizecat != "<DL"],list(ef$sex[ef$sizecat != "<DL"]),sum)$x[1])
mN0W <- sum(aggregate(ef$npat[ef$sizecat == "<DL"],list(ef$sex[ef$sizecat == "<DL"]),sum)$x[1])
mADM <- sum(aggregate(ef$npat[ef$sizecat != "<DL"],list(ef$sex[ef$sizecat != "<DL"]),sum)$x[2])
mN0M <- sum(aggregate(ef$npat[ef$sizecat == "<DL"],list(ef$sex[ef$sizecat == "<DL"]),sum)$x[2])

signif(mADW/(mADW+mN0W),3) # 0.200
signif(mN0W/(mADW+mN0W),3) # 0.800
signif(mADM/(mADM+mN0M),3) # 0.320
signif(mN0M/(mADM+mN0M),3) # 0.680
signif((mADM+mADW)/(mADM+mN0M+mADW+mN0W),3) # 0.254
signif((mN0M+mN0W)/(mADM+mN0M+mADW+mN0W),3) # 0.746

#-----------------------------------------------------
# write data files into project directory
#----------------------------------------------------
#setwd(datdir)
#names(ef)
#adenoPG <- ef
#save(adenoPG, file = "adenoPG-shape-20220518.Rdata")

#-----------------------------------------------
# cancer hazard
#----------------------------------------------
sess <- subset(ef, shape == "sessile")
sess.e <- sess
sess.e$cancer <- 0 # empty
sess.e$shape <- "none" # empty
sess.e$pno <- 0
sess.e$countcat <- "0"
sess.e$size <- 0
sess.e$sizecat <- "<DL"

pedu <- subset(ef, shape == "peduncular")
pedu$size[pedu$sizecat == "<0.5"] <- exp((log(0.44721)+log(0.5))/2)
pedu.e <- pedu
pedu.e$cancer <- 0 # empty
pedu.e$shape <- "none" # empty
pedu.e$pno <- 0
pedu.e$countcat <- "0"
pedu.e$size <- 0
pedu.e$sizecat <- "<DL"

flat <- subset(ef, shape == "flat")
flat.e <- flat
flat.e$cancer <- 0 # empty
flat.e$shape <- "none" # empty
flat.e$pno <- 0
flat.e$countcat <- "0"
flat.e$size <- 0
flat.e$sizecat <- "<DL"

# size calculations only with cancer patients
sess.c <- subset(sess, cancer == 1)
pedu.c <- subset(pedu, cancer == 1)
flat.c <- subset(flat, cancer == 1)
sess.size <- aggregate(sess.c$size*sess.c$npat,list(sess.c$sex,sess.c$agecat),sum, drop = F)$x/
  aggregate(sess.c$npat,list(sess.c$sex,sess.c$agecat),sum, drop = F)$x
pedu.size <- aggregate(pedu.c$size*pedu.c$npat,list(pedu.c$sex,pedu.c$agecat),sum, drop = F)$x/
  aggregate(pedu.c$npat,list(pedu.c$sex,pedu.c$agecat),sum, drop = F)$x
flat.size <- aggregate(flat.c$size*flat.c$npat,list(flat.c$sex,flat.c$agecat),sum, drop = F)$x/
  aggregate(flat.c$npat,list(flat.c$sex,flat.c$agecat),sum, drop = F)$x

sess.totsize <- aggregate(sess.c$size*sess.c$npat,list(sess.c$sex),sum)$x/
  aggregate(sess.c$npat,list(sess.c$sex),sum)$x
pedu.totsize <- aggregate(pedu.c$size*pedu.c$npat,list(pedu.c$sex),sum)$x/
  aggregate(pedu.c$npat,list(pedu.c$sex),sum)$x
flat.totsize <- aggregate(flat.c$size*flat.c$npat,list(flat.c$sex),sum)$x/
  aggregate(flat.c$npat,list(flat.c$sex),sum)$x

#ef.ad <- subset(ef, shape != "none")
ef.ad <- subset(ef, cancer == 1)
ef.size <- aggregate(ef.ad$size*ef.ad$npat,list(ef.ad$sex,ef.ad$agecat),sum)$x/
  aggregate(ef.ad$npat,list(ef.ad$sex,ef.ad$agecat),sum)$x
ef.totsize <- aggregate(ef.ad$size*ef.ad$npat,list(ef.ad$sex),sum)$x/
  aggregate(ef.ad$npat,list(ef.ad$sex),sum)$x

# generate correct cancer counts
sess <- rbind(sess,pedu.e,flat.e,none)
pedu <- rbind(sess.e,pedu,flat.e,none)
flat <- rbind(sess.e,pedu.e,flat,none)

sess <- droplevels(sess)
pedu <- droplevels(pedu)
flat <- droplevels(flat)

sum(sess$cancer*sess$npat) # 183
sum(flat$cancer*flat$npat) # 36
sum(pedu$cancer*pedu$npat) # 77
sum(ef.ad$cancer*ef.ad$npat) # 296

# Table S2
aggregate(ef$npat,list(ef$sex),sum)
aggregate(ef$npat,list(ef$agecat,ef$sex),sum)
aggregate(sess$npat*sess$cancer,list(sess$sex),sum)
aggregate(sess$npat*sess$cancer,list(sess$agecat,sess$sex),sum)
aggregate(pedu$npat*pedu$cancer,list(pedu$sex),sum)
aggregate(pedu$npat*pedu$cancer,list(pedu$agecat,pedu$sex),sum)
aggregate(flat$npat*flat$cancer,list(flat$sex),sum)
aggregate(flat$npat*flat$cancer,list(flat$agecat,flat$sex),sum)

# agecat indices
vw <- seq(1,13,2) # w
vm <- seq(2,14,2) # m

# all
ncanc <- aggregate(ef$npat*ef$cancer,list(ef$sex,ef$agecat),sum)$x # cancer
npat <- aggregate(ef$npat,list(ef$sex,ef$agecat),sum)$x # patients
pyr <- vector()
pyr0 <- aggregate((ef$age-54)*ef$npat,list(ef$sex,ef$agecat),sum)$x # persons years
pyr[1] <- pyr0[1] + 5*sum(npat[vw[2:7]])
pyr[2] <- pyr0[2] + 5*sum(npat[vm[2:7]]) 
pyr0 <- aggregate((ef$age-59)*ef$npat,list(ef$sex,ef$agecat),sum)$x # persons years
pyr[3] <- pyr0[3] + 5*sum(npat[vw[3:7]])
pyr[4] <- pyr0[4] + 5*sum(npat[vm[3:7]])  
pyr0 <- aggregate((ef$age-64)*ef$npat,list(ef$sex,ef$agecat),sum)$x # persons years
pyr[5] <- pyr0[5] + 5*sum(npat[vw[4:7]])
pyr[6] <- pyr0[6] + 5*sum(npat[vm[4:7]])
pyr0 <- aggregate((ef$age-69)*ef$npat,list(ef$sex,ef$agecat),sum)$x # persons years
pyr[7] <- pyr0[7] + 5*sum(npat[vw[5:7]])
pyr[8] <- pyr0[8] + 5*sum(npat[vm[5:7]]) 
pyr0 <- aggregate((ef$age-74)*ef$npat,list(ef$sex,ef$agecat),sum)$x # persons years
pyr[9] <- pyr0[9] + 5*sum(npat[vw[6:7]])
pyr[10] <- pyr0[10] + 5*sum(npat[vm[6:7]])
pyr0 <- aggregate((ef$age-79)*ef$npat,list(ef$sex,ef$agecat),sum)$x # persons years
pyr[11] <- pyr0[11] + 5*(npat[13])
pyr[12] <- pyr0[12] + 5*(npat[14])
pyr0 <- aggregate((ef$age-84)*ef$npat,list(ef$sex,ef$agecat),sum)$x # persons years
pyr[13] <- pyr0[13]
pyr[14] <- pyr0[14]
age <- aggregate(ef$age*ef$npat,list(ef$sex,ef$agecat),sum)$x
pno <- aggregate(ef$pno*ef$npat,list(ef$sex,ef$agecat),sum)$x
meanage <- age/npat
haz <- ncanc/pyr
h.lo <- qpois(0.025,ncanc)/pyr
h.hi <- qpois(0.975,ncanc)/pyr

cage <- aggregate(ef$age[ef$cancer == 1]*ef$npat[ef$cancer == 1],list(ef$sex[ef$cancer == 1]),sum)$x
nccanc <- aggregate(ef$cancer[ef$cancer == 1]*ef$npat[ef$cancer == 1],list(ef$sex[ef$cancer == 1]),sum)$x
cage/nccanc
meanage
haz
sexc <- c("w","m")
agecat <- aggregate(ef$cancer,list(ef$sex,ef$agecat),sum)$Group.2
#sizecm <- aggregate(ef$size*ef$npat,list(ef$sex,ef$agecat),sum)$x/npat
sizecm <- ef.size
df.ef.age <- data.frame("all",sexc,npat,pno,ncanc,agecat,sizecm,pyr,meanage,haz,h.lo,h.hi,cage/nccanc)
headline <- c("Shape","Sex","npat","nad","ncanc","agecat","sizecm","pyr",
              "mage","chaz","chaz.lo","chaz.hi","cage")
names(df.ef.age) <- headline 
df.ef.age

# totals
totnpat <- aggregate(ef$npat,list(ef$sex),sum)$x
totpno <- aggregate(ef$pno*ef$npat,list(ef$sex),sum)$x
totncanc <- aggregate(ef$cancer*ef$npat,list(ef$sex),sum)$x
totpyr <- aggregate((ef$age-54)*ef$npat,list(ef$sex),sum)$x
totmage <- aggregate(ef$age*ef$npat,list(ef$sex),sum)$x/totnpat
#totsizecm <- aggregate(ef$size*ef$npat,list(ef$sex),sum)$x/totnpat
totsizecm <- ef.totsize
tothaz <- totncanc/totpyr
toth.lo <- qpois(0.025,totncanc)/totpyr
toth.hi <- qpois(0.975,totncanc)/totpyr
df.ef.tot <- data.frame("all",sexc,totnpat,totpno,totncanc,"total",totsizecm,
                          totpyr,totmage,tothaz,toth.lo,toth.hi,cage/nccanc)
names(df.ef.tot) <- headline 
df.ef.tot

df.ef <- rbind(df.ef.age,df.ef.tot)
df.ef

# sessile
ncanc <- aggregate(sess$npat*sess$cancer,list(sess$sex,sess$agecat),sum)$x # cancer
npat <- aggregate(sess$npat,list(sess$sex,sess$agecat),sum)$x # patients
pyr <- vector()
pyr0 <- aggregate((sess$age-54)*sess$npat,list(sess$sex,sess$agecat),sum)$x # persons years
pyr[1] <- pyr0[1] + 5*sum(npat[vw[2:7]])
pyr[2] <- pyr0[2] + 5*sum(npat[vm[2:7]]) 
pyr0 <- aggregate((sess$age-59)*sess$npat,list(sess$sex,sess$agecat),sum)$x # persons years
pyr[3] <- pyr0[3] + 5*sum(npat[vw[3:7]])
pyr[4] <- pyr0[4] + 5*sum(npat[vm[3:7]])  
pyr0 <- aggregate((sess$age-64)*sess$npat,list(sess$sex,sess$agecat),sum)$x # persons years
pyr[5] <- pyr0[5] + 5*sum(npat[vw[4:7]])
pyr[6] <- pyr0[6] + 5*sum(npat[vm[4:7]])
pyr0 <- aggregate((sess$age-69)*sess$npat,list(sess$sex,sess$agecat),sum)$x # persons years
pyr[7] <- pyr0[7] + 5*sum(npat[vw[5:7]])
pyr[8] <- pyr0[8] + 5*sum(npat[vm[5:7]]) 
pyr0 <- aggregate((sess$age-74)*sess$npat,list(sess$sex,sess$agecat),sum)$x # persons years
pyr[9] <- pyr0[9] + 5*sum(npat[vw[6:7]])
pyr[10] <- pyr0[10] + 5*sum(npat[vm[6:7]])
pyr0 <- aggregate((sess$age-79)*sess$npat,list(sess$sex,sess$agecat),sum)$x # persons years
pyr[11] <- pyr0[11] + 5*(npat[13])
pyr[12] <- pyr0[12] + 5*(npat[14])
pyr0 <- aggregate((sess$age-84)*sess$npat,list(sess$sex,sess$agecat),sum)$x # persons years
pyr[13] <- pyr0[13]
pyr[14] <- pyr0[14]
age <- aggregate(sess$age*sess$npat,list(sess$sex,sess$agecat),sum)$x
pno <- aggregate(sess$pno*sess$npat,list(sess$sex,sess$agecat),sum)$x
meanage <- age/npat
haz <- ncanc/pyr
h.lo <- qpois(0.025,ncanc)/pyr
h.hi <- qpois(0.975,ncanc)/pyr

#sum(pyr[vw])
#sum(pyr[vm])

cage <- aggregate(sess$age[sess$cancer == 1]*sess$npat[sess$cancer == 1],list(sess$sex[sess$cancer == 1]),sum)$x
nccanc <- aggregate(sess$cancer[sess$cancer == 1]*sess$npat[sess$cancer == 1],list(sess$sex[sess$cancer == 1]),sum)$x
cage/nccanc
meanage
haz
sexc <- c("w","m")
agecat <- aggregate(sess$cancer,list(sess$sex,sess$agecat),sum)$Group.2
#sizecm <- aggregate(sess$size*sess$npat,list(sess$sex,sess$agecat),sum)$x/npat
sizecm <- sess.size
df.sess.age <- data.frame("sessile",sexc,npat,pno,ncanc,agecat,sizecm,pyr,meanage,haz,h.lo,h.hi,cage/nccanc)
headline <- c("Shape","Sex","npat","nad","ncanc","agecat","sizecm","pyr",
              "mage","chaz","chaz.lo","chaz.hi","cage")
names(df.sess.age) <- headline 
df.sess.age

# totals
totnpat <- aggregate(sess$npat,list(sess$sex),sum)$x
totpno <- aggregate(sess$pno*sess$npat,list(sess$sex),sum)$x
totncanc <- aggregate(sess$cancer*sess$npat,list(sess$sex),sum)$x
totpyr <- aggregate((sess$age-54)*sess$npat,list(sess$sex),sum)$x
totmage <- aggregate(sess$age*sess$npat,list(sess$sex),sum)$x/totnpat
#totsizecm <- aggregate(sess$size*sess$npat,list(sess$sex),sum)$x/totnpat
totsizecm <- sess.totsize
tothaz <- totncanc/totpyr
toth.lo <- qpois(0.025,totncanc)/totpyr
toth.hi <- qpois(0.975,totncanc)/totpyr
df.sess.tot <- data.frame("sessile",sexc,totnpat,totpno,totncanc,"total",totsizecm,
                          totpyr,totmage,tothaz,toth.lo,toth.hi,cage/nccanc)
names(df.sess.tot) <- headline 
df.sess.tot

df.sess <- rbind(df.sess.age,df.sess.tot)
df.sess

# peduncular
ncanc <- aggregate(pedu$cancer*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # cancer
npat <- aggregate(pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # patients
pyr <- vector()
pyr0 <- aggregate((pedu$age-54)*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # persons years
pyr[1] <- pyr0[1] + 5*sum(npat[vw[2:7]])
pyr[2] <- pyr0[2] + 5*sum(npat[vm[2:7]]) 
pyr0 <- aggregate((pedu$age-59)*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # persons years
pyr[3] <- pyr0[3] + 5*sum(npat[vw[3:7]])
pyr[4] <- pyr0[4] + 5*sum(npat[vm[3:7]])  
pyr0 <- aggregate((pedu$age-64)*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # persons years
pyr[5] <- pyr0[5] + 5*sum(npat[vw[4:7]])
pyr[6] <- pyr0[6] + 5*sum(npat[vm[4:7]])
pyr0 <- aggregate((pedu$age-69)*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # persons years
pyr[7] <- pyr0[7] + 5*sum(npat[vw[5:7]])
pyr[8] <- pyr0[8] + 5*sum(npat[vm[5:7]]) 
pyr0 <- aggregate((pedu$age-74)*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # persons years
pyr[9] <- pyr0[9] + 5*sum(npat[vw[6:7]])
pyr[10] <- pyr0[10] + 5*sum(npat[vm[6:7]])
pyr0 <- aggregate((pedu$age-79)*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # persons years
pyr[11] <- pyr0[11] + 5*(npat[13])
pyr[12] <- pyr0[12] + 5*(npat[14])
pyr0 <- aggregate((pedu$age-84)*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x # persons years
pyr[13] <- pyr0[13]
pyr[14] <- pyr0[14]
age <- aggregate(pedu$age*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x
pno <- aggregate(pedu$pno*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x
meanage <- age/npat
haz <- ncanc/pyr
h.lo <- qpois(0.025,ncanc)/pyr
h.hi <- qpois(0.975,ncanc)/pyr

#sum(pyr[vw])
#sum(pyr[vm])

cage <- aggregate(pedu$age[pedu$cancer == 1]*pedu$npat[pedu$cancer == 1],list(pedu$sex[pedu$cancer == 1]),sum)$x
nccanc <- aggregate(pedu$cancer[pedu$cancer == 1]*pedu$npat[pedu$cancer == 1],list(pedu$sex[pedu$cancer == 1]),sum)$x
cage/nccanc
meanage
haz
sexc <- c("w","m")
agecat <- aggregate(pedu$cancer,list(pedu$sex,pedu$agecat),sum)$Group.2
#sizecm <- aggregate(pedu$size*pedu$npat,list(pedu$sex,pedu$agecat),sum)$x/npat
sizecm <- pedu.size
df.pedu.age <- data.frame("peduncular",sexc,npat,pno,ncanc,agecat,sizecm,pyr,meanage,haz,h.lo,h.hi,cage/nccanc)
headline <- c("Shape","Sex","npat","nad","ncanc","agecat","sizecm","pyr",
              "mage","chaz","chaz.lo","chaz.hi","cage")
names(df.pedu.age) <- headline 
df.pedu.age

# totals
totnpat <- aggregate(pedu$npat,list(pedu$sex),sum)$x
totpno <- aggregate(pedu$pno*pedu$npat,list(pedu$sex),sum)$x
totncanc <- aggregate(pedu$cancer*pedu$npat,list(pedu$sex),sum)$x
totpyr <- aggregate((pedu$age-54)*pedu$npat,list(pedu$sex),sum)$x
totmage <- aggregate(pedu$age*pedu$npat,list(pedu$sex),sum)$x/totnpat
#totsizecm <- aggregate(pedu$size*pedu$npat,list(pedu$sex),sum)$x/totnpat
totsizecm <- pedu.totsize
tothaz <- totncanc/totpyr
toth.lo <- qpois(0.025,totncanc)/totpyr
toth.hi <- qpois(0.975,totncanc)/totpyr
df.pedu.tot <- data.frame("peduncular",sexc,totnpat,totpno,totncanc,"total",totsizecm,
                          totpyr,totmage,tothaz,toth.lo,toth.hi,cage/nccanc)
names(df.pedu.tot) <- headline 
df.pedu.tot

df.pedu <- rbind(df.pedu.age,df.pedu.tot)
df.pedu

# flat
ncanc <- aggregate(flat$cancer*flat$npat,list(flat$sex,flat$agecat),sum)$x # cancer
npat <- aggregate(flat$npat,list(flat$sex,flat$agecat),sum)$x # patients
pyr <- vector()
pyr0 <- aggregate((flat$age-54)*flat$npat,list(flat$sex,flat$agecat),sum)$x # persons years
pyr[1] <- pyr0[1] + 5*sum(npat[vw[2:7]])
pyr[2] <- pyr0[2] + 5*sum(npat[vm[2:7]]) 
pyr0 <- aggregate((flat$age-59)*flat$npat,list(flat$sex,flat$agecat),sum)$x # persons years
pyr[3] <- pyr0[3] + 5*sum(npat[vw[3:7]])
pyr[4] <- pyr0[4] + 5*sum(npat[vm[3:7]])  
pyr0 <- aggregate((flat$age-64)*flat$npat,list(flat$sex,flat$agecat),sum)$x # persons years
pyr[5] <- pyr0[5] + 5*sum(npat[vw[4:7]])
pyr[6] <- pyr0[6] + 5*sum(npat[vm[4:7]])
pyr0 <- aggregate((flat$age-69)*flat$npat,list(flat$sex,flat$agecat),sum)$x # persons years
pyr[7] <- pyr0[7] + 5*sum(npat[vw[5:7]])
pyr[8] <- pyr0[8] + 5*sum(npat[vm[5:7]]) 
pyr0 <- aggregate((flat$age-74)*flat$npat,list(flat$sex,flat$agecat),sum)$x # persons years
pyr[9] <- pyr0[9] + 5*sum(npat[vw[6:7]])
pyr[10] <- pyr0[10] + 5*sum(npat[vm[6:7]])
pyr0 <- aggregate((flat$age-79)*flat$npat,list(flat$sex,flat$agecat),sum)$x # persons years
pyr[11] <- pyr0[11] + 5*(npat[13])
pyr[12] <- pyr0[12] + 5*(npat[14])
pyr0 <- aggregate((flat$age-84)*flat$npat,list(flat$sex,flat$agecat),sum)$x # persons years
pyr[13] <- pyr0[13]
pyr[14] <- pyr0[14]
age <- aggregate(flat$age*flat$npat,list(flat$sex,flat$agecat),sum)$x
pno <- aggregate(flat$pno*flat$npat,list(flat$sex,flat$agecat),sum)$x
meanage <- age/npat
haz <- ncanc/pyr
h.lo <- qpois(0.025,ncanc)/pyr
h.hi <- qpois(0.975,ncanc)/pyr

#sum(pyr[vw])
#sum(pyr[vm])

cage <- aggregate(flat$age[flat$cancer == 1]*flat$npat[flat$cancer == 1],list(flat$sex[flat$cancer == 1]),sum)$x
nccanc <- aggregate(flat$cancer[flat$cancer == 1]*flat$npat[flat$cancer == 1],list(flat$sex[flat$cancer == 1]),sum)$x
cage/nccanc
meanage
haz
sexc <- c("w","m")
agecat <- aggregate(flat$cancer,list(flat$sex,flat$agecat),sum)$Group.2
#sizecm <- aggregate(flat$size*flat$npat,list(flat$sex,flat$agecat),sum)$x/npat
sizecm <- flat.size
df.flat.age <- data.frame("flat",sexc,npat,pno,ncanc,agecat,sizecm,pyr,meanage,haz,h.lo,h.hi,cage/nccanc)
headline <- c("Shape","Sex","npat","nad","ncanc","agecat","sizecm","pyr",
              "mage","chaz","chaz.lo","chaz.hi","cage")
names(df.flat.age) <- headline 
df.flat.age

# totals
totnpat <- aggregate(flat$npat,list(flat$sex),sum)$x
totpno <- aggregate(flat$pno*flat$npat,list(flat$sex),sum)$x
totncanc <- aggregate(flat$cancer*flat$npat,list(flat$sex),sum)$x
totpyr <- aggregate((flat$age-54)*flat$npat,list(flat$sex),sum)$x
totmage <- aggregate(flat$age*flat$npat,list(flat$sex),sum)$x/totnpat
#totsizecm <- aggregate(flat$size*flat$npat,list(flat$sex),sum)$x/totnpat
totsizecm <- flat.totsize
tothaz <- totncanc/totpyr
toth.lo <- qpois(0.025,totncanc)/totpyr
toth.hi <- qpois(0.975,totncanc)/totpyr
df.flat.tot <- data.frame("flat",sexc,totnpat,totpno,totncanc,"total",totsizecm,
                          totpyr,totmage,tothaz,toth.lo,toth.hi,cage/nccanc)
names(df.flat.tot) <- headline 
df.flat.tot

flat <- rbind(df.flat.age,df.flat.tot)
flat
flat.w <- subset(flat, Sex == "w")
flat.m <- subset(flat, Sex == "m")
flat.b <- flat.w
flat.b$Sex <- "b"
flat.b$npat <- flat.w$npat + flat.m$npat
flat.b$nad <- flat.w$nad + flat.m$nad
flat.b$ncanc <- flat.w$ncanc + flat.m$ncanc
flat.b$sizecm <- (flat.w$sizecm*flat.w$npat + flat.m$sizecm*flat.m$npat)/flat.b$npat
flat.b$sizecm[flat.b$agecat == "80-84"] <- flat.m$sizecm[flat.b$agecat == "80-84"]
flat.b$pyr <- flat.w$pyr + flat.m$pyr
flat.b$mage <- (flat.w$mage*flat.w$npat + flat.m$mage*flat.m$npat)/flat.b$npat
flat.b$chaz <- flat.b$ncanc/flat.b$pyr
flat.b$chaz.lo <- qpois(0.025,flat.b$ncanc)/flat.b$pyr
flat.b$chaz.hi <- qpois(0.975,flat.b$ncanc)/flat.b$pyr
flat.b$cage <- (flat.w$cage*flat.w$npat + flat.m$cage*flat.m$npat)/flat.b$npat

df.flat <- rbind(flat,flat.b)

# bind all together
df <- rbind(df.ef,df.sess,df.pedu,df.flat)
df$enad <- df$nad/df$npat

# show total incidence
df.0 <- subset(df, Shape != "all" & Sex != "b" )
df.w <- subset(df.0, Sex == "w")
df.m <- subset(df.0, Sex == "m")
aggregate(df.w$ncanc,list(df.w$agecat),sum)$x/df.w$pyr[df.w$Shape == "flat"]
aggregate(df.m$ncanc,list(df.m$agecat),sum)$x/df.m$pyr[df.m$Shape == "flat"]

df.canag <- df
df.canag

setwd(datdir)
save(df.canag, file = "canag-20220614.Rdata")




