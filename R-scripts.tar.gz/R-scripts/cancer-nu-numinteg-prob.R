#----------------------------------------------
# cancer transition probabilities
# 2022/06/20, jck
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
#shp <- "flat"
#shp <- "sessile"
shp <- "peduncular"

noad <- character()
#noad <- "wN0"
noad <- "noN0"

patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    df0$ymin <- 40
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}

sexc <- character()
#sexc <- "both"
sexc <- "m"
#sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K1"
mmname <- "K2"

meth <- character()
#meth <- "sum" # summation
meth <- "hyp" # hypergeometric function

# likelihood
likc <- character()
#likc <- "posize"
#likc <- "dist"
likc <- "permut"

atr <- character()
atr <- "atrend"
#atr <- "std"

mdv <- character()
#mdv <- "grid"
mdv <- "pref"

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,atr,sep="-") 

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
#ymin <- unique(df$ylo[df$sizecat == "<0.5"])
#df$ymin <- ymin

#ysess <- c(50,200,800,3200)
#ypedu <- c(13,50,200,800)
#yflat <- ysess
#yall <- ysess
df <- droplevels(df)

{
  if (dims == "2d"){
    if (shp != "peduncular"){
      Size1cm <- 1/sqrt(800)
      Ninf <- 3200
      yN <- c(50,200,800,1800,3200) # 0.25,0.5,1,1.5,2 cm
    }
    else {
      Size1cm <- 1/sqrt(200)
      Ninf <- 800
      yN <- c(13,50,200,450,800) # 0.25,0.5,1,1.5,2 cm
    }
    gdim <- 2
    
  }
  else if (dims == "3d"){
    if (shp != "peduncular"){
      Size1cm <- 1/3200^(1/3) # 1 cm
      Ninf <- 25600
      yN <- c(50,400,3200,10800,25600) # 0.25,0.5,1,1.5,2 cm
    }
    else {
      Size1cm <-  1/400^(1/3)
      Ninf <- 3200 # not used
      yN <- c(6,50,400,1350,3200) # 0.25,0.5,1,1.5,2 cm
    }
    gdim <- 3
  }
}

#------------------------------------------------------------
# read aggregate cancer data with nuAge estimates
#------------------------------------------------------------
setwd(datdir)
load(file = "nuAgeFit-canag-ecell-20220616.Rdata")
head(cf)
str(cf)

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid" & atr =="atrend"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
  else if (mdv == "grid" & atr == "std"){thispardir <- gstdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
{
  if (atr == "atrend"){
    source("pAdenoK0K1K2atrend-distrib-size.R")
  }
  else if (atr == "std"){
    source("pAdenoK0K1K2std-distrib-size.R")
  }
}

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
      Esize <- ymeanK0
      Prev <- PrevK0
      pn_K <- pn_K0_ler
      }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
    Esize <- ymeanK1
    Prev <- PrevK1.app
    pn_K <- pn_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.sum
    Thelohi <- theta_lohi_K1.sum
    #Theloho <- pnlohi_K1.sum
    Esize <- EsizeK1.hyp
    Prev <- PrevK1
    pn_K <- pn_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.sum
    Thelohi <- theta_lohi_K2.sum
    Esize <- EsizeK2.sum
    Prev <- PrevK2
    pn_K <- pn_K2.sum
  }
  else
  {
    print("Not implemented\n")
  }
}

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
upar <- dpar$parval

#--------------------------------
# model predictions
#--------------------------------
#cf <- subset(cf, shape != "flat,2d")
cf$lage65 <- log(cf$mage/65)
cf$lagesq <- cf$lage65*cf$lage65
desc.0 <- glm(cases ~ lage65 + sizecm, family = poisson(link = "log"), offset = log(pyr*1e-4), data = cf)
summary(desc.0) # AIC: 171.31
names(cf)
#------------------------------
#calculate time transfer factor
#------------------------------
fname
nlimit <- 100*Ninf
y0 <- 1/Size1cm^gdim
nu65 <- cf$nu65[cf$Sex == sexc & cf$Shape == shp & cf$agecat == "55-59"]
cacen <- cf$cacen[cf$Sex == sexc & cf$Shape == shp & cf$agecat == "55-59"]

timeStep <- .25# year
timeStepCen <- timeStep/2 # year
ages <- seq(60+timeStepCen,70-timeStepCen,timeStep)
delt <- seq(0+timeStepCen,10-timeStepCen,timeStep)
ndim <- length(ages)
eSize_0 <- vector() 
eN_0 <- vector() 
DeSize_0 <- vector()  
DeN_0 <- vector() 
nuAge <- vector()
nuDelt <- vector()
eCell_0 <- vector()
DeCell_0 <- vector()
for (i in 1:ndim)
{
  acen <- (ages[i]-65)/10
  dacen <- (delt[i]-65)/10
  eSize_0[i] <- Esize(ages[i],upar,1,0,nlimit) 
  eN_0[i] <- ENad(ages[i],upar,0)
  DeSize_0[i] <- Esize(delt[i],upar,1,0,nlimit) 
  DeN_0[i] <- ENad(delt[i],upar,0)
  nuAge[i] <- nu65*exp(cacen*acen)
  nuDelt[i] <- nu65*exp(cacen*dacen)
  eCell_0[i] <- eSize_0[i]*eN_0[i]
  DeCell_0[i] <- DeSize_0[i]*DeN_0[i]
}
DeSize_0[1] <- 0
DeCell_0[1] <- 0

ttf <- vector()
hCell <- vector()
hCum <- vector()
hS <- 0
sCell <- vector()
for (i in 1:ndim)
{
  # calculate hCell
  ttf[i] <- (eCell_0[i]*nuAge[i] - DeCell_0[i]*nuDelt[i])/(eCell_0[1]*nuAge[1]) # S49
  hCell[i] <- nuAge[i]*ttf[i] # S49
  
  # inner integration, cumulative step
  hS <- (hS + hCell[i])
 
  # mind the timeStep
  hCum[i] <- hS*timeStep
  sCell[i] <- exp(-hCum[i]) # single cell
  
  cat(sprintf("ages: %g, hCell: %g, hCum: %g, sCell: %g\n",ages[i],hCell[i],hCum[i],sCell[i]))
}

# outer integration, use number of cells per clone
hInt0p25 <- vector()
hInt0p5 <- vector()
hInt1 <- vector()
hInt1p5 <- vector()
hInt2 <- vector()
hSum0p25 <- 0
hSum0p5 <- 0
hSum1 <- 0
hSum1p5 <- 0
hSum2 <- 0
for (i in 1:ndim)
{

  # outer integration, cumulative step
  hSum0p25 <- hSum0p25 + yN[1]*hCell[i]*exp(-yN[1]*hCum[i])
  hSum0p5 <- hSum0p5 + yN[2]*hCell[i]*exp(-yN[2]*hCum[i])
  hSum1 <- hSum1 + yN[3]*hCell[i]*exp(-yN[3]*hCum[i])
  hSum1p5  <- hSum1p5 + yN[4]*hCell[i]*exp(-yN[4]*hCum[i])
  hSum2  <- hSum2 + yN[5]*hCell[i]*exp(-yN[5]*hCum[i])
  
  # mind the timeStep
  hInt0p25[i] <- hSum0p25*timeStep
  hInt0p5[i] <- hSum0p5*timeStep
  hInt1[i] <- hSum1*timeStep
  hInt1p5[i] <- hSum1p5*timeStep
  hInt2[i] <- hSum2*timeStep
}

headline <- c("Shape","Sex","Size","age","delt","nuAge","ttf","hCell","hCum","sCell","pCanc")
prf0p25 <- data.frame(shp,sexc,"0.25 cm",ages,delt,nuAge,ttf,hCell,hCum,sCell,hInt0p25)
names(prf0p25) <- headline
prf0p5 <- data.frame(shp,sexc,"0.5 cm",ages,delt,nuAge,ttf,hCell,hCum,sCell,hInt0p5)
names(prf0p5) <- headline
prf1 <- data.frame(shp,sexc,"1 cm", ages,delt,nuAge,ttf,hCell,hCum,sCell,hInt1)
names(prf1) <- headline
prf1p5 <- data.frame(shp,sexc,"1.5 cm", ages,delt,nuAge,ttf,hCell,hCum,sCell,hInt1p5)
names(prf1p5) <- headline
prf2 <- data.frame(shp,sexc,"2 cm",ages,delt,nuAge,ttf,hCell,hCum,sCell,hInt2)
names(prf2) <- headline
prf <- rbind(prf0p25,prf0p5,prf1,prf1p5,prf2)
str(prf)
summary(prf)

ffname <- "prob60_70-ts0p25yr"
ffname <- paste(ffname,fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(tmpdir)
save(prf, file = fsavname)


