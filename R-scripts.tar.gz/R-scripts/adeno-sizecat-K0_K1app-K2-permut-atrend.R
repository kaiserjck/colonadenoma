#----------------------------------------------
# adeno OE analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
#shp <- "flat"
#shp <- "sessile"
shp <- "peduncular"

noad <- character()
#noad <- "wN0"
noad <- "noN0"

patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    df0$ymin <- 40
    df0$size[df0$sizecat == "<0.5"] <- exp((log(sqrt(40/200))+log(0.5))/2)
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}

sexc <- character()
#sexc <- "both"
sexc <- "m"
#sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K1"
mmname <- "K2"

meth <- character()
#meth <- "sum" # summation
meth <- "hyp" # hypergeometric function

# likelihood
likc <- character()
#likc <- "posize"
likc <- "permut"

mdv <- character()
mdv <- "atrend"
#mdv <- "std"

mds <- character()
mds <- "pref"

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,mdv,sep="-") 

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
  
  if(shp != "peduncular"){
    df0$ymin <- 30
    df0$ylo[df0$sizecat == "<0.5"] <- 30
  }
}

# set detection limit boundaries for preferred models
{
  if (mds == "pref"){
    if (shp != peduncular & dims == 2) {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat" & dims == 3) {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    #else if (shp == "peduncular") {
    #  df0$ylo[df0$ylo == 50] <- 40
    #  df0$ymin[df0$ymin == 50] <- 40}  
  }
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
#ymin <- unique(df$ylo[df$sizecat == "<0.5"])
#df$ymin <- ymin
df <- droplevels(df)

# calculate df$npat_age
npatTot_agecat <- aggregate(df0$npat,list(df0$agecat),sum, drop=FALSE)
npatTot_agecat[is.na(npatTot_agecat)] <- 0

ad <- df

npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum, drop=FALSE)
npat_size_age[is.na(npat_size_age)] <- 0
npno_size_age <- aggregate(ad$pno*ad$npat, list(ad$agecat,ad$sizecat), sum, drop=FALSE)
npno_size_age[is.na(npno_size_age)] <- 0
#npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum)
#npat_size_age <- aggregate(ad$npat, list(factor(ad$age),ad$sizecat), sum)
#npat_size_age$x[is.na(npat_size_age$x) == T] <- 0

ylo_uni <- aggregate(ad$ylo, list(ad$agecat,ad$sizecat), unique, drop=FALSE)
yhi_uni <- aggregate(ad$yhi, list(ad$agecat,ad$sizecat), unique, drop=FALSE)
ymin_uni <- aggregate(ad$ymin, list(ad$agecat,ad$sizecat), unique, drop=FALSE)
#ylo_uni <- aggregate(ad$ylo, list(factor(ad$age),ad$sizecat), unique)
#yhi_uni <- aggregate(ad$yhi, list(factor(ad$age),ad$sizecat), unique)
#ymin_uni <- aggregate(ad$ymin, list(factor(ad$age),ad$sizecat), unique)

df.h <- data.frame(shp,sexc,dims,npat_size_age,npno_size_age$x,ylo_uni$x,yhi_uni$x,ymin_uni$x)

npat_age <- aggregate(ad$npat, list(ad$agecat), sum, drop=FALSE)
npno_age <- aggregate(ad$pno*ad$npat, list(ad$agecat), sum, drop=FALSE)
age_sum <- aggregate(ad$npat*ad$age, list(ad$agecat), sum, drop=FALSE)
npat_agecat <- aggregate(ad$npat, list(ad$agecat), sum, drop=FALSE)
#age_sum <- aggregate(ad$npat*ad$age, list(factor(ad$age),ad$sizecat), sum)
age_mean <- age_sum$x/npat_agecat$x
#npat_age <- aggregate(ad$npat, list(factor(ad$age)), sum)
help1 <- split(df.h, df.h$Group.1)
nlevels <- length(levels(df.h$Group.1))
for(i in 1:nlevels){
  help1[[i]]$age <- age_mean[i]
  help1[[i]]$acen <- (age_mean[i]-65)/10
  help1[[i]]$npat_age <- npat_age$x[i]
  help1[[i]]$npatTot_age <- npatTot_agecat$x[i]
  help1[[i]]$npno_age <- npno_age$x[i]
}
df.r <- help1[[1]]
for (i in 2:nlevels){
  df.r <- rbind(df.r,help1[[i]])
}
#df.r <- data.frame(df.h)
dim(df.r)
names(df.r) <- c("shp","sex","dims","agecat","sizecat","npat","npno","ylo","yhi","ymin","age","acen",
                 "npat_agecat","npatTot_agecat","npno_agecat")
# repair missing values
df.r$ymin <- ymin_uni$x[1]
df.r$ylo[df.r$sizecat == "<0.5"] <- ylo_uni$x[1]
df.r$yhi[df.r$sizecat == "<0.5"] <- yhi_uni$x[1]

# reorder columns
df.r <- df.r[,c("shp","sex","dims","age","acen","agecat","sizecat","npat","npat_agecat","npatTot_agecat","npno","npno_agecat","ylo","yhi","ymin")]
aggregate(df.r$npat,list(df.r$agecat),sum)
head(df.r)
str(df.r)

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "atrend" & likc == "posize"){thispardir <- patrendpardir}
  else if (mdv == "std" & likc == "posize"){thispardir <- pstdpardir}
  if (mdv == "atrend" & likc == "permut"){thispardir <- atrendpardir}
  else if (mdv == "std" & likc == "permut"){thispardir <- stdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 1000
sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names

# hack: make sigma symmetric
dim(sigma)[1]
sigma[1,2] <- sigma[2,1]
if(dim(sigma)[1] == 3)
{
 sigma[1,3] <- sigma[3,1]
 sigma[2,3] <- sigma[3,2]
}
if(dim(sigma)[1] == 4)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
}
if(dim(sigma)[1] == 5)
{
  sigma[1,3] <- sigma[3,1]
  sigma[2,3] <- sigma[3,2]
  sigma[1,4] <- sigma[4,1]
  sigma[2,4] <- sigma[4,2]
  sigma[3,4] <- sigma[4,3]
  sigma[1,5] <- sigma[5,1]
  sigma[2,5] <- sigma[5,2]
  sigma[3,5] <- sigma[5,3]
  sigma[4,5] <- sigma[5,4]
}
cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma)))
has.cov <- dpar$X %in% dcov$X # create vector denoting parameters present in dcov
pr <- dpar$parval[has.cov] # coefficients present in dcov
#pr[1] <- log(pr[1])
if (all(1 == sign(eigen(sigma)$values)) == TRUE)
#if (is.positive.definite(sigma) == TRUE)
{Z <- mvrnorm(n=nsim,mu=pr,Sigma=sigma)}
#Z[,1] <- exp(Z[,1])
apply(Z,2,mean)
#apply(Z,2,sd)

#---------------------------------------------------------
# matrix of simulated parameters for uncertainty calculations
#--------------------------------------------------------- 
is.complete <- all(dpar$X %in% dcov$X) # check if dcov parameter set is complete
{ # if statement
  if(is.complete) {
    
    df.par <- data.frame(Z)
    colnames(df.par) <- dpar$X
    
  } else {
    
    nmpar <- dim(dpar[!has.cov,])[1] # no. of fixed parameters (not present in dcov)
    Y <- matrix(ncol = nmpar, nrow = nsim) # define matrix with NAs
    for(i in 1:nmpar)
    {
      Y[1:nsim,i] <- dpar$parval[!has.cov][i] # assign fixed parameter estimates to nsim rows
    }
    df.par <- data.frame(cbind(Z,Y)) # combine simulated and fixed parameters and convert to data frame
    colnames(df.par) <- c(dpar$X[has.cov],dpar$X[!has.cov]) # assign parameter names to columns
    df.par <- df.par[,dpar$X] # sort columns to original order
    
  }
} # end of if statement

upar <- dpar$parval

if(mdv == "std"){
  npar <- length(upar)
  upar[npar+1] <- 0
  nvarpar <- dim(df.par)[2]
  df.par[,nvarpar+1] <- 0
}

df.par[1:10,]

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
{
  if (likc == "posize"){
    source("pAdenoK0K1K2atrend-posize-size.R")
  }
  else if (likc == "permut"){
    source("pAdenoK0K1K2atrend-permut.R")
  }
}

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
    ENad <- ENadK0
    Thelohi <- theta_lohi_K0_ler
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.hyp
    Thelohi <- theta_lohi_K2.hyp
  }
  else
  {
    print("Not implemented\n")
  }
}

#--------------------------------
# model predictions
#--------------------------------
# adenoma size
#--------------------------------
psz <- df.r
#df <- droplevels(df)

# model predictions
# expectation value
lbd <- ENad(psz$age,upar,gb.ymin) 

# probabilities
# model prediction for size category
pdim <- dim(psz)[1]
PScat_unique <- unlist(lapply(1:pdim, function(i) Thelohi(psz$age[i],upar,psz$ylo[i],psz$yhi[i])/lbd[i]))

psz.1 <- data.frame(psz,lbd,PScat_unique)

help1 <- split(psz.1, psz.1$agecat)
nAgeCat <- length(levels(psz.1$agecat))
nSizeCat <- length(levels(psz.1$sizecat))

for(i in 1:nAgeCat){
    # abbreviations
    lbd <- help1[[i]]$lbd[1]
    uPScat <- help1[[i]]$PScat_unique
    cat(sprintf("agecat: %s, lbd: %g\np1: %g, p2: %g, p3: %g, p4: %g\n", help1[[i]]$agecat[1], lbd, uPScat[1], uPScat[2], uPScat[3], uPScat[4]))
    
    # assume data for 4 sizecats
    help1[[i]]$PScat[1] <- exp(lbd*(uPScat[1]-1)) - exp(-lbd)
    help1[[i]]$PScat[2] <- exp(lbd*(uPScat[1]+uPScat[2]-1)) - exp(lbd*(uPScat[1]-1))
    help1[[i]]$PScat[3] <- exp(lbd*(uPScat[1]+uPScat[2]+uPScat[3]-1)) - exp(lbd*(uPScat[1]+uPScat[2]-1))
    help1[[i]]$PScat[4] <- 1-exp(-lbd*uPScat[4])
}
psz.h1 <- help1[[1]]
for (i in 2:nAgeCat){
  psz.h1 <- rbind(psz.h1,help1[[i]])
}
psz.h1

aggregate(psz.h1$PScat_unique, list(psz.h1$agecat),sum)
aggregate(psz.h1$PScat, list(psz.h1$agecat),sum)


# model uncertainties
#pdfPScat <- list()
#for(i in 1:pdim)
#{
#  PScatsav <- unlist(lapply(1:nsim, function(j) 
#    Thelohi(psz$age[i],as.numeric(df.par[j,]),psz$ylo[i],psz$yhi[i])/ENad(psz$age[i],as.numeric(df.par[j,]),gb.ymin)))
#  pdfPScat[[i]] <- PScatsav
#  cat(sprintf("Model undercertainty simulation: cell no. %2d completed\n", i))
#}

#PScat.mn <- unlist(lapply(pdfPScat,mean))
#PScat.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfPScat[[i]], probs = 0.025))))
#PScat.md <- unlist(lapply(pdfPScat,median))
#PScat.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfPScat[[i]], probs = 0.975))))
PScat <- psz.h1$PScat
PScat.lo <- psz.h1$PScat
PScat.md <- psz.h1$PScat
PScat.hi <- psz.h1$PScat

# count uncertainties
psz <- psh.h1
MScat <- unlist(lapply(1:pdim, function(i) psz$npat[i]/psz$npatTot_agecat[i]))

# simulation
nsim <- 10000
pdfNpat <- list()
for(i in 1:pdim)
{
  Npatsav <- rpois(nsim,psz$npat[i])
  pdfNpat[[i]] <- Npatsav
}

pdfNpatTot <- list()
nage <- length(levels(psz$agecat))
for(i in 1:nage)
{
  NpatTotsav <- rpois(nsim,npatTot_agecat$x[i])
  pdfNpatTot[[i]] <- NpatTotsav
}

#pdfNpatCat <- list()
#nsize <- length(levels(psz$sizecat))
#for(i in 1:nage)
#{
#  j <- (i-1)*(nsize-1)
#  k <- i+j
#  cat(sprintf("nage: %g, k: %g\n", i, k))
#  pdfNpatCat[[i]] <- pdfNpat[[k]] + pdfNpat[[k+1]] + pdfNpat[[k+2]] + pdfNpat[[k+3]]
#}
#pdfNpatCat[[7]] <- pdfNpat[[25]] + pdfNpat[[26]] + pdfNpat[[27]]

pdfMScat <- list()
nsize <- length(levels(psz$sizecat))
for(i in 1:pdim){
  j <- as.integer((i-1)/nsize)+1
  cat(sprintf("pdim: %g, agecat: %g\n", i, j))
  pdfMScat[[i]] <- pdfNpat[[i]]/pdfNpatTot[[j]]
}

MScat.mn <- unlist(lapply(pdfMScat,mean))
MScat.lo <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfMScat[[i]], probs = 0.025))))
MScat.md <- unlist(lapply(pdfMScat,median))
MScat.hi <- as.numeric(unlist(lapply(1:pdim,function (i) quantile(pdfMScat[[i]], probs = 0.975))))

#----------------------------------------
# build plot frames
#----------------------------------------
headline <- c("Shape","Sex","dim","Mode","age","agecat","sizecat","npat","npatTotAdeno","npatTot","pmn","plo","phi")
pf.m <- data.frame(psz$shp,psz$sex,psz$dims,"M",psz$age,psz$agecat,psz$sizecat,psz$npat,psz$npat_agecat,psz$npatTot_agecat,
                   PScat,PScat.lo,PScat.hi)
names(pf.m) <- headline
head(pf.m)

pf.s <- data.frame(psz$shp,psz$sex,psz$dims,"S",psz$age,psz$agecat,psz$sizecat,psz$npat,psz$npat_agecat,psz$npatTot_agecat,
                   MScat,MScat.lo,MScat.hi)
names(pf.s) <- headline
head(pf.s)

scf <- rbind(pf.m,pf.s)
str(scf)

setwd(curvdir)
fsavname <- paste("sizecat",fname,sep = "-")
fsavname <- paste(fsavname,"Rdata",sep = ".")
fsavname
save(scf,file = fsavname)
