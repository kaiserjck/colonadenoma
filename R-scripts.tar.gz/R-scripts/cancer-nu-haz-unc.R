#----------------------------------------------
# adeno nu(age) analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#--------------------------------------------------------------
library(gnm) # generalized non-linear models
#library(ggplot2)
#library(splines)
library(numDeriv) # for hessian(.)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(bbmle) # mle2 fitting with functions similar to glm fitting
library(Formula)
library(formattable)
library(corrplot)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-----------------------------------------------------------------------------
# read data
#-----------------------------------------------------------------------------
setwd(datdir)
load(file = "canag-ecell-20220626.Rdata")
head(ecf.cell)
str(ecf.cell)

#-----------------------------------------------------
# age dependence of effective transformation rate nu_eff
#-----------------------------------------------------
nueffa <- function(nu0, nuAge) 
{ 
  age <- df$mage
  pyr <- df$pyr
  eCell <- df$eCad
  
  acen <- (age-65)/10

  hazard <- eCell*exp(nu0+nuAge*acen)

  return (pyr * hazard)
}

#----------------------------------------------------------
# Poisson fit
#----------------------------------------------------------
cf <- ecf.cell
cf <- subset(cf, agecat != "total")
str(cf)
names(cf)[5] <- "cases"

a.m <- subset(cf, Sex == "m" & Shape == "all" & agecat != "total")
a.w <- subset(cf, Sex == "w" & Shape == "all" & agecat != "total")

s.m <- subset(cf, Sex == "m" & Shape == "sessile" & agecat != "total")
s.w <- subset(cf, Sex == "w" & Shape == "sessile" & agecat != "total")

p.m <- subset(cf, Sex == "m" & Shape == "peduncular" & agecat != "total")
p.w <- subset(cf, Sex == "w" & Shape == "peduncular" & agecat != "total")

f.m <- subset(cf, Sex == "m" & Shape == "flat" & agecat != "total")
f.w <- subset(cf, Sex == "w" & Shape == "flat" & agecat != "total")

f.m.3d <- subset(cf, Sex == "m" & Shape == "flat,3d" & agecat != "total")
f.w.3d <- subset(cf, Sex == "w" & Shape == "flat,3d" & agecat != "total")

df <- a.m
upar <- vector()
upar[1] <- log(1e-6)
upar[2] <- 1
lambda <- nueffa (nu0 = upar[1], nuAge = upar[2])
#lambda
-2*sum(dpois (df$cases, lambda, log = TRUE))

mle.1 <- mle2(cases ~ dpois (lambda = nueffa(nu0, nuAge)), 
              start=list(nu0 = upar[1], nuAge = upar[2]), 
              parameters=list(nu0~1, nuAge~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.1)
AIC(mle.1)

round((upar[1] - coef(mle.1)[1])/coef(mle.1)[1]*100,1)
round((upar[2] - coef(mle.1)[2])/coef(mle.1)[2]*100,1)

# AIC
rn <- sum(dpois (df$cases, df$cases, log = TRUE))
npar <- length(coef(mle.1,exclude.fixed=T))
rd <- -2*(as.numeric(logLik(mle.1)) - rn)
rd
AICrd <- rd + 2*npar
AICrd

# Pearson residuals
res <- residuals(mle.1,type="pearson")
degf <- length(df$cases) - npar
pres <- sum(res^2)/degf
pres

prf <- profile(mle.1)
plot(prf)
confint(prf)

df <- s.m
upar <- vector()
upar[1] <- log(1e-6)
upar[2] <- 1
lambda <- nueffa (nu0 = upar[1], nuAge = upar[2])
#lambda
-2*sum(dpois (df$cases, lambda, log = TRUE))

mle.2 <- mle2(cases ~ dpois (lambda = nueffa(nu0, nuAge)), 
              start=list(nu0 = upar[1], nuAge = upar[2]), 
              parameters=list(nu0~1, nuAge~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.2)
AIC(mle.2)

df <- p.m
upar <- vector()
upar[1] <- log(1e-6)
upar[2] <- 1
lambda <- nueffa (nu0 = upar[1], nuAge = upar[2])
#lambda
-2*sum(dpois (df$cases, lambda, log = TRUE))

mle.3 <- mle2(cases ~ dpois (lambda = nueffa(nu0, nuAge)), 
              start=list(nu0 = upar[1], nuAge = upar[2]), 
              parameters=list(nu0~1, nuAge~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.3)
AIC(mle.3)

df <- f.m
upar <- vector()
upar[1] <- log(1e-6)
upar[2] <- 1
lambda <- nueffa (nu0 = upar[1], nuAge = upar[2])
#lambda
-2*sum(dpois (df$cases, lambda, log = TRUE))

mle.4 <- mle2(cases ~ dpois (lambda = nueffa(nu0, nuAge)), 
              start=list(nu0 = upar[1], nuAge = upar[2]), 
              parameters=list(nu0~1, nuAge~1), 
              #method = "L-BFGS-B",
              #method = "Brent",
              data = df)

summary(mle.4)
AIC(mle.4)

#--------------------------------------------------------------------
# load ecell
#--------------------------------------------------------------------
setwd(curvdir)
load(file = "ecell-a55_90-20220615.Rdata")

ef <- ecf.cell
str(ef)
names(cf)[5] <- "cases"

ec.a.m <- subset(ef, Sex == "men" & Shape == "all")
ec.a.w <- subset(ef, Sex == "women" & Shape == "all" )

ec.s.m <- subset(ef, Sex == "men" & Shape == "sessile")
ec.s.w <- subset(ef, Sex == "women" & Shape == "sessile")

ec.p.m <- subset(ef, Sex == "men" & Shape == "peduncular")
ec.p.w <- subset(ef, Sex == "women" & Shape == "peduncular")

ec.f.m <- subset(ef, Sex == "men" & Shape == "flat")
ec.f.w <- subset(ef, Sex == "women" & Shape == "flat")

ec.1 <- ec.a.m
ec.2 <- ec.s.m
ec.3 <- ec.p.m
ec.4 <- ec.f.m

#--------------------------------------------------------------------
# uncertainty calculations: mvrnorm
#--------------------------------------------------------------------
library(MASS)
# simulate multivariate normal distribution
nsim = 10000
#sigma <- data.matrix(dcov[,-1]) # covariance matrix, skip first column containing row names
sigma.1 <- data.matrix(vcov(mle.1))
sigma.2 <- data.matrix(vcov(mle.2))
sigma.3 <- data.matrix(vcov(mle.3))
sigma.4 <- data.matrix(vcov(mle.4))

#cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma.1)))
pr.1 <- coef(mle.1)
#cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma.2)))
pr.2 <- coef(mle.2)
#cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma.3)))
pr.3 <- coef(mle.3)
#cat(sprintf("--> CovMat posdef: '%s'\n", is.positive.definite(sigma.3)))
pr.4 <- coef(mle.4)

if (all(1 == sign(eigen(sigma.1)$values)) == TRUE)
  #if (is.positive.definite(sigma) == TRUE)
{Z.1 <- mvrnorm(n=nsim,mu=pr.1,Sigma=sigma.1)}
apply(Z.1,2,mean)
apply(Z.1,2,sd)

if (all(1 == sign(eigen(sigma.2)$values)) == TRUE)
  #if (is.positive.definite(sigma) == TRUE)
{Z.2 <- mvrnorm(n=nsim,mu=pr.2,Sigma=sigma.2)}
apply(Z.2,2,mean)
apply(Z.2,2,sd)

if (all(1 == sign(eigen(sigma.3)$values)) == TRUE)
  #if (is.positive.definite(sigma) == TRUE)
{Z.3 <- mvrnorm(n=nsim,mu=pr.3,Sigma=sigma.3)}
apply(Z.3,2,mean)
apply(Z.3,2,sd)

if (all(1 == sign(eigen(sigma.4)$values)) == TRUE)
  #if (is.positive.definite(sigma) == TRUE)
{Z.4 <- mvrnorm(n=nsim,mu=pr.4,Sigma=sigma.4)}
apply(Z.4,2,mean)
apply(Z.4,2,sd)

numn.1 <- vector()
nudist.1 <- list()
numd.1 <- vector()
nulo.1 <- vector()
nuhi.1 <- vector()

numn.2 <- vector()
nudist.2 <- list()
numd.2 <- vector()
nulo.2 <- vector()
nuhi.2 <- vector()

numn.3 <- vector()
nudist.3 <- list()
numd.3 <- vector()
nulo.3 <- vector()
nuhi.3 <- vector()

numn.4 <- vector()
nudist.4 <- list()
numd.4 <- vector()
nulo.4 <- vector()
nuhi.4 <- vector()

ages <- seq(55,90,1)
ndim <- length(ages)
for (i in 1:ndim)
{
  acen <- (ages[i]-65)/10
  numn.1[i] <- ec.1$eCad[i]*exp(coef(mle.1)[1] + coef(mle.1)[2]*acen)
  nudist.1[[i]] <- ec.1$eCad[i]*exp(Z.1[,1] + Z.1[,2]*acen)
  nulo.1[i] <- quantile(nudist.1[[i]], probs = 0.025)
  numd.1[i] <- quantile(nudist.1[[i]], probs = 0.5)
  nuhi.1[i] <- quantile(nudist.1[[i]], probs = 0.975)

  numn.2[i] <- ec.2$eCad[i]*exp(coef(mle.2)[1] + coef(mle.2)[2]*acen)
  nudist.2[[i]] <- ec.2$eCad[i]*exp(Z.2[,1] + Z.2[,2]*acen)
  nulo.2[i] <- quantile(nudist.2[[i]], probs = 0.025)
  numd.2[i] <- quantile(nudist.2[[i]], probs = 0.5)
  nuhi.2[i] <- quantile(nudist.2[[i]], probs = 0.975)
  
  numn.3[i] <- ec.3$eCad[i]*exp(coef(mle.3)[1] + coef(mle.3)[2]*acen)
  nudist.3[[i]] <- ec.3$eCad[i]*exp(Z.3[,1] + Z.3[,2]*acen)
  nulo.3[i] <- quantile(nudist.3[[i]], probs = 0.025)
  numd.3[i] <- quantile(nudist.3[[i]], probs = 0.5)
  nuhi.3[i] <- quantile(nudist.3[[i]], probs = 0.975)
  
  numn.4[i] <- ec.4$eCad[i]*exp(coef(mle.4)[1] + coef(mle.4)[2]*acen)
  nudist.4[[i]] <- ec.4$eCad[i]*exp(Z.4[,1] + Z.4[,2]*acen)
  nulo.4[i] <- quantile(nudist.4[[i]], probs = 0.025)
  numd.4[i] <- quantile(nudist.4[[i]], probs = 0.5)
  nuhi.4[i] <- quantile(nudist.4[[i]], probs = 0.975)
}

ec.1$hazlo <- nulo.1
ec.1$hazmn <- numn.1
ec.1$hazhi <- nuhi.1
ec.2$hazlo <- nulo.2
ec.2$hazmn <- numn.2
ec.2$hazhi <- nuhi.2
ec.3$hazlo <- nulo.3
ec.3$hazmn <- numn.3
ec.3$hazhi <- nuhi.3
ec.4$hazlo <- nulo.4
ec.4$hazmn <- numn.4
ec.4$hazhi <- nuhi.4

ec.m <- rbind(ec.1,ec.2,ec.3,ec.4)
dim(ec.m)
names(ec.m)

ec.w <- rbind(ec.1,ec.2,ec.3,ec.4)
dim(ec.w)
names(ec.w)

ec <- rbind(ec.w,ec.m)
dim(ec)
setwd(curvdir)
fsavname <- "haz-unc-a55_90.Rdata"
save(ec,file = fsavname)


