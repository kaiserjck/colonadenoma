#----------------------------------------------
# test hypergeometric function
# jck, 2021/05/18
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
library(gsl) # for hypergeometric function 2F1
library(hypergeo) # for hypergeometric function 2F1
library(BMS) # for hypergeometric function 2F1
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#setwd(pardir)
#parDF <- read.csv ("temp/flat-noN0-all-m-3d-K1-std_parms.csv")

upar <- vector()
#upar <- as.numeric(parDF$parval)
upar[1] <- 4.04E-02	
upar[2] <- 51.6	
upar[3] <- 0.0221	
upar[4] <- 0.0105


f21hyper(30,1,20,.8) #returns about 165.8197
hyperg_2F1(30,1,20,.8, give=F, strict=TRUE)
hyperg_2F1_renorm(30,1,20,.8, give=F, strict=TRUE)
hypergeo(30,1,20,.8)
f21hyper(30,10,20,0) # returns one
hyperg_2F1(30,10,20,0)
f21hyper(10,15,20,-0.1) # returns about 0.4872972
hyperg_2F1(10,15,20,-0.1)

one_minus_axi <- function (s1, age, alpha, gamma)
{
  dage <- age - s1
  
  beta <- alpha-gamma
  
  zaehler <- exp(gamma*dage) - 1
  nenner <- alpha*exp(gamma*dage) - beta
  xi <- zaehler/nenner
  
  return (1-alpha*xi)
}

# functions for exact K1
# integrated sum of p_n(s,t)
# interchange of summation and integration
sum_pj <- function(s1,age,alp,gam,rho,ymin)
{
  
  nind <- seq(0,ymin,1)
  ndim <- length(nind)
  axi <- one_minus_axi(s1,age,alp,gam)
  sumbi <- vector()
  for(i in 1:ndim)
  {
    sumbi[i] <- dnbinom(nind[i],rho,axi)
    print(sumbi[i])
  }
  
  cat(sprintf("s1 = %g, axi = %g, sumbi = %g\n", s1, axi, sum(sumbi)))
  return (sum(sumbi))
}

intsum_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- integrate(lsum_pj, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  
  return (t - P_y0) # integrated p_1^(1)(s1,t)
}

lsum_pj <- function(s1,ages,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  sumbi <- vector()
  sumbi <- unlist(lapply(1:ndim, function(i) sum(dnbinom(nind,rho,one_minus_axi(agei[i],ages,alp,gam)))))
  return (sumbi)
}

lintsum_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- vector()
  ndim <- length(t)
  P_y0 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(lsum_pj, lower = 0, upper = t[i], ages = t[i], alp, gam, rho, ymin)$value))
  
  return (t - P_y0) # integrated p_2^(1)(s2,t)
}

#hyperg_2F1(a, b, c, x, give=FALSE, strict=TRUE)
integ_one_minus_sum_pj_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  p_ymin <- dnbinom(ymin+1,rho,one_minus_axi(s1,age,alp,gam))
  
  axi <- 1 - one_minus_axi(s1,age,alp,gam)
  hgf <- Re(hypergeo(1, 1+rho+ymin, 2+ymin, axi))
  
  return(p_ymin*hgf) # same as 1-sum_pj: to be tested
}

int2F1_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  pn_K1 <- integrate(integ_one_minus_sum_pj_2F1, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  return (pn_K1) # integrated 1 - p_1^(1)(s1,t)
}

linteg_one_minus_sum_pj_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  
  one_minus_sumbi <- vector()
  one_minus_sumbi <- unlist(lapply(1:ndim, function(i)
    dnbinom(ymin+1,rho,one_minus_axi(agei[i],age,alp,gam))*Re(hypergeo(1,1+rho+ymin,2+ymin,1-one_minus_axi(agei[i],age,alp,gam)))))
  
  return(one_minus_sumbi) # same as 1-sum_pj: to be tested
}

lint2F1_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  pn_K1 <- vector()
  ndim <- length(t)
  pn_K1 <- unlist(lapply(1:ndim, 
                         function(i) 
                           integrate(linteg_one_minus_sum_pj_2F1, lower = 0, upper = t[i], age = t[i], alp, gam, rho, ymin)$value))
  return (pn_K1) # integrated 1 - p_1^(1)(s1,t)
}

agem <- 65
alp <- upar[2]
gam <- upar[3]
rho <- upar[4]
ymin <- 50

1-lsum_pj(0,agem,alp,gam,rho,ymin)
axi <- 1 - one_minus_axi(0*agem,agem,alp,gam)
dnbinom(ymin+1,rho,one_minus_axi(0,agem,alp,gam))*Re(hypergeo(1, 1+rho+ymin, 2+ymin, axi))
integ_one_minus_sum_pj_2F1(0,agem,alp,gam,rho,ymin)
linteg_one_minus_sum_pj_2F1(0,agem,alp,gam,rho,ymin)

agem-integrate(lsum_pj, lower = 0, upper = agem, agem, alp, gam, rho, ymin)$value
lintsum_pn_K1(agem,alp,gam,rho,ymin)
int2F1_pn_K1(agem,alp,gam,rho,ymin)
lint2F1_pn_K1(agem,alp,gam,rho,ymin)

hyperg_2F1(1, 1+rho+ymin, 2+ymin, axi, give=F, strict=TRUE)
hyperg_2F1_conj_renorm(1, 1+rho+ymin, 2+ymin, axi, give=F, strict=TRUE)
hypergeo(1, 1+rho+ymin, 2+ymin, axi, tol = 1e-6)





