#-------------------------------------------------------------
# likelihood functions for grouped patients
# models K0, K1.app, K1, K2.app
# i
# jck, 2021/05/20
#-------------------------------------------------------------

#--------------------------------------------------------------
# define global variables for likelihood calculation
#--------------------------------------------------------------

source("globvar.R")

#---------------------------------------------------
# model independent functions
#---------------------------------------------------
# adenoma size categories
likeli_si_pedu <- function(sizecat, iage, pno_cat)
{
  p_pat <- 1 # "<DL"
  switch(as.character(sizecat),
         #"<0.5"={p_pat <- pno_cat[[1]][iage]},
         "0.5-1"={p_pat <- pno_cat[[1]][iage]},
         "1-2"={p_pat <- pno_cat[[2]][iage]},
         ">2"={p_pat <- pno_cat[[3]][iage]} 
  )
  return (p_pat)
}

likeli_si_sefl <- function(sizecat, iage, pno_cat)
{
  p_pat <- 1 # "<DL"
  switch(as.character(sizecat),
         "<0.5"={p_pat <- pno_cat[[1]][iage]},
         "0.5-1"={p_pat <- pno_cat[[2]][iage]},
         "1-2"={p_pat <- pno_cat[[3]][iage]},
         ">2"={p_pat <- pno_cat[[4]][iage]} 
  )
  return (p_pat)
}

# assign shape-dependent function
if(shp == "peduncular") {likeli_si <- likeli_si_pedu} # 3 size categories
if(shp == "sessile" | shp == "flat") {likeli_si <- likeli_si_sefl} # 4 size categories

# adenoma number categories
likeli_no <- function(countcat, p_pat)
{
  n2_4 <- c(2:4)
  n0_4 <- c(0:4)
  switch(countcat,
         "0"={lik <- 1},
         "1"={lik <- p_pat},
         #"2-4"={lik <- p_pat^2/2+p_pat^3/6+p_pat^4/24},
         "2-4"={lik <- sum(p_pat^n2_4/factorial(n2_4))},
         ">=5"={lik <- exp(p_pat) - sum(p_pat^n0_4/factorial(n0_4))} 
  )
  return (lik)
}

#------------------------------------------------------
# K=0
#------------------------------------------------------
library('VGAM') # Lerch function

# Cristoforo Simonetto
# corrected 2021/06/09, jck
pn_K0_ler <- function (t,alp,gam,n) # n -> ymin
{
  ax <- alp*(exp(gam*t)-1)/(alp*exp(gam*t)-(alp-gam))
  return(ax^(1+n)*lerch(ax,1,1+n)/alp)
}

# adenoma size
sinteg_Gg_K0 <- function (s0, age, alp, gam, n)
{
  
  dage <- s0-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)*(gfunc/Gfunc)
  return(f2*(f1^n))
}

# integration over age (for discrete cell number)
sinteg_pn_K0 <- function (t,alp,gam,ys)
{
  ndim <- length(t)
  pnK0 <- vector()
  pnK0 <- unlist(lapply(1:ndim, 
                        function(i) 
                        {ifelse(ys[i] > 0, integrate(sinteg_Gg_K0, lower = 0, upper = t[i], age = t[i], alp, gam, n = ys[i])$value, 1)}))
  #return (alp*pnK0)
  return (pnK0) # jck, 2021/08/25
}

# for cell size distribution
# corrected 2021/06/09, jck
pnlohi_K0_ler <- function (t,alp,gam,ylo,yhi) 
{
  ax <- alp*(exp(gam*t)-1)/(alp*exp(gam*t)-(alp-gam))
  fhi <- {ifelse(yhi > 0, ax^(1+yhi)*lerch(ax,1,1+yhi)/alp, 0)} # yhi < 0 for highest cat
  flo <- ax^(1+ylo)*lerch(ax,1,1+ylo)/alp
  return(flo-fhi)
}

sdevianceK0 <- function(X0, alp, gam, bx, ba, bg, df)
{
  age <- df$age
  acen <- df$acen
  pno <- df$pno
  ylo <- df$ylo
  yhi <- df$yhi
  npat <- df$npat
  shape <- df$shape
  
  aX0 <- vector()
  aX0 <- exp(bx*acen)
  aalp <- vector()
  aalp <- exp(ba*acen)
  agam <- vector()
  agam <- exp(ba*acen)
  
  # -ENadK0 for detectable adenoma
  ENadK0 <- vector()
  ENadK0 <- X0*aX0*pn_K0_ler(age,aalp*alp,agam*gam,gb.ymin) # -ENadK0
  
  lnP0 <- vector()
  lnP0 <- -ENadK0
  
  # adenoma size for K=0
  p_pat <- vector()
  p_pat <- {ifelse(shape != "none", X0*aX0*pnlohi_K0_ler(age,aalp*alp,agam*gam,ylo,yhi), 1)}
  p_pat_ot <- vector()
  p_pat_ot <- {ifelse(shape != "none", X0*aX0*pnlohi_K0_ler(age,aalp*alp,agam*gam,gb.ymin,yhi), 1)} # other adenoma
  
  lnj <- vector()
  lnj <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  # all adenoma in largest category
  #lnj <- {ifelse(shape != "none", pno*log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  lnlik <- sum(npat*lnj) + sum(npat*lnP0)
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*lnj)))
  
  return (-2*lnlik)
}

# df known via data =
smloglikK0 <- function (X0, alp, gam, bx, ba, bg)
{
  mdl_call()
  
  aX0 <- vector()
  aX0 <- exp(bx*acen)
  aalp <- vector()
  aalp <- exp(ba*acen)
  agam <- vector()
  agam <- exp(ba*acen)
  
  # -ENadK0 for detectable adenoma
  ENadK0 <- vector()
  ENadK0 <- X0*aX0*pn_K0_ler(age,aalp*alp,agam*gam,gb.ymin) # -ENadK0
  
  lnP0 <- vector()
  lnP0 <- -ENadK0
  
  # adenoma size for K=0
  p_pat <- vector()
  p_pat <- {ifelse(shape != "none", X0*aX0*pnlohi_K0_ler(age,aalp*alp,agam*gam,ylo,yhi), 1)}
  p_pat_ot <- vector()
  p_pat_ot <- {ifelse(shape != "none", X0*aX0*pnlohi_K0_ler(age,aalp*alp,agam*gam,gb.ymin,yhi), 1)} # other adenoma
  
  lnj <- vector()
  lnj <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used

  lnlik <- sum(npat*lnj) + sum(npat*lnP0)
  
  return (-lnlik)
}

snloglikK0 <- function (par)
{
  mdl_call()
  
  X0 <- par[1]
  alp <- par[2]
  gam <- par[3]
  bx <- par[4]
  ba <- par[5]
  #bg <- par[6]
  
  age <- df$age
  acen <- df$acen
  pno <- df$pno
  ylo <- df$ylo
  yhi <- df$yhi
  npat <- df$npat
  shape <- df$shape
  
  aX0 <- vector()
  aX0 <- exp(bx*acen)
  aalp <- vector()
  aalp <- exp(ba*acen)
  agam <- vector()
  agam <- exp(ba*acen)
  
  # -ENadK0 for detectable adenoma
  ENadK0 <- vector()
  ENadK0 <- X0*aX0*pn_K0_ler(age,aalp*alp,agam*gam,gb.ymin) # -ENadK0
  
  lnP0 <- vector()
  lnP0 <- -ENadK0
  
  # adenoma size for K=0
  p_pat <- vector()
  p_pat <- {ifelse(shape != "none", X0*aX0*pnlohi_K0_ler(age,aalp*alp,agam*gam,ylo,yhi), 1)}
  p_pat_ot <- vector()
  p_pat_ot <- {ifelse(shape != "none", X0*aX0*pnlohi_K0_ler(age,aalp*alp,agam*gam,gb.ymin,yhi), 1)} # other adenoma
  
  lnj <- vector()
  lnj <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  # all adenoma in largest category
  #lnj <- {ifelse(shape != "none", pno*log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  lnlik <- sum(npat*lnj) + sum(npat*lnP0)

  return (-lnlik)
}

#------------------------------------------------------
# K=1, approximated mu_1/alpha = rho  << 1
#------------------------------------------------------
# K=1, integral for approximated model
# partial geometric sum
# Reinhard Meckbach
# corrected 2021/06/09, jck
ainteg_Gg_K1.app <- function (s1, age, alp, gam, n)
{
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)
  return (s1*f2*(f1^n)) # linear age dependence on s1 in approximation
}

# vectorizable with lapply
pn_K1.app <- function (t,alp,gam,ymin) 
{
  ndim <- length(t)
  pnK1 <- vector()
  pnK1 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(ainteg_Gg_K1.app, lower = 0, upper = t[i], age = t[i], alp[i], gam[i], n = ymin)$value))
  return (pnK1)
}

pnlohi_K1.app <- function (t,alp,gam,ylo,yhi) 
{
  ndim <- length(t)
  fhi <- unlist(lapply(1:ndim, function(i) {ifelse(yhi[i] > 0, pn_K1.app(t[i],alp[i],gam[i],yhi[i]), 0)})) # yhi < 0 for highest cat
  flo <- unlist(lapply(1:ndim, function(i) pn_K1.app(t[i],alp[i],gam[i],ylo[i])))
  return(flo-fhi)
}

sdevianceK1.app <- function(X0, alp, gam, bx, ba, bg, df)
{
  age <- df$age
  acen <- df$acen
  yhi <- df$yhi
  ylo <- df$ylo
  ymin <- df$ymin
  pno <- df$pno
  npat <- df$npat
  shape <- df$shape
  
  aX0 <- vector()
  aX0 <- exp((bx-ba)*acen) # account for mu_1/rho
  aalp <- vector()
  aalp <- exp(ba*acen)
  agam <- vector()
  agam <- exp(ba*acen)
  
  # -ENadK1 for detectable adenoma
  lnP0 <- vector()
  lnP0 <- -X0*aX0/aalp*pn_K1.app (age,aalp*alp,agam*gam,gb.ymin)
  
  # adenoma size for K=1.app
  p_pat <- vector()
  p_pat <- {ifelse(shape != "none", X0*aX0/aalp*pnlohi_K1.app(age,aalp*alp,agam*gam,ylo,yhi), 1)}
  p_pat_ot <- vector()
  p_pat_ot <- {ifelse(shape != "none", X0*aX0/aalp*pnlohi_K1.app(age,aalp*alp,agam*gam,ymin,yhi), 1)} # needs ymin as vector
  
  lnj <- vector()
  lnj <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  lnlik <- sum(npat*lnj) + sum(npat*lnP0)
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*lnj)))
  
  return (-2*lnlik)
}

smloglikK1.app <- function(X0, alp, gam, bx, ba, bg)
{
  mdl_call()
  
  countcat <- as.character(countcat) # switch needs expects character
  
  aX0 <- vector()
  aX0 <- exp((bx-ba)*acen) # account for mu_1/rho
  aalp <- vector()
  aalp <- exp(ba*acen)
  agam <- vector()
  agam <- exp(ba*acen)
  
  # -ENadK1 for detectable adenoma
  lnP0 <- vector()
  lnP0 <- -X0*aX0/aalp*pn_K1.app (age,aalp*alp,agam*gam,gb.ymin)
  
  # adenoma size for K=1.app
  p_pat <- vector()
  p_pat <- {ifelse(shape != "none", X0*aX0/aalp*pnlohi_K1.app(age,aalp*alp,agam*gam,ylo,yhi), 1)}
  p_pat_ot <- vector()
  p_pat_ot <- {ifelse(shape != "none", X0*aX0/aalp*pnlohi_K1.app(age,aalp*alp,agam*gam,ymin,yhi), 1)} # needs ymin as vector
  
  lnj <- vector()
  lnj <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  lnlik <- sum(npat*lnj) + sum(npat*lnP0)
  
  return(-lnlik)
}

snloglikK1.app <- function(par)
{
  mdl_call()
  
  X0 <- par[1]
  alp <- par[2]
  gam <- par[3]
  bx <- par[4]
  ba <- par[5]
  #bg <- par[6]
  
  age <- df$age
  acen <- df$acen
  yhi <- df$yhi
  ylo <- df$ylo
  ymin <- df$ymin
  pno <- df$pno
  npat <- df$npat
  shape <- df$shape
  
  aX0 <- vector()
  aX0 <- exp((bx-ba)*acen) # account for mu_1/rho
  aalp <- vector()
  aalp <- exp(ba*acen)
  agam <- vector()
  agam <- exp(ba*acen)
  
  # -ENadK1 for detectable adenoma
  lnP0 <- vector()
  lnP0 <- -X0*aX0/aalp*pn_K1.app (age,aalp*alp,agam*gam,gb.ymin)
  
  # adenoma size for K=1.app
  p_pat <- vector()
  p_pat <- {ifelse(shape != "none", X0*aX0/aalp*pnlohi_K1.app(age,aalp*alp,agam*gam,ylo,yhi), 1)}
  p_pat_ot <- vector()
  p_pat_ot <- {ifelse(shape != "none", X0*aX0/aalp*pnlohi_K1.app(age,aalp*alp,agam*gam,ymin,yhi), 1)} # needs ymin as vector
  
  lnj <- vector()
  lnj <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  lnlik <- sum(npat*lnj) + sum(npat*lnP0)
 
  return(-lnlik)
}

#-----------------------------------------------------
# K=1, exact
#-----------------------------------------------------
one_minus_axi <- function (s1, age, alpha, gamma)
{
  
  dage <- age - s1
  
  beta <- alpha-gamma
  
  zaehler <- exp(gamma*dage) - 1
  nenner <- alpha*exp(gamma*dage) - beta
  xi <- zaehler/nenner
  
  return (1-alpha*xi)
}

lsum_pj <- function(s1,ages,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  sumbi <- vector()
  sumbi <- unlist(lapply(1:ndim, function(i) sum(dnbinom(nind,rho,one_minus_axi(agei[i],ages,alp,gam)))))
  return (sumbi)
}

lintsum_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- vector()
  ndim <- length(t)
  P_y0 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(lsum_pj, lower = 0, upper = t[i], ages = t[i], alp, gam, rho, ymin)$value))
  
  return (t - P_y0) # integrated p_2^(1)(s2,t)
}

sdevianceK1.sum <- function(X0, alp, gam, rho, bx, ba, bg, df)
{
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  intsum_pK1_y <- list()
  for (j in 1:gb.nsc)
  {
    intsum_pK1_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lintsum_pn_K1(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(intsum_pK1_y[[j]]) - unlist(intsum_pK1_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(intsum_pK1_y[[1]]) - unlist(intsum_pK1_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(intsum_pK1_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(intsum_pK1_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -intsum_pK1_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0i)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  return (-2*lnlik)
}

# df is known via data =
smloglikK1.sum <- function(X0, alp, gam, rho, bx, ba, bg)
{
  mdl_call()
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  intsum_pK1_y <- list()
  for (j in 1:gb.nsc)
  {
    intsum_pK1_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lintsum_pn_K1(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(intsum_pK1_y[[j]]) - unlist(intsum_pK1_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(intsum_pK1_y[[1]]) - unlist(intsum_pK1_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(intsum_pK1_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(intsum_pK1_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -intsum_pK1_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}

snloglikK1.sum <- function(par)
{
  mdl_call()
  
  X0 <- par[1]
  alp <- par[2]
  gam <- par[3]
  rho <- par[4]
  bx <- par[5]
  ba <- par[6]
  #bg <- par[7]
  
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character  
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  intsum_pK1_y <- list()
  for (j in 1:gb.nsc)
  {
    intsum_pK1_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lintsum_pn_K1(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(intsum_pK1_y[[j]]) - unlist(intsum_pK1_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(intsum_pK1_y[[1]]) - unlist(intsum_pK1_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(intsum_pK1_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(intsum_pK1_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -intsum_pK1_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}

#-------------------------------------------------------------------
# K=1, exact, hypergeometric function
#-------------------------------------------------------------------

library(hypergeo) # for hypergeometric function 2F1

linteg_one_minus_sum_pj_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  
  one_minus_sumbi <- vector()
  one_minus_sumbi <- unlist(lapply(1:ndim, function(i)
    dnbinom(ymin+1,rho,one_minus_axi(agei[i],age,alp,gam))*Re(hypergeo(1,1+rho+ymin,2+ymin,1-one_minus_axi(agei[i],age,alp,gam), tol = 1e-6))))
  
  return(one_minus_sumbi) # same as 1-sum_pj: to be tested
}

lint2F1_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  pn_K1 <- vector()
  ndim <- length(t)
  pn_K1 <- unlist(lapply(1:ndim, 
                         function(i) 
                           integrate(linteg_one_minus_sum_pj_2F1, lower = 0, upper = t[i], age = t[i], alp, gam, rho, ymin)$value))
  return (pn_K1) # integrated 1 - p_1^(1)(s1,t)
}

sdevianceK1 <- function(X0, alp, gam, rho, bx, ba, bg, df)
{
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  intsum_pK1_y <- list()
  for (j in 1:gb.nsc)
  {
    intsum_pK1_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lint2F1_pn_K1(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(intsum_pK1_y[[j]]) - unlist(intsum_pK1_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(intsum_pK1_y[[1]]) - unlist(intsum_pK1_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(intsum_pK1_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(intsum_pK1_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -intsum_pK1_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0i)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  return (-2*lnlik)
}

# df is known via data =
smloglikK1 <- function(X0, alp, gam, rho, bx, ba, bg)
{
  mdl_call()
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  intsum_pK1_y <- list()
  for (j in 1:gb.nsc)
  {
    intsum_pK1_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lint2F1_pn_K1(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(intsum_pK1_y[[j]]) - unlist(intsum_pK1_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(intsum_pK1_y[[1]]) - unlist(intsum_pK1_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(intsum_pK1_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(intsum_pK1_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -intsum_pK1_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}

snloglikK1 <- function(par)
{
  mdl_call()

  X0 <- par[1]
  alp <- par[2]
  gam <- par[3]
  rho <- par[4]
  bx <- par[5]
  ba <- par[6]
  #bg <- par[7]
  
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  intsum_pK1_y <- list()
  for (j in 1:gb.nsc)
  {
    intsum_pK1_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lint2F1_pn_K1(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(intsum_pK1_y[[j]]) - unlist(intsum_pK1_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(intsum_pK1_y[[1]]) - unlist(intsum_pK1_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(intsum_pK1_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(intsum_pK1_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -intsum_pK1_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}

#----------------------------------------------------------------------
# K=2, approximation of one subclone
#----------------------------------------------------------------------

# approximation of one subclone
# multiply by s1
sinteg_pn_K2 <- function(age,alp,gam,rho,ys)
{
  
  ndim <- length(age)
  intpn <- vector()
  # multiply by s1: one subclone approximation
  intpn <- unlist(lapply(1:ndim, 
                         function(i) {ifelse(ys[i] > 0, integrate(function(s1, j=ys[i]) s1*dnbinom(j,rho,one_minus_axi(s1,age[i],alp,gam)),
                                                                  lower=0,upper=age[i])$value, 1)})
  )
  return(intpn)
}

# integrated sum of p_n(s,t)
# interchange of summation and integration
sum_pj_age <- function(s1,age,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  sumbi <- sum(s1*dnbinom(nind,rho,one_minus_axi(s1,age,alp,gam))) # multiply by s1: one subclone approximation
  
  return (sumbi)
}

lsum_pj_age <- function(s1,ages,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  sumbi <- vector()
  sumbi <- unlist(lapply(1:ndim, function(i) sum(agei[i]*dnbinom(nind,rho,one_minus_axi(agei[i],ages,alp,gam)))))
  return (sumbi)
}

intSum_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- integrate(lsum_pj_age, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  retarg <- ((t^2)/2 - P_y0)
  return (retarg) # integrated p_1^(1)(s1,t)
}

lintSum_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- vector()
  ndim <- length(t)
  P_y0 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(lsum_pj_age, lower = 0, upper = t[i], ages = t[i], alp, gam, rho, ymin)$value))
  retarg <- ((t^2)/2 - P_y0)
  return (retarg) # integrated p_2^(1)(s2,t)
}

sdevianceK2.sum <- function(X0, alp, gam, rho, bx, ba, bg, df)
{
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  int_pK2_y <- list()
  for (j in 1:gb.nsc)
  {
    int_pK2_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lintSum_pn_K2(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(int_pK2_y[[j]]) - unlist(int_pK2_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(int_pK2_y[[1]]) - unlist(int_pK2_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(int_pK2_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(int_pK2_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -int_pK2_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0i)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  return (-2*lnlik)
}

# df is known via data =
smloglikK2.sum <- function(X0, alp, gam, rho, bx, ba, bg)
{
  mdl_call()
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  int_pK2_y <- list()
  for (j in 1:gb.nsc)
  {
    int_pK2_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lintSum_pn_K2(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(int_pK2_y[[j]]) - unlist(int_pK2_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(int_pK2_y[[1]]) - unlist(int_pK2_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(int_pK2_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(int_pK2_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -int_pK2_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}

snloglikK2.sum <- function(par)
{
  mdl_call()
  
  X0 <- par[1]
  alp <- par[2]
  gam <- par[3]
  rho <- par[4]
  bx <- par[5]
  ba <- par[6]
  #bg <- par[7]
  
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  int_pK2_y <- list()
  for (j in 1:gb.nsc)
  {
    int_pK2_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*lintSum_pn_K2(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(int_pK2_y[[j]]) - unlist(int_pK2_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(int_pK2_y[[1]]) - unlist(int_pK2_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(int_pK2_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(int_pK2_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -int_pK2_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}

#----------------------------------------------------------------------
# K=2, approximation of one subclone, hypergeometric function
#----------------------------------------------------------------------
library(hypergeo)

integ_one_minus_sum_pj_age_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  p_ymin <- dnbinom(ymin+1,rho,one_minus_axi(s1,age,alp,gam))
  
  axi <- 1 - one_minus_axi(s1,age,alp,gam)
  hgf <- Re(hypergeo(1, 1+rho+ymin, 2+ymin, axi))
  return(s1*p_ymin*hgf) # multiply by s1: one subclone approximation
}

int2F1_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  pn_K2 <- integrate(integ_one_minus_sum_pj_age_2F1, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  return (pn_K2) # integrated s*(1 - p_1^(1)(s1,t))
}

sdevianceK2.app <- function(X0, alp, gam, rho, bx, ba, bg, df)
{
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  int_pK2_y <- list()
  for (j in 1:gb.nsc)
  {
    int_pK2_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*int2F1_pn_K2(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(int_pK2_y[[j]]) - unlist(int_pK2_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(int_pK2_y[[1]]) - unlist(int_pK2_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(int_pK2_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(int_pK2_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -int_pK2_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0i)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  return (-2*lnlik)
}

# df is known via data =
smloglikK2.app <- function(X0, alp, gam, rho, bx, ba, bg)
{
  mdl_call()
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  int_pK2_y <- list()
  for (j in 1:gb.nsc)
  {
    int_pK2_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*int2F1_pn_K2(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(int_pK2_y[[j]]) - unlist(int_pK2_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(int_pK2_y[[1]]) - unlist(int_pK2_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(int_pK2_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(int_pK2_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -int_pK2_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}

snloglikK2.app <- function(par)
{
  mdl_call()
  
  X0 <- par[1]
  alp <- par[2]
  gam <- par[3]
  rho <- par[4]
  bx <- par[5]
  ba <- par[6]
  #bg <- par[7]
  
  age <- df$age
  npat <- df$npat
  pno <- df$pno
  shape <- df$shape
  sizecat <- as.character(df$sizecat) # switch expects character
  
  # all unique ages
  ages <- seq(min(age),max(age),1)
  nage <- length(ages)
  
  asX0 <- vector()
  asX0 <- exp(bx*(ages-65)/10)
  asalp <- vector()
  asalp <- exp(ba*(ages-65)/10)
  asgam <- vector()
  asgam <- exp(ba*(ages-65)/10)
  
  # all patients
  ndim <- length(age)
  minage <- as.integer(min(age)+.5)
  iage <- as.integer(age+.5)-minage+1
  
  # computation load goes here
  # all unique ages
  int_pK2_y <- list()
  for (j in 1:gb.nsc)
  {
    int_pK2_y[[j]] <- unlist(lapply(1:nage, function(i) X0*asX0[i]*int2F1_pn_K2(ages[i],alp*asalp[i],gam*asgam[i],rho/asalp[i],gb.ylo[j])))
  }
  
  # calculate cumulative size probabilities for unique ages is fast
  pno_cat <- list()
  pno_cat_ot <- list()
  for (j in 1:(gb.nsc-1))
  {
    pno_cat[[j]] <-  unlist(int_pK2_y[[j]]) - unlist(int_pK2_y[[j+1]])
    pno_cat_ot[[j]] <-  unlist(int_pK2_y[[1]]) - unlist(int_pK2_y[[j+1]])
  }
  pno_cat[[gb.nsc]] <-  unlist(int_pK2_y[[gb.nsc]])
  pno_cat_ot[[gb.nsc]] <-  unlist(int_pK2_y[[1]])
  
  # extract expectation value ENadK1
  lnP0 <- vector()
  lnP0 <- -int_pK2_y[[1]] # -ENadK1
  lnP0i <- vector()
  lnP0i <- unlist(lapply(1:ndim, function(i) lnP0[iage[i]]))
  
  # adenoma size for K=1: size categories
  p_pat <- vector()
  p_pat <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat)))
  p_pat_ot <- vector()
  p_pat_ot <- unlist(lapply(1:ndim, function(i) likeli_si(sizecat[i], iage[i], pno_cat_ot)))
  
  sino <- vector()
  sino <- {ifelse(shape != "none", (pno-1)*log(p_pat_ot) + log(p_pat), 0)} # pno = 0,1,2,5; 0 for "none" not used
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0i)
  
  return(-lnlik)
}


