#-------------------------------------------------------------
# 2021/06/09, jck
#-------------------------------------------------------------

#--------------------------------------------------------------
# define global variables for likelihood calculation
#--------------------------------------------------------------

gb <- {}

# ages
gb.ages <- seq(min(df$age),max(df$age),1)
gb.nage <- length(gb.ages)

# age index
gb.ndim <- length(df$age)
gb.minage <- as.integer(min(df$age)+.5)
gb.iage <- vector()
gb.iage <- as.integer(df$age+.5)-gb.minage+1 # starts with iage = 1

# cell numbers at boundaries
gb.ymin <- df$ymin[1]
gb.smin <- 0.25
if(shp == "peduncular") {gb.smin <- 0.5}

# unique lower boundaries define cell size categories
dum <- unique(df$ylo)
dum <- sort(dum)
{
  if(min(dum) == 0){
    gb.ylo <- dum[2:length(dum)] # skip ylo = 0
  }
  else if (min(dum) > 0){
    gb.ylo <- dum
  }
}

#if(shp == "peduncular") {gb.ylo <- c(gb.ymin,unique(df$ylo))} # insert dummy for gb.ylo[1]
gb.nsc <- length(gb.ylo) # should be four for sess, flat and three for pedu

# make model parameters global
#gb.upar <- dpar$parval

#------------------------------------------------------
# growth model fitting
# with parallel calls
#------------------------------------------------------

# model call counting
mmcall <- 0
mdl_call <- function() 
{
  mmcall <<- mmcall + 1 # global counter <<-
  if (mmcall < 10)
  {
    strg <- sprintf("Call: %d", mmcall)
    print(strg, quote = F)
  }
  else if (mmcall >= 10 & mmcall < 100)
  {
    if ((mmcall %% 10) == 0)
    {strg <- sprintf("Call: %d", mmcall)
    print(strg, quote = F)} 
  }
  else
  {
    if ((mmcall %% 100) == 0)
    {strg <- sprintf("Call: %d", mmcall)
    print(strg, quote = F)} 
  }
  return(mdl_call)
}