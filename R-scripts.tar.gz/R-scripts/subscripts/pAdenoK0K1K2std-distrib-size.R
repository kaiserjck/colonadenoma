#-------------------------------------------------------------
# evaluation functions for grouped patients
# models K0, K1.app, K1, K2.app
# adjusted to Bavarian data
# jck, 2021/09/13
#-------------------------------------------------------------

#--------------------------------------------------------------
# define global variables for likelihood calculation
#--------------------------------------------------------------

source("globvar.R")

#---------------------------------------------------
# model independent functions
#---------------------------------------------------
# adenoma size categories
likeli_si_pedu <- function(sizecat, iage, pno_cat)
{
  p_pat <- 1 # "<DL"
  switch(sizecat,
         #"<0.5"={p_pat <- pno_cat[[1]][iage]},
         "0.5-1"={p_pat <- pno_cat[[1]][iage]},
         "1-2"={p_pat <- pno_cat[[2]][iage]},
         ">2"={p_pat <- pno_cat[[3]][iage]} 
  )
  return (p_pat)
}

likeli_si_sefl <- function(sizecat, iage, pno_cat)
{
  p_pat <- 1 # "<DL"
  switch(sizecat,
         "<0.5"={p_pat <- pno_cat[[1]][iage]},
         "0.5-1"={p_pat <- pno_cat[[2]][iage]},
         "1-2"={p_pat <- pno_cat[[3]][iage]},
         ">2"={p_pat <- pno_cat[[4]][iage]} 
  )
  return (p_pat)
}

# assign shape-dependent function
if(shp == "peduncular") {likeli_si <- likeli_si_pedu} # 3 size categories
if(shp == "sessile" | shp == "flat") {likeli_si <- likeli_si_sefl} # 4 size categories

# adenoma number categories
likeli_no <- function(countcat, p_pat)
{
  n2_4 <- c(2:4)
  n0_4 <- c(0:4)
  switch(countcat,
         "0"={lik <- 1},
         "1"={lik <- p_pat},
         "2-4"={lik <- sum(p_pat^n2_4/factorial(n2_4))},
         ">=5"={lik <- exp(p_pat) - sum(p_pat^n0_4/factorial(n0_4))} 
  )
  return (lik)
}

# Probability of N adenoma
Padeno_N <- function(Count, ENad)
{
  Count <- as.character(Count) # switch needs character
  prob <- 0
  switch(Count,
         "0"={prob <- dpois(0,ENad)},
         "1"={prob <- dpois(1,ENad)},
         "2-4"={prob <- dpois(2,ENad) + dpois(3,ENad) + dpois(4,ENad)},
         ">=5"={prob <- 1 - dpois(0,ENad) - dpois(1,ENad) - dpois(2,ENad) - dpois(3,ENad) - dpois(4,ENad)} 
  )
  return (prob)
}

Padeno_bin <- function(Count, ENad)
{
  Count <- as.character(Count) # switch needs character
  prob <- 0
  switch(Count,
         "no"={prob <- dpois(0,ENad)},
         "yes"={prob <- 1 - dpois(0,ENad)}
  )
  return (prob)
}

# Probability of adenoma size interval
#Padeno_S <- function(sizecat, age)
#{
#  p_size <- 1 # "<DL"
#  switch(sizecat,
#         "<0.5"={p_size <- },
#         "0.5-1"={p_size <- },
#         "1-2"={p_size <- },
#         ">2"={p_size <- } 
#  )
#  return (p_size)
#}

#------------------------------------------------------
# K=0
#------------------------------------------------------
library('VGAM') # Lerch function

# Cristoforo Simonetto
# corrected 2021/06/09, jck
pn_K0_ler <- function (t,alp,gam,n) # n -> ymin
{
  ax <- alp*(exp(gam*t)-1)/(alp*exp(gam*t)-(alp-gam))
  return(ax^(1+n)*lerch(ax,1,1+n)/alp)
}

# expected number of Adenoma
ENadK0 <- function (age,upar,ymin)
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  return(X0 * pn_K0_ler(age,alp,gam,ymin))
}

# for cell size distribution
# corrected 2021/06/09, jck
theta_lohi_K0_ler <- function (t,upar,ylo,yhi) 
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  ax <- alp*(exp(gam*t)-1)/(alp*exp(gam*t)-(alp-gam))
  fhi <- {ifelse(yhi > 0, ax^(1+yhi)*lerch(ax,1,1+yhi)/alp, 0)} # yhi < 0 for highest cat
  flo <- ax^(1+ylo)*lerch(ax,1,1+ylo)/alp
  
  {retarg <- ifelse (ylo == 0, 0, flo-fhi)} # p = 0 below detection limit
  
  return(X0*retarg)
}

ainteg_Gg_K0 <- function (s1, age, alp, gam, n)
{
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)
  return (f2*(f1^n))
}

sinteg_Gg_K0 <- function (s1, age, alp, gam, n)
{
  
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)*(gfunc/Gfunc)
  return(f2*(f1^n))
}

sum_ydim_K0 <- function(s1,age,alp,gam,dim,ymin,Ninf) # s1 is a vector()!
{
  nind <- seq(ymin+1,ymin+1+Ninf,1)
  agei <- s1
  ndim <- length(agei)
  sumbi <- unlist(lapply(1:ndim, function(i) sum((nind^(1/dim))*sinteg_Gg_K0(agei[i], age, alp, gam, nind))))
  return (sumbi)
}

EsizeK0.sum <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  zaehler <- integrate(sum_ydim_K0, lower = 0, upper = t, age = t, alp,gam,dim,ymin,Ninf)$value
  nenner <- pn_K0_ler(t,alp,gam,ymin)
  return(zaehler/nenner)
}

# integration faster as summation!
# needs vectorized age
integrand_ydim_K0 <- function(ys,s1,age,dim,alp,gam)
{
  retarg <- (ys^(1/dim))*sinteg_Gg_K0(s1, age, alp, gam, ys) 
  return(retarg)
}

integrate_ydim_K0 <- function(s1,age,alp,gam,dim,ymin,Ninf) # s1 is a vector()!
{
  ylo <- ymin+1
  yhi <- ylo + Ninf
  agei <- s1
  ndim <- length(agei)
  
  sumbi.int <- vector()
  sumbi.int <- unlist(lapply(1:ndim, function(i) 
                             integrate(integrand_ydim_K0, lower = ylo, upper = Inf, agei[i],age,dim,alp,gam)$value))
  return (sumbi.int)
}

EsizeK0 <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  zaehler <- integrate(integrate_ydim_K0, lower = 0, upper = t, age = t, alp,gam,dim,ymin,Ninf)$value # age integral
  nenner <- pn_K0_ler(t,alp,gam,ymin)
  return(zaehler/nenner)
}

# K=0
# cell expectation value
# partial geometric sum
# Reinhard Meckbach
minteg_Gg_K0 <- function (s1, age, alp, gam, n)
{
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/Gfunc
  f3 <- Gfunc/gfunc + n + 1
  return (f2*(f1^(n+1)*f3)) # (n+1)!
}

# stochastic expectation value of cell number
# for detectable adenoma at age t
ymeanK0 <- function(t,upar,ymin)
{
  alp <- upar[2]
  gam <- upar[3]
  
  ysm <- integrate(minteg_Gg_K0, lower = 0, upper = t, age = t, alp, gam, n = ymin)$value

  denom <-  pn_K0_ler (t,alp,gam,ymin)
  
  return(ysm/denom) 
}
#------------------------------------------------------
# K=1, approximated mu_1/alpha = rho  << 1
#------------------------------------------------------
# K=1, integral for approximated model
# partial geometric sum
# Reinhard Meckbach
# corrected 2021/06/09, jck
ainteg_Gg_K1.app <- function (s1, age, alp, gam, n)
{
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)
  return (s1*f2*(f1^n)) # linear age dependence on s1 in approximation
}

# vectorizable with lapply
pn_K1.app <- function (t,alp,gam,ys) 
{
  ndim <- length(t)
  pnK1 <- vector()
  pnK1 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(ainteg_Gg_K1.app, lower = 0, upper = t[i], age = t[i], alp, gam, n = ys[i])$value))
  return (pnK1)
}

# expected number of Adenoma
ENadK1.app <- function (ages,upar,ymin)
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  ndim <- length(ages)
  vymin <- rep(ymin,ndim)
  ENadK1 <- unlist(lapply(1:ndim, function(i) X0 * pn_K1.app(ages[i],alp,gam,vymin[i])))
  return(ENadK1)
}

theta_lohi_K1.app <- function (t,upar,ylo,yhi) 
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  ndim <- length(t)
  fhi <- unlist(lapply(1:ndim, function(i) {ifelse(yhi[i] > 0, pn_K1.app(t[i],alp,gam,yhi[i]), 0)})) # yhi < 0 for highest cat
  flo <- unlist(lapply(1:ndim, function(i) pn_K1.app(t[i],alp,gam,ylo[i])))
  
  {retarg <- ifelse (ylo == 0, 0, flo-fhi)} # p = 0 below detection limit
  
  return(X0*retarg)
}

# K=1
sinteg_Gg_K1.app <- function (s1, age, alp, gam, n)
{
  
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)*(gfunc/Gfunc)
  return(s1*f2*(f1^n)) # linear dependence on s1
}

sum_ydim_K1.app <- function(s1,age,alp,gam,dim,ymin,Ninf)
{
  nind <- seq(ymin+1,ymin+1+Ninf,1)
  agei <- s1
  
  ndim <- length(agei)
  sumbi <- unlist(lapply(1:ndim, function(i) sum((nind^(1/dim))*sinteg_Gg_K1.app(agei[i], age, alp, gam, nind))))
  
  return (sumbi)
}

EsizeK1.app.sum <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  zaehler <- integrate(sum_ydim_K1.app, lower = 0, upper = t, age = t, alp,gam,dim,ymin,Ninf)$value
  nenner <- pn_K1.app(t,alp,gam,ymin)
  return(zaehler/nenner)
}

# integration faster as summation!
# needs vectorized age
integrand_ydim_K1.app <- function(ys,s1,age,dim,alp,gam)
{
  retarg <- (ys^(1/dim))*sinteg_Gg_K1.app(s1, age, alp, gam, ys) 
  return(retarg)
}

integrate_ydim_K1.app <- function(s1,age,alp,gam,dim,ymin,Ninf) # s1 is a vector()!
{
  ylo <- ymin+1
  yhi <- ylo + Ninf
  agei <- s1
  ndim <- length(agei)
  
  sumbi.int <- vector()
  sumbi.int <- unlist(lapply(1:ndim, function(i) 
    integrate(integrand_ydim_K1.app, lower = ylo, upper = Inf, agei[i],age,dim,alp,gam)$value))
  return (sumbi.int)
}

EsizeK1.app <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  
  zaehler <- integrate(integrate_ydim_K1.app, lower = 0, upper = t, age = t, alp,gam,dim,ymin,Ninf)$value # age integral
  nenner <- pn_K1.app(t,alp,gam,ymin)
  return(zaehler/nenner)
}

# K=1, integrand for hybrid model
# cell expectation value
# partial geometric sum
# Reinhard Meckbach
minteg_Gg_K1 <- function (s1, age, alp, gam, n)
{
  dage <- s1-age
  gfunc <- exp(gam*dage)
  Gfunc <- alp/gam*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/Gfunc
  f3 <- Gfunc/gfunc+(n+1)
  return (s1*f2*(f1^(n+1)*f3)) # (n+1)!, linear dependence on s1 for K=1!
}

# stochastic expectation value of cell number
# for detectable adenoma at age t
ymeanK1 <- function(t,upar,ymin)
{
  alp <- upar[2]
  gam <- upar[3]
  
  ysm <- integrate(minteg_Gg_K1, lower = 0, upper = t, age = t, alp, gam, n = ymin)$value
  denom <- pn_K1.app(t,alp,gam,ymin)
  
  return(ysm/denom) 
}
#-----------------------------------------------------
# K=1, exact
#-----------------------------------------------------
one_minus_axi <- function (s1, age, alpha, gamma)
{
  
  dage <- age - s1
  
  beta <- alpha-gamma
  
  zaehler <- exp(gamma*dage) - 1
  nenner <- alpha*exp(gamma*dage) - beta
  xi <- zaehler/nenner
  
  return (1-alpha*xi)
}

# exact pn from Dewanji et al. 2011
# depends on rho = mu1/alpha
sinteg_pn_K1 <- function(age,alp,gam,rho,ys)
{
  
  ndim <- length(age)
  intpn <- vector()
  intpn <- unlist(lapply(1:ndim, 
                         function(i) {ifelse(ys[i] > 0, integrate(function(s1, j=ys[i]) dnbinom(j,rho,one_minus_axi(s1,age[i],alp,gam)),
                                               lower=0,upper=age[i])$value, 1)})
                  )
  return(intpn)
}

# functions for exact K1
# integrated sum of p_n(s,t)
# interchange of summation and integration
sum_pj <- function(s1,age,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  sumbi <- sum(dnbinom(nind,rho,one_minus_axi(s1,age,alp,gam)))
               
  return (sumbi)
}

intsum_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- integrate(sum_pj, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value

  return (t - P_y0) # integrated p_1^(1)(s1,t)
}

lsum_pj <- function(s1,ages,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  sumbi <- vector()
  sumbi <- unlist(lapply(1:ndim, function(i) sum(dnbinom(nind,rho,one_minus_axi(agei[i],ages,alp,gam)))))
  return (sumbi)
}

lintSum_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- vector()
  ndim <- length(t)
  P_y0 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(lsum_pj, lower = 0, upper = t[i], ages = t[i], alp, gam, rho, ymin[i])$value))
  
  return (t - P_y0) # integrated p_2^(1)(s2,t)
}

# expected number of Adenoma
ENadK1.sum <- function (ages,upar,ymin)
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  nage <- length(ages)
  ENadK1 <- vector()
  ENadK1 <- unlist(lapply(1:nage, function(i) X0*lintSum_pn_K1(ages[i],alp,gam,rho,ymin)))

  return(ENadK1)
}

pnlohi_K1.sum <- function (t,upar,ylo,yhi) 
{
  X0 <- uoar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  ndim <- length(t)
  fhi <- unlist(lapply(1:ndim, function(i) {ifelse(yhi[i] > 0, X0*lintSum_pn_K1(ages[i],alp,gam,rho,yhi[i]))})) # yhi < 0 for highest cat
  flo <- unlist(lapply(1:nage, function(i) X0*lintSum_pn_K1(ages[i],alp,gam,rho,ylo[i])))
  
  {retarg <- ifelse (ylo == 0, 0, flo-fhi)} # p = 0 below detection limit
  
  return(retarg)
}

sum_ydim_K1 <- function(s1,age,alp,gam,rho,dim,ymin,Ninf)
{
  nind <- seq(ymin+1,ymin+1+Ninf,1)
  agei <- s1
  
  ndim <- length(agei)
  sumbi <- unlist(lapply(1:ndim, function(i) sum((nind^(1/dim))*dnbinom(nind,rho,one_minus_axi(agei[i],age,alp,gam)))))
  
  return (sumbi)
}

EsizeK1.sum <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  zaehler <- integrate(sum_ydim_K1, lower = 0, upper = t, age = t, alp,gam,rho,dim,ymin,Ninf)$value
  nenner <- lintSum_pn_K1(t,alp,gam,rho,ymin)
  return(zaehler/nenner)
}

# integration faster as summation!
# needs vectorized age
integrand_ydim_K1 <- function(ys,s1,age,dim,alp,gam,rho)
{
  retarg <- (ys^(1/dim))*dnbinom(ys,rho,one_minus_axi(s1,age,alp,gam))
  return(retarg)
}

integrate_ydim_K1 <- function(s1,age,alp,gam,rho,dim,ymin,Ninf) # s1 is a vector()!
{
  ylo <- ymin+1
  yhi <- ylo + Ninf
  agei <- s1
  ndim <- length(agei)
  
  sumbi.int <- vector()
  sumbi.int <- unlist(lapply(1:ndim, function(i) 
    integrate(integrand_ydim_K1, lower = ylo, upper = Inf, agei[i],age,dim,alp,gam,rho)$value)) # cell size integral
  return (sumbi.int)
}

EsizeK1 <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  zaehler <- integrate(integrate_ydim_K1, lower = 0, upper = t, age = t, alp,gam,rho,dim,ymin,Ninf)$value # age integral
  nenner <- lintSum_pn_K1(t,alp,gam,rho,ymin) # ymin is small
  return(zaehler/nenner)
}

#----------------------------------------------------
# K1, exact with hypergeometric function
#----------------------------------------------------
library(hypergeo) # for hypergeometric function 2F1

integ_one_minus_sum_pj_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  p_ymin <- dnbinom(ymin+1,rho,one_minus_axi(s1,age,alp,gam))
  
  axi <- 1 - one_minus_axi(s1,age,alp,gam)
  hgf <- Re(hypergeo(1, 1+rho+ymin, 2+ymin, axi, tol = 1e-6)) # real part of complex number
  
  return(p_ymin*hgf) # same as 1-sum_pj: to be tested
}

# precision problem with integration?
diff_integ_one_minus_sum_pj_2F1 <- function(s1,age,alp,gam,rho,ylo,yhi)
{
  p_ylo <- dnbinom(ylo+1,rho,one_minus_axi(s1,age,alp,gam))
  p_yhi <- {ifelse(yhi > 0, dnbinom(yhi+1,rho,one_minus_axi(s1,age,alp,gam)),0)}
  
  axi <- 1 - one_minus_axi(s1,age,alp,gam)
  hgf_ylo <- Re(hypergeo(1, 1+rho+ylo, 2+ylo, axi, tol = 1e-6)) # real part of complex number
  hgf_yhi <- {ifelse(yhi > 0, Re(hypergeo(1, 1+rho+yhi, 2+yhi, axi, tol = 1e-6)),0)} # real part of complex number
  
  return(p_ylo*hgf_ylo-p_yhi*hgf_yhi) #
}

int2F1_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  pn_K1 <- integrate(integ_one_minus_sum_pj_2F1, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  return (pn_K1) # integrated 1 - p_1^(1)(s1,t)
}

linteg_one_minus_sum_pj_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  
  one_minus_sumbi <- vector()
  one_minus_sumbi <- unlist(lapply(1:ndim, function(i)
    dnbinom(ymin+1,rho,one_minus_axi(agei[i],age,alp,gam))*Re(hypergeo(1,1+rho+ymin,2+ymin,1-one_minus_axi(agei[i],age,alp,gam), tol = 1e-6))))
  
  return(one_minus_sumbi) # same as 1-sum_pj: to be tested
}

lint2F1_pn_K1 <- function(t,alp,gam,rho,ymin)
{
  pn_K1 <- vector()
  ndim <- length(t)
  pn_K1 <- unlist(lapply(1:ndim, 
                         function(i) 
                           integrate(linteg_one_minus_sum_pj_2F1, lower = 0, upper = t[i], age = t[i], alp, gam, rho, ymin)$value))
  return (pn_K1) # integrated 1 - p_1^(1)(s1,t)
}

lint2F1_pnlohi_K1 <- function(t,alp,gam,rho,ylo,yhi)
{
  ndim <- length(t)
  pnlo_K1 <- vector()
  pnlo_K1 <- unlist(lapply(1:ndim, 
                           function(i) 
                            integrate(linteg_one_minus_sum_pj_2F1, lower = 0, upper = t[i], age = t[i], alp, gam, rho, ylo[i])$value))
  pnhi_K1 <- vector()
  pnhi_K1 <- unlist(lapply(1:ndim, 
                           function(i) {ifelse(yhi[i] > 0,
                             integrate(linteg_one_minus_sum_pj_2F1, lower = 0, upper = t[i], age = t[i], alp, gam, rho, yhi[i])$value, 0)})
                           )
  return (pnlo_K1-pnhi_K1) 
}

# expected number of Adenoma
ENadK1.hyp <- function (ages,upar,ymin)
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  nage <- length(ages)
  ENadK1 <- vector()
  ENadK1 <- unlist(lapply(1:nage, function(i) X0*lint2F1_pn_K1(ages[i],alp,gam,rho,ymin)))
  #ENadK1 <-  X0*lintsum_pn_K1(ages,alp,gam,rho,ymin)
  return(ENadK1)
}

# wrapper
theta_lohi_K1.hyp <- function (t,upar,ylo,yhi) 
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  retarg <- X0*lint2F1_pnlohi_K1 (t,alp,gam,rho,ylo,yhi)
  
  {retarg <- ifelse (ylo == 0, 0, retarg)} # p = 0 below detection limit
  
  return(retarg)
  
  return()
}

EsizeK1.hyp <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  zaehler <- integrate(sum_ydim_K1, lower = 0, upper = t, age = t, alp,gam,rho,dim,ymin,Ninf)$value # like K1.sum
  nenner <- lint2F1_pn_K1(t,alp,gam,rho,ymin)
  return(zaehler/nenner)
}

#----------------------------------------------------------------------
# K=2, approximation of one subclone
#----------------------------------------------------------------------

# approximation of one subclone
# multiply by s1
sinteg_pn_K2 <- function(age,alp,gam,rho,ys)
{
  
  ndim <- length(age)
  intpn <- vector()
  # multiply by s1: one subclone approximation
  intpn <- unlist(lapply(1:ndim, 
                         function(i) {ifelse(ys[i] > 0, integrate(function(s1, j=ys[i]) s1*dnbinom(j,rho,one_minus_axi(s1,age[i],alp,gam)),
                                                                  lower=0,upper=age[i])$value, 1)})
                  )
  return(intpn)
}

# integrated sum of p_n(s,t)
# interchange of summation and integration
sum_pj_age <- function(s1,age,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  sumbi <- sum(s1*dnbinom(nind,rho,one_minus_axi(s1,age,alp,gam))) # multiply by s1: one subclone approximation
  
  return (sumbi)
}

lsum_pj_age <- function(s1,ages,alp,gam,rho,ymin)
{
  nind <- seq(0,ymin,1)
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  sumbi <- vector()
  sumbi <- unlist(lapply(1:ndim, function(i) sum(agei[i]*dnbinom(nind,rho,one_minus_axi(agei[i],ages,alp,gam)))))
  return (sumbi)
}

intSum_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- integrate(lsum_pj_age, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  retarg <- ((t^2)/2 - P_y0)
  return (retarg) # integrated p_1^(1)(s1,t)
}

lintSum_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- vector()
  ndim <- length(t)
  P_y0 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(lsum_pj_age, lower = 0, upper = t[i], ages = t[i], alp, gam, rho, ymin)$value))
  retarg <- ((t^2)/2 - P_y0)
  return (retarg) # integrated p_2^(1)(s2,t)
}

# expected number of Adenoma
ENadK2.sum <- function (ages,upar,ymin)
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  nage <- length(ages)
  ENadK2 <- vector()
  ENadK2 <- unlist(lapply(1:nage, function(i) X0*lintSum_pn_K2(ages[i],alp,gam,rho,ymin)))
  #ENadK1 <-  X0*lintsum_pn_K1(ages,alp,gam,rho,ymin)
  return(ENadK2)
}

#pnlohi_K2.sum <- function (t,upar,ylo,yhi) 
#{
#  X0 <- upar[1]
#  alp <- upar[2]
#  gam <- upar[3]
#  rho <- upar[4]
  
#  ndim <- length(t)
#  fhi <- unlist(lapply(1:ndim, function(i) {ifelse(yhi[i] > 0, X0*lintsum_pn_K2(t[i],alp,gam,rho,yhi[i]))})) # yhi < 0 for highest cat
#  flo <- unlist(lapply(1:ndim, function(i) X0*lintsum_pn_K2(t[i],alp,gam,rho,ylo[i])))
#  return(flo-fhi)
#}

theta_lohi_K2.sum <- function (t,upar,ylo,yhi) 
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  ndim <- length(t)
  fhi <- unlist(lapply(1:ndim, function(i) {ifelse(yhi[i] < 0, 0, X0*lintSum_pn_K2(t[i],alp,gam,rho,yhi[i]))})) # yhi < 0 for highest cat
  flo <- unlist(lapply(1:ndim, function(i) X0*lintSum_pn_K2(t[i],alp,gam,rho,ylo[i])))
  
  {retarg <- ifelse (ylo == 0, 0, flo-fhi)} # p = 0 below detection limit
  
  return(retarg)
}

sum_ydim_K2 <- function(s1,age,alp,gam,rho,dim,ymin,Ninf)
{
  nind <- seq(ymin+1,ymin+1+Ninf,1)
  agei <- s1
  
  ndim <- length(agei)
  sumbi <- unlist(lapply(1:ndim, function(i) sum((nind^(1/dim))*agei[i]*dnbinom(nind,rho,one_minus_axi(agei[i],age,alp,gam)))))

  return (sumbi)
}

EsizeK2.sum <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  zaehler <- integrate(sum_ydim_K2, lower = 0, upper = t, age = t, alp,gam,rho,dim,ymin,Ninf)$value
  nenner <- lintSum_pn_K2(t,alp,gam,rho,ymin)
  return(zaehler/nenner)
}

# integration faster as summation!
# needs vectorized age
integrand_ydim_K2 <- function(ys,s1,age,dim,alp,gam,rho)
{
  retarg <- (ys^(1/dim))*s1*dnbinom(ys,rho,one_minus_axi(s1,age,alp,gam))
  return(retarg)
}

integrate_ydim_K2 <- function(s1,age,alp,gam,rho,dim,ymin,Ninf) # s1 is a vector()!
{
  ylo <- ymin+1
  yhi <- ylo + Ninf
  agei <- s1
  ndim <- length(agei)
  
  sumbi.int <- vector()
  sumbi.int <- unlist(lapply(1:ndim, function(i) 
    integrate(integrand_ydim_K2, lower = ylo, upper = Inf, agei[i],age,dim,alp,gam,rho)$value)) # cell size integral
  return (sumbi.int)
}

EsizeK2 <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  zaehler <- integrate(integrate_ydim_K2, lower = 0, upper = t, age = t, alp,gam,rho,dim,ymin,Ninf)$value # age integral
  nenner <- lintSum_pn_K2(t,alp,gam,rho,ymin)
  return(zaehler/nenner)
}


#--------------------------------------------------------------
# K2.app with hypergeometric function
#--------------------------------------------------------------
integ_one_minus_sum_pj_age_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  p_ymin <- dnbinom(ymin+1,rho,one_minus_axi(s1,age,alp,gam))
  
  axi <- 1 - one_minus_axi(s1,age,alp,gam)
  hgf <- Re(hypergeo(1, 1+rho+ymin, 2+ymin, axi))
  return(s1*p_ymin*hgf) # multiply by s1: one subclone approximation
}

int2F1_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  pn_K2 <- integrate(integ_one_minus_sum_pj_age_2F1, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  return (pn_K2) # integrated s*(1 - p_1^(1)(s1,t))
}

# expected number of Adenoma
ENadK2.hyp <- function (ages,upar,ymin)
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  nage <- length(ages)
  vymin <- rep(ymin,nage)
  ENadK2 <- vector()
  ENadK2 <- unlist(lapply(1:nage, function(i) X0*int2F1_pn_K2(ages[i],alp,gam,rho,vymin[i])))
  #ENadK1 <-  X0*lintsum_pn_K1(ages,alp,gam,rho,ymin)
  return(ENadK2)
}

theta_lohi_K2.hyp <- function (t,upar,ylo,yhi) 
{
  X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  ndim <- length(t)
  fhi <- unlist(lapply(1:ndim, function(i) {ifelse(yhi[i] < 0, 0, X0*int2F1_pn_K2(t[i],alp,gam,rho,yhi[i]))})) # yhi < 0 for highest cat
  flo <- unlist(lapply(1:ndim, function(i) X0*int2F1_pn_K2(t[i],alp,gam,rho,ylo[i])))
  
  {retarg <- ifelse (ylo == 0, 0, flo-fhi)} # p = 0 below detection limit
  
  return(retarg)
}

EsizeK2.hyp <- function(t,upar,dim,ymin,Ninf)
{
  #X0 <- upar[1]
  alp <- upar[2]
  gam <- upar[3]
  rho <- upar[4]
  
  zaehler <- integrate(sum_ydim_K2, lower = 0, upper = t, age = t, alp,gam,rho,dim,ymin,Ninf)$value
  nenner <- int2F1_pn_K2(t,alp,gam,rho,ymin)
  return(zaehler/nenner)
}
