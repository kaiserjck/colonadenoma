#------------------------------------------------------------------------------
# directory structure
#------------------------------------------------------------------------------

# subdirectories
statdir <- paste(dir, "/stats", sep = "")
datdir <- paste(statdir,"/data", sep = "")
curvdir <- paste(statdir,"/curves",sep = "")
plotdir <- paste(statdir,"/plots",sep = "")
tmpdir <- paste(statdir,"tmp",sep = "/")
pardir <- paste(statdir, "/parms", sep = "") # fresh fit results
spardir <- paste(statdir, "/bparms", sep = "") # best fit results
stdpardir <- paste(statdir, "/bparms/std", sep = "") # best fit results: std
atrendpardir <- paste(statdir, "/bparms/atrend", sep = "") # best fit results: atrend
gstdpardir <- paste(statdir, "/bparms-grid/std", sep = "") # fit results from grid: std
gatrendpardir <- paste(statdir, "/bparms-grid/atrend", sep = "") # fit results from grid: atrend
patrendpardir <- paste(statdir, "/pparms-grid/atrend", sep = "") # fit results from grid: atrend
pstdpardir <- paste(statdir, "/pparms-grid/std", sep = "") # fit results from grid: atrend
resdir <- paste(statdir, "/results", sep = "")
subdir <- paste(statdir, "/subscripts", sep = "")
#figdir <- paste(dir, "/writeup/figures", sep = "")
