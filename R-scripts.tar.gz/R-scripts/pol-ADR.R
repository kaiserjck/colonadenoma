#----------------------------------------------
# adeno: data set with negative screening results
# check age and sex dependence
# based on adenoma prevalence
# jck, 2022/04/06
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects 

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma" # project root directory
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
statdir 
datdir 

#----------------------------------------------------------
# prepare screening data
#----------------------------------------------------------
setwd("~/imodel/colonlmu/data_lmu/adenoma/")
load("adeno-ADR-complete.Rdata")

dim(adeno)
# 258116     19
table(adeno$dad) # DIAGNOSEADENOMA
#     no    yes 
# 191884  66232 
names(adeno)
#[1] "patid"           "postcode"        "sex"             "byr"             "byrcat"          "age"             "agecat"         
#[8] "pscat"           "EXAMINATIONDATE" "QUARTAL"         "dad"             "lok"             "polypcount"      "polypsize"      
#[15] "polypshape"      "adenomhist"      "histkarzinom"    "adv_adenoma"     "adv_npl" 

str(adeno)
summary(adeno)

# no cancers in 2009
table(adeno$histkarzinom,adeno$QUARTAL)

mean(adeno$age[adeno$histkarzinom == 1 & adeno$QUARTAL < 20091]) # 68.35644
#adeno <- adeno[adeno$QUARTAL < 20091,]
length(adeno$dad[adeno$dad == "yes"]) # 66232
sum(adeno$histkarzinom) # 1919
table(adeno$histkarzinom)
#      0      1 
# 256197   1919 

# remove carcinoma
adeno <- adeno[adeno$histkarzinom < 1,]
dim(adeno) # 256197     19
table(adeno$dad)
#     no    yes 
# 190436  65761

table(adeno$adenomhist[adeno$dad == "yes"],useNA = "always")
# tubular tubulovillous       villous     dysplasia          <NA> 
#   53206          8953           688          1587          1327  
table(adeno$polypcount[adeno$dad == "yes"],useNA = "always")
#      1   2-4   >=5  <NA> 
#  31414 28773  5208   366 
table(adeno$polypsize[adeno$dad == "yes"],useNA = "always")
#   0.25  0.75   1.5     2   2.5     4  <NA> 
#  28827 23024  7592  2539  2987   418   374 
table(adeno$polypshape[adeno$dad == "yes"],useNA = "always")
#  flat    sessile peduncular       <NA> 
#  7482      47061      10839        379 
table(adeno$lok[adeno$dad == "yes"],useNA = "always")
#distal     both proximal     <NA> 
#  18306    20087    13139    14229 

help1 <- split(adeno,adeno$dad)

acc.org <- help1[[2]] # with adenoma
# complete cases for adenoma
acc <- acc.org[complete.cases(acc.org[ , c("adenomhist","polypcount","polypsize","polypshape","lok")]),]
dim(acc) # 50649    19
dim(subset(acc,complete == 1)) # 50649    19
dim(acc.org)[1]- dim(acc)[1] # 15112 records with incomplete information removed
round(dim(acc)[1]/dim(acc.org)[1]*100,1)  # 77.0% remain
table(acc$dad,useNA="always")
# no   yes  <NA> 
#  0 50649     0 

# calculate reduction factor for age and sex
# limit to maximal age
noad <- help1[[1]] # no adenoma
table(noad$dad,useNA="always")
a.o <- subset(acc.org, age < 93)
a.r <- subset(acc, age < 93)
n.o <- subset(noad, age < 93)
a.o$npat <- 1
a.o <- aggregate(a.o$npat,list(a.o$sex,a.o$age), sum)
a.r$npat <- 1
a.r <- aggregate(a.r$npat,list(a.r$sex,a.r$age), sum)
n.o$npat <- 1
n.o <- aggregate(n.o$npat,list(n.o$sex,n.o$age), sum)
# data frame with with reduced number of patients without adenoma
n.r <- n.o
n.r$x <- as.integer(a.r$x/a.o$x*n.o$x+.5)

# concatenate location
table(acc$lok)
acc$lok2 <- "proximal"
acc$lok2[acc$lok == "both"] <- "distboth"
acc$lok2[acc$lok == "distal"] <- "distboth"
acc$lok2 <- as.factor(acc$lok2)
#acc$lok2 <- factor(acc$lok2, levels = c(1:2), labels = c("proximal","distboth"))
table(acc$lok,acc$lok2)



#----------------------------------------------------------
# generate grouped patient data with adenoma
#----------------------------------------------------------
# add column with number of patients
acc$npat <- 1

acc.r <- aggregate(acc$npat,list(acc$sex,
                                  acc$age,
                                  acc$agecat,
                                  #acc$polypshape,
                                  #acc$lok2,
                                  #acc$accmhist,
                                  acc$polypcount,
                                  acc$pscat), sum)
headline <- c("sex","age","agecat","countcat","sizecat","npat")
names(acc.r) <- headline

dim(acc.r)
str(acc.r)
summary(acc.r)

noad$npat <- 1
noad.o <- aggregate(noad$npat,list(noad$sex,noad$age,noad$agecat), sum)
noad.r <- data.frame(noad.o$Group.1,noad.o$Group.2,noad.o$Group.3,"0","<DL",noad.o$x)
names(noad.r) <- headline

# replace with reduced number of patients
noad.r$npat[1:76] <- n.r$x # leave age counts >= 93
round(sum(noad.r$npat)/sum(noad.o$x)*100.1) # 77.0%
round(dim(acc)[1]/dim(acc.org)[1]*100,1)  # 77.0% remain

dim(noad.r)
str(noad.r)
summary(noad.r)

adpg <- rbind(acc.r,noad.r)

dim(adpg)
str(adpg)
summary(adpg)

sum(adpg$npat[adpg$sex == "m"]) # 88300
sum(adpg$npat[adpg$sex == "w"]) # 109047

adpg$pno <- NA
adpg$pno[adpg$countcat == "0"] <- 0
adpg$pno[adpg$countcat == "1"] <- 1
adpg$pno[adpg$countcat == "2-4"] <- 2 # most probable number
adpg$pno[adpg$countcat == ">=5"] <- 5 # most probable number
table(adpg$pno,useNA="always")

sizemin <-  exp((log(0.25)+log(0.5))/2)
adpg$size <- NA
adpg$size[adpg$sizecat == "<DL"] <- 0
adpg$size[adpg$sizecat == "<0.5"] <- sizemin
adpg$size[adpg$sizecat == "0.5-1"] <- sizemin*2
adpg$size[adpg$sizecat == "1-2"] <- sizemin*4
adpg$size[adpg$sizecat == ">2"] <- sizemin*8
table(adpg$size,useNA="always")

#----------------------------------------------------------
# cell size assignment
#----------------------------------------------------------
ymin <- 50
adpg$ymin <- ymin # physical DL

none <- subset(adpg, sizecat == "<DL")
none$ylo2d <- 0
#none$ys2d <- 0
none$yhi2d <- 0
none$ylo3d <- 0
#none$ys3d <- 0
none$yhi3d <- 0


sefl <- subset(adpg, sizecat != "<DL")

#sefl$ys2d <- 0
#sefl$ys2d[sefl$sizecat == "<0.5"] <- 100
#sefl$ys2d[sefl$sizecat == "0.5-1"] <- 400
#sefl$ys2d[sefl$sizecat == "1-2"] <- 1600
#sefl$ys2d[sefl$sizecat == ">2"] <- 6400

sefl$ylo2d <- 0
sefl$ylo2d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo2d[sefl$sizecat == "0.5-1"] <- 200
sefl$ylo2d[sefl$sizecat == "1-2"] <- 800
sefl$ylo2d[sefl$sizecat == ">2"] <- 3200

sefl$yhi2d <- 0
sefl$yhi2d[sefl$sizecat == "<0.5"] <- 200
sefl$yhi2d[sefl$sizecat == "0.5-1"] <- 800
sefl$yhi2d[sefl$sizecat == "1-2"] <- 3200
sefl$yhi2d[sefl$sizecat == ">2"] <- -1

#sefl$ys3d <- 0
#sefl$ys3d[sefl$sizecat == "<0.5"] <- 141
#sefl$ys3d[sefl$sizecat == "0.5-1"] <- 1131
#sefl$ys3d[sefl$sizecat == "1-2"] <- 9051
#sefl$ys3d[sefl$sizecat == ">2"] <- 72408

sefl$ylo3d <- 0
sefl$ylo3d[sefl$sizecat == "<0.5"] <- ymin
sefl$ylo3d[sefl$sizecat == "0.5-1"] <- 400
sefl$ylo3d[sefl$sizecat == "1-2"] <- 3200
sefl$ylo3d[sefl$sizecat == ">2"] <- 25600

sefl$yhi3d <- 0
sefl$yhi3d[sefl$sizecat == "<0.5"] <- 400
sefl$yhi3d[sefl$sizecat == "0.5-1"] <- 3200
sefl$yhi3d[sefl$sizecat == "1-2"] <- 25600
sefl$yhi3d[sefl$sizecat == ">2"] <- -1

#--------------------------------------------------------
# check shares
#--------------------------------------------------------
ef <- rbind(sefl,none)

# DIAGNOSEADENOMA
ef$dad <- "yes"
ef$dad[ef$sizecat == "<DL"] <- "no"
ef$dad <- as.factor(ef$dad)

# control for likelihood
ef$shape <- "all"
ef$shape[ef$sizecat == "<DL"] <- "none"
ef$shape <- as.factor(ef$shape)

dim(ef)
str(ef)
summary(ef)

mADW <- sum(aggregate(ef$npat[ef$sizecat != "<DL"],list(ef$sex[ef$sizecat != "<DL"]),sum)$x[1])
mN0W <- sum(aggregate(ef$npat[ef$sizecat == "<DL"],list(ef$sex[ef$sizecat == "<DL"]),sum)$x[1])
mADM <- sum(aggregate(ef$npat[ef$sizecat != "<DL"],list(ef$sex[ef$sizecat != "<DL"]),sum)$x[2])
mN0M <- sum(aggregate(ef$npat[ef$sizecat == "<DL"],list(ef$sex[ef$sizecat == "<DL"]),sum)$x[2])

round(mADW/(mADW+mN0W),3) # 0.203
round(mN0W/(mADW+mN0W),3) # 0.797
round(mADM/(mADM+mN0M),3) # 0.324
round(mN0M/(mADM+mN0M),3) # 0.676
round((mADM+mADW)/(mADM+mN0M+mADW+mN0W),3) # 0.257
round((mN0M+mN0W)/(mADM+mN0M+mADW+mN0W),3) # 0.743

#-----------------------------------------------------
# write data files into project directory
#----------------------------------------------------
setwd(datdir)
names(ef)
adenoPG <- ef
#save(adenoPG, file = "adenoPG-20220408.Rdata")
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------
library(ggplot2)
library(scales)
library(cowplot)

pf <- adenoPG
summary(pf)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
#myPalette <- c(cbbPalette[2],cbbPalette[6])
myPalette <- c(cbPalette[1],cbbPalette[1])

# New facet label names for sex variable
sex.labs <- c("women", "men")
names(sex.labs) <- c("w", "m")

pf.ss <- aggregate(pf$npat,list(pf$dad,pf$agecat,pf$sex),sum)
names(pf.ss) <- c("dad","agecat","sex","npat")
fp.1 <- ggplot() + 
  #ggtitle("Age & sex specific patient numbers, 2022/04/08") + 
  geom_bar(data = pf.ss, aes(x=agecat, y=npat, fill=dad), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = surv, aes(x=agecat, y=npat,fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(name = "Adenoma", values = myPalette) +
  facet_grid(sex ~ ., labeller = labeller(sex = sex.labs)) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  scale_y_log10(name="No. of patients", labels=trans_format('log10', math_format(10^.x))) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15)) 
#  + theme_bw()  # use a white background
print(fp.1)

#-----------------------------------------
# reproduce imposed prevalence and plot
#-----------------------------------------

pf.prev <- aggregate(pf$npat,list(pf$sex,pf$dad,pf$agecat),sum)
names(pf.prev) <- c("Sex","Adenoma","agecat","npat")
help1 <- split(pf.prev,pf.prev$Sex)
pf.w <- help1[[1]]
pf.m <- help1[[2]]
sum(pf.w$npat)
sum(pf.m$npat)

pf.ac.m <- aggregate(pf.m$npat,list(pf.m$agecat),sum)
pf.ac.w <- aggregate(pf.w$npat,list(pf.w$agecat),sum)

help2.m <- split(pf.m,pf.m$agecat)
help2.w <- split(pf.w,pf.w$agecat)

for(i in 1:7){
  help2.m[[i]]$nagrp <- pf.ac.m$x[i] 
  help2.w[[i]]$nagrp <- pf.ac.w$x[i] 
}

pf.p.m <- help2.m[[1]]
pf.p.w <- help2.w[[1]]
for(i in 2:7){
  pf.p.m <- rbind(pf.p.m,help2.m[[i]])
  pf.p.w <- rbind(pf.p.w,help2.w[[i]])
}
pf.p <- rbind(pf.p.m,pf.p.w)
pf.p$ppat <- pf.p$npat/pf.p$nagrp
#pf.p$ppat[pf.p$Adenoma == "no"] <- 1 - pf.p$ppat[pf.p$Adenoma == "no"]
#levels(pf.p$Shape)[4] <- "all"
pf.p

fp.2 <- ggplot() + 
  #ggtitle("Age & sex specific prevalence, 2022/05/18") + 
  geom_bar(data = pf.p, aes(x=agecat, y = 100*ppat, fill=Adenoma), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = surv, aes(x=agecat, y=npat,fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(Sex ~ ., labeller = labeller(Sex = sex.labs)) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  scale_y_continuous(name="Share (%)", limits=c(0,100), breaks = seq(0,100,20)) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Share (%)", labels = scales::percent, limits=c(0,1), breaks = seq(0,1,0.2)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15)) 
#  + theme_bw()  # use a white background
print(fp.2)

#--------------------------------------------------------
# cowplot
#--------------------------------------------------------
plot_grid(fp.1, fp.2, labels = "AUTO", ncol=1)

#--------------------------------------------------------
# all-in-one
#--------------------------------------------------------

headline <- c("quant","Sex","agecat","Adenoma","value")
names(pf.ss)
#pf.pat <- data.frame("Npat",pf$sex,pf$agecat,pf$dad,pf$npat)
pf.pat <- data.frame("Npat",pf.ss$sex,pf.ss$agecat,pf.ss$dad,log10(pf.ss$npat))
names(pf.pat) <- headline
names(pf.p)
pf.adr <- data.frame("Share",pf.p$Sex,pf.p$agecat,pf.p$Adenoma,pf.p$ppat*100)
names(pf.adr) <- headline

pf.ps <- rbind(pf.pat,pf.adr)
str(pf.ps)

quant.labs <- c("No. of patients (log10)", "Share (%)")
names(quant.labs) <- c("Npat", "Share")

#pf.pa$quant <- fct_rev(pf.pa$quant)

fp.3 <- ggplot() + 
  #ggtitle("Age & sex specific prevalence, 2022/05/18") + 
  geom_bar(data = pf.ps, aes(x=agecat, y = value, fill=Adenoma), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = pf.pa, aes(x=agecat, y=value,fill=Shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(quant ~ Sex, labeller = labeller(Sex = sex.labs, quant = quant.labs), scales = "free_y") + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  #scale_y_continuous(name="Adenoma detection rate (%)", limits=c(0,30), breaks = seq(0,30,10)) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Share (%)", labels = scales::percent, limits=c(0,1), breaks = seq(0,1,0.2)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=15),
        axis.title.y=element_blank(),
        legend.position = c(0.9,0.92)) 
#  + theme_bw()  # use a white background
print(fp.3)



