#----------------------------------------------
# adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/gsf/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#----------------------------------------------------------
# select adenoma data 
#----------------------------------------------------------
shp <- character()
#shp <- "all"
shp <- "flat"
#shp <- "sessile"
#shp <- "peduncular"

noad <- character()
#noad <- "wN0"
noad <- "noN0"

patdata <- character()
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20220408.Rdata")
    df0 <- adenoPG
    patdata <- "adenoPG-20220408.Rdata"} 
  else if (shp == "sessile") {
    load(file = "sessPG-20220527.Rdata")
    df0 <- sess
    patdata <- "sessPG-20220527.Rdata"}
  else if (shp == "flat") {
    load(file = "flatPG-20220527.Rdata")
    df0 <- flat
    patdata <- "flatPG-20220527.Rdata"}
  else if (shp == "peduncular") {
    load(file = "peduPG-20220527.Rdata")
    df0 <- pedu
    df0$ymin <- 40
    patdata <- "peduPG-20220527.Rdata"}
  #else if (shp == "peduncular") {
  #  load(file = "peduPG-20211103.Rdata")
  #  levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
  #  pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
  #  df0 <- pedu
  #  patdata <- "peduPG-20211103.Rdata"}
}

sexc <- character()
#sexc <- "both"
sexc <- "m"
#sexc <- "w"

dims <- character()
#dims <- "2d"
dims <- "3d"

mmname <- character()
#mmname <- "K1"
mmname <- "K2"

meth <- character()
#meth <- "sum" # summation
meth <- "hyp" # hypergeometric function

# likelihood
likc <- character()
#likc <- "posize"
likc <- "permut"

mdv <- character()
mdv <- "atrend"
#mdv <- "std"

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
#fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,mdv,sep="-") 

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  if (dims == "2d") {
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
#ymin <- unique(df$ylo[df$sizecat == "<0.5"])
#df$ymin <- ymin
df <- droplevels(df)

# calculate df$npat_age
ad <- df

#npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum, drop=FALSE)
npat_size_age <- aggregate(ad$npat, list(ad$agecat,ad$sizecat), sum)
#npat_size_age <- aggregate(ad$npat, list(factor(ad$age),ad$sizecat), sum)
#npat_size_age$x[is.na(npat_size_age$x) == T] <- 0
age_sum <- aggregate(ad$npat*ad$age, list(ad$agecat,ad$sizecat), sum)
#age_sum <- aggregate(ad$npat*ad$age, list(factor(ad$age),ad$sizecat), sum)
age_mean <- age_sum$x/npat_size_age$x
ylo_uni <- aggregate(ad$ylo, list(ad$agecat,ad$sizecat), unique)
yhi_uni <- aggregate(ad$yhi, list(ad$agecat,ad$sizecat), unique)
ymin_uni <- aggregate(ad$ymin, list(ad$agecat,ad$sizecat), unique)
#ylo_uni <- aggregate(ad$ylo, list(factor(ad$age),ad$sizecat), unique)
#yhi_uni <- aggregate(ad$yhi, list(factor(ad$age),ad$sizecat), unique)
#ymin_uni <- aggregate(ad$ymin, list(factor(ad$age),ad$sizecat), unique)

df.h <- data.frame(shp,sexc,dims,age_mean,(age_mean-65)/10,npat_size_age,ylo_uni$x,yhi_uni$x,ymin_uni$x)

npat_age <- aggregate(ad$npat, list(ad$agecat), sum)
#npat_age <- aggregate(ad$npat, list(factor(ad$age)), sum)
help1 <- split(df.h, df.h$Group.1)
nlevels <- length(levels(df.h$Group.1))
for(i in 1:nlevels){
  help1[[i]]$npat_age <- npat_age$x[i]
}
df.r <- help1[[1]]
for (i in 2:nlevels){
  df.r <- rbind(df.r,help1[[i]])
}
#df.r <- data.frame(df.h)
dim(df.r)
names(df.r) <- c("shp","sex","dims","age","acen","agecat","sizecat","npat","ylo","yhi","ymin","npat_age")
aggregate(df.r$npat,list(df.r$agecat),sum)
unique(df.r$npat_age)
#df <- df.r

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(ad)[1]))
cat(sprintf("   All Npat: %d\n", sum(ad$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(ad$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "atrend" & likc == "posize"){thispardir <- patrendpardir}
  else if (mdv == "std" & likc == "posize"){thispardir <- pstdpardir}
  else if (mdv == "atrend" & likc == "permut"){thispardir <- atrendpardir}
  else if (mdv == "std" & likc == "permut"){thispardir <- stdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")
#exit <- file.exists("peduncular-all-distboth-m-K0-agAS2_parms.csv")
#ifelse(exit == T, mat <- read.csv(file = fname), "no")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

upar <- vector()
upar <- dpar$parval

#if(mdv == "std"){
#  npar <- length(upar)
#  upar[npar+1] <- 0
#}
upar
#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
{
  if (likc == "posize"){
    source("pAdenoK0K1K2atrend-posize-size.R")
    
  }
  else if(likc == "permut"){
    source("pAdenoK0K1K2atrend-permut.R")
    
  }
}

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
      Esize <- ymeanK0
  }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
    Esize <- ymeanK1
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.hyp
    Thelohi <- theta_lohi_K1.hyp
    Esize <- EsizeK1
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.sum
    Thelohi <- theta_lohi_K2.sum
    Esize <- EsizeK2.sum
  }
  else
  {
    print("Not implemented\n")
  }
}

#-------------------------------------------------------
# service functions for determination of percentiles
#-------------------------------------------------------
yperc <- function(ysize,ageref,upar,ymin,perc)
{
  lbd <- ENad(ageref,upar,ymin) 
  cumP <- Thelohi(ageref,upar,ymin,ysize)/lbd
  return(perc - cumP)
}

# median
ymedian <- function(age,upar,ymin,ymax)
{
  perc <- 0.5 # median
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = TRUE)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

# 2.5%-tile
y025 <- function(age,upar,ymin,ymax)
{
  perc <- 0.025 # 2.5%
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = TRUE)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

# 97.5%-tile
y975 <- function(age,upar,ymin,ymax)
{
  perc <- 0.975 # 97.5%
  ndim <- length(age)
  ymed <- vector()
  
  e <- try (d <- uniroot(function(ysize) yperc(ysize,age,upar,ymin,perc), interval = c(ymin+1,ymax)), silent = F)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

# 97.5%-tile
logy975 <- function(age,upar,ymin,ymax)
{
  perc <- 0.975 # 97.5%
  ndim <- length(age)
  ymed <- vector()
  
  e <- try (d <- uniroot(function(ysize) log(yperc(ysize,age,upar,ymin,perc)), interval = c(ymin+1,ymax)), silent = F)
  if (class(e) == "try-error") { 
    ymed <- ymin-0.25 
  } else { 
    ymed <- d$root	
  } 
  
  return(ymed)
}

#--------------------------------
# model predictions
#--------------------------------

#ageref <- 85
#nInf = 200000
#delY <- nInf/10

# model predictions
# expectation value
#lbd <- ENad(ageref,upar,gb.ymin) 
#ymeanK1(ageref,upar,gb.ymin)

# cumulative probabilities
# model prediction
#yvec <- seq(gb.ymin,gb.ymin+nInf,delY)
#range(yvec)
#pdim <- length(yvec)
#PScat <- unlist(lapply(1:pdim, function(i) Thelohi(ageref,upar,gb.ymin,yvec[i])/lbd))
#plot(yvec,PScat)

#y.mn <- EsizeK2.sum(ageref,upar,1,gb.ymin,gb.ymin+10*nInf)
#y.mn <- ymeanK1(ageref,upar,gb.ymin)
#y.md <- ymedian(ageref,upar,gb.ymin,gb.ymin+nInf)
#y.lo <- y025(ageref,upar,gb.ymin,gb.ymin+nInf)
#y.hi <- y975(ageref,upar,gb.ymin,gb.ymin+10*nInf)

#y.mn
#Size1cm*EsizeK1.app.sum(ageref,upar,gdim,gb.ymin,gb.ymin+10*nInf)
#cat(sprintf("Cells lo, md, hi: %d, %d, %d\n", as.integer(y.lo+.5), as.integer(y.md+.5), as.integer(y.hi+.5)))
#cat(sprintf("Size  lo, md, hi: %f, %f, %f\n", Size1cm*y.lo^(1/gdim), Size1cm*y.md^(1/gdim), Size1cm*y.hi^(1/gdim)))
#-----------------------------------------
# build plot frame
#-----------------------------------------
{
  if (sexc == "w") {sexcc = "women"}
  else if (sexc == "m") {sexcc = "men"}
}

ages <- seq(20,90,1)
ndim <- length(ages)
y.md <- unlist(lapply(1:ndim, function(i) ymedian(ages[i],upar,gb.ymin,2000)))
#y.025 <- unlist(lapply(1:ndim, function(i) y025(ages[i],upar,gb.ymin,y.md[i])))

#y.975 <- vector()
#y.975[1] <- y975(ages[1],upar,y.md[1],y.md[1]+1000)
#for (i in 21:(ndim-40)){
# y.975[i] <- y975(ages[i],upar, y.975[i-1],1.2*y.975[i-1])
#  cat(sprintf("age %g of ageend %g completed: y.975 = %g\n", ages[i],ages[ndim], y.975[i]))
#}
#y.975 <- unlist(lapply(1:1, function(i) y975(ages[i],upar,1000,15000)))
#y.sav <- y.975

#headline <- c("Shape","Sex","Dim","age","y.md","y.025","y.975")
#mdf <- data.frame(shp,sexcc,gdim,ages,y.md,y.025,y.975)
headline <- c("Shape","Sex","Dim","age","y.md")
mdf <- data.frame(shp,sexcc,dims,ages,y.md)
names(mdf) <- headline
head(mdf)

# plot file saving
fname
ffname <- paste("mdcell",fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(curvdir)
save(mdf, file = fsavname)
