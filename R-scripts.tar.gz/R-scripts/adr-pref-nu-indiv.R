#----------------------------------------------
# adeno ADR analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#library(ggplot2)
library(matrixcalc) # for testing if hessian is positive definite
library(MASS)
library(Formula)
#library(corrplot)
# library for function "lerch"
library(VGAM)

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

#-------------------------------------------
# directory structure
#-------------------------------------------

shp <- character()
#shp <- "all"
#shp <- "flat"
#shp <- "sessile"
shp <- "peduncular"

noad <- character()
noad <- "wN0"
#noad <- "noN0"

loca <- character()
loca <- "all"

sexc <- character()
sexc <- "m"
#sexc <- "w"

dims <- character()
dims <- "2d"
#dims <- "3d"

mmname <- character()
#mmname <- "K0"
#mmname <- "K1app"
mmname <- "K1"
#mmname <- "K2"

# likelihood
likc <- character()
#likc <- "sing"
#likc <- "unif"
likc <- "dist"
#likc <- "bina"

# model version
mdv <- character()
#mdv <- "grid" # grid models
mdv <- "pref" # preferred models with adjusted detection limits

# model version
atr <- character()
atr <- "atrend" # age trend
#atr <- "std" # standard

fname <- shp
#fname <- paste(fname,"-",noad,sep="")
#fname <- paste(fname,"-",histo,sep="")
fname <- paste(fname,"-",loca,sep="")
fname <- paste(fname,"-",sexc,sep="")
fname <- paste(fname,"-",dims,sep="")
fname <- paste(fname,"-",mmname,sep="")
fname <- paste(fname,"-",likc,sep="")
fname <- paste(fname,atr,sep="-")

#-------------------------------------------------------------
# prepare observed data
#-------------------------------------------------------------
setwd(datdir)
{
  if (shp == "all") {
    load(file = "adenoPG-20210915.Rdata")
    df0 <- sadenoPG} 
  else if (shp == "sessile") {
    load(file = "sessPG-20210915.Rdata")
    df0 <- sess}
  else if (shp == "flat") {
    load(file = "flatPG-20210915.Rdata")
    df0 <- flat}
  else if (shp == "peduncular" & mdv == "grid") {
    load(file = "peduPG-20210915.Rdata")
    df0 <- pedu
    patdata <- "peduPG-20210915.Rdata"}
  else if (shp == "peduncular" & mdv == "pref") {
    load(file = "peduPG-20211103.Rdata")
    levels(pedu$sizecat)[levels(pedu$sizecat)=="<1"] <- "0.5-1" # all other code uses "0.5-1"
    pedu$sizecat <- relevel(pedu$sizecat,"0.5-1")
    df0 <- pedu
    patdata <- "peduPG-20211103.Rdata"}
}

{ # this bracket is needed!
  # shape already selected
  
  # sex
  if (sexc != "both") {
    df0 <- subset(df0, sex == sexc)} 
  
  # location
  if (loca == "distboth") {
    df0 <- subset(df0, loca == "distboth" | loca == "none")} 
  else if (loca == "proximal") {
    df0 <- subset(df0, loca == "proximal" | loca == "none")}
  
  if (dims == "2d") {
    df0$ys <- df0$ys2d
    df0$ylo <- df0$ylo2d
    df0$yhi <- df0$yhi2d} 
  else if (dims == "3d") {
    df0$ys <- df0$ys3d
    df0$ylo <- df0$ylo3d
    df0$yhi <- df0$yhi3d}
}
df0$yhi[df0$sizecat == ">2"] <- -1
#df0$acen <- (df0$age-65)/10

{
  if (dims == "2d"){
    if (shp != "peduncular"){
      Size1cm <- 1/sqrt(800)
    }
    else {
      Size1cm <- 1/sqrt(200)
    }
    gdim <- 2
    Ninf <- max(df0$yhi2d)
  }
  else if (dims == "3d"){
    if (shp != "peduncular"){
      Size1cm <- 1/3200^(1/3) # 1 cm
    }
    else {
      Size1cm <- 1/400^(1/3)
    }
    gdim <- 3
    Ninf <- max(df0$yhi3d)
  }
}

# set detection limit boundaries for preferred models
{
  if (mdv == "pref"){
    if (shp == "sessile") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "flat") {
      df0$ylo[df0$ylo == 50] <- 30
      df0$ymin[df0$ymin == 50] <- 30}
    else if (shp == "peduncular") {
      df0$ylo[df0$ylo == 50] <- 40
      df0$ymin[df0$ymin == 50] <- 40}  
  }
}

#summary(df0)
dim(df0)[1]
{
  if (noad == "wN0"){
    df <- df0}
  else if (noad == "noN0"){
    df <- subset(df0, shape != "none")}
}
df0 <- droplevels(df0)

ad <- subset(df0, shape != "none")

# diagnostics
cat(sprintf("   Scenario: %s\n", fname))
cat(sprintf("      Cells: %d\n", dim(df0)[1]))
cat(sprintf("   All Npat: %d\n", sum(df0$npat)))
cat(sprintf(" Adeno Npat: %d\n", sum(ad$npat)))
cat(sprintf("  Free Npat: %d\n", sum(df0$npat)-sum(ad$npat)))
cat(sprintf("     MeanAd: %f\n", sum(ad$pno*ad$npat)/sum(ad$npat)))
cat(sprintf("     MeanSz: %f\n", sum(ad$size*ad$npat)/sum(ad$npat)))

load(file = "canagnu-20220214.Rdata")
df.canag
#setwd(resdir)
#write.csv(df.canag,file = "cancer-nu.csv")


#-----------------------------------------------------------------------
# read model results
#-----------------------------------------------------------------------

# set pardir
{
  if (mdv == "grid" & atr =="atrend"){thispardir <- gatrendpardir}
  else if (mdv == "pref"){thispardir <- atrendpardir}
  else if (mdv == "grid" & atr == "std"){thispardir <- gstdpardir}
}
thispardir <- paste(thispardir,shp,sep ="/")
thispardir <- paste(thispardir,dims,sep ="/")
mod <- substring(mmname, 1, 2) # first two characters of mmname
thispardir <- paste(thispardir,mod,sep ="/")
setwd(thispardir)

#setwd(pardir)

fparlist <- vector()
fprotlist <- vector()
fvcovlist <- vector()
fbasename <- fname
namvec <- strsplit(fbasename, split ="-")
f1 <- paste(fbasename,"_parms.csv",sep="")
f2 <- paste(fbasename,"_vcov.csv",sep="")
f3 <- paste(fbasename,"_protocol.txt",sep="")

ifelse (file.exists(f1), dpar <- read.csv(f1), cat(sprintf(" '%s' not found\n", f1)))
ifelse (file.exists(f2), dcov <- read.csv(f2), cat(sprintf(" '%s' not found\n", f2)))
dpar
dcov

#----------------------------------------------------------
# select evaluation functions
#----------------------------------------------------------

setwd(subdir)
{
  if (atr == "atrend"){
    source("pAdenoK0K1K2atrend-distrib-size.R")
  }
  else if (atr == "std"){
    source("pAdenoK0K1K2std-distrib-size.R")
  }
}

#-----------------------------------------------------------
# crude data: short oe analysis
#-----------------------------------------------------------

{ # this bracket is needed!
  if (mmname == "K0")
  {
      ENad <- ENadK0
      Thelohi <- theta_lohi_K0_ler
      Esize <- ymeanK0
      Prev <- PrevK0
      pn_K <- pn_K0_ler
      }
  else if (mmname == "K1app")
  {
    ENad <- ENadK1.app
    Thelohi <- theta_lohi_K1.app
    Esize <- ymeanK1
    Prev <- PrevK1.app
    pn_K <- pn_K1.app
  }
  else if (mmname == "K1")
  {
    ENad <- ENadK1.sum
    Thelohi <- theta_lohi_K1.sum
    #Theloho <- pnlohi_K1.sum
    Esize <- EsizeK1.hyp
    Prev <- PrevK1
    pn_K <- pn_K1.hyp
  }
  else if (mmname == "K2")
  {
    ENad <- ENadK2.sum
    Thelohi <- theta_lohi_K2.sum
    Esize <- EsizeK2.sum
    Prev <- PrevK2
    pn_K <- pn_K2.sum
  }
  else
  {
    print("Not implemented\n")
  }
}

#-----------------------------------------------------------------
# age cells: poisson data frame
#-----------------------------------------------------------------
upar <- dpar$parval

#------------------------------
#calculate nuag
#------------------------------
fname
cf <- subset (df.canag, Sex == sexc & Shape == shp & agecat != "total")
cf.total <- subset (df.canag, Sex == sexc & Shape == shp & agecat == "total")

ages <- cf$mage
ninf <- Ninf # needed for denominator
nlimit <- 10*ninf

ndim <- length(ages)
eSize_0 <- vector()
eN_0 <- vector()
for(i in 1:ndim){
  eSize_0[i] <- Esize(ages[i],upar,1,0,nlimit) 
  eN_0[i] <- ENad(ages[i],upar,0)
}
nu <- vector()
nu <- cf$chaz/eSize_0/eN_0
plot(ages,nu)

acen <- (ages-65)/10
m.nu <- glm(nu[1:6] ~ acen[1:6], family = gaussian(link = "log"))
summary(m.nu)
nu.fit <- predict(m.nu, type = "response")
plot(ages[1:6],nu.fit)
coef(m.nu)
nu65 <- exp(coef(m.nu)[1])
cacen <- coef(m.nu)[2]

#levels(cf$shape)[levels(cf$shape)=="flat"] <- "flat,2d"
#cf$Shape[cf$Shape == "flat"] <- "flat,2d"
eCell_0 <- eSize_0*eN_0
cf.ag <- data.frame(cf,eCell_0,nu,nu65,cacen)

eCell_0 <- Esize(cf.total$mage,upar,1,0,nlimit)*ENad(cf.total$mage,upar,0)
nu <- cf.total$chaz/eCell_0
nu65 <- cf.total$chaz.lo/eCell_0
cacen <- cf.total$chaz.hi/eCell_0
#cf.total$Shape[cf.total$Shape == "flat"] <- "flat,2d"
cf.total.nu <- data.frame(cf.total,eCell_0,nu,nu65,cacen)

cf.p.m <- rbind(cf.ag,cf.total.nu)

setwd(datdir)
ffname <- "nu65fit"
ffname <- paste(ffname,fname,sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(datdir)
save(cf.p.m, file = fsavname)

load(file = "nu65fit-peduncular-all-w-2d-K1-dist-atrend.Rdata")
load(file = "nu65fit-peduncular-all-m-2d-K1-dist-atrend.Rdata")
load(file = "nu65fit-sessile-all-w-2d-K2-dist-atrend.Rdata")
load(file = "nu65fit-sessile-all-m-2d-K2-dist-atrend.Rdata")
load(file = "nu65fit-flat-all-w-2d-K2-dist-atrend.Rdata")
load(file = "nu65fit-flat-all-m-2d-K2-dist-atrend.Rdata")
load(file = "nu65fit-flat-all-w-3d-K2-dist-atrend.Rdata")
load(file = "nu65fit-flat-all-m-3d-K2-dist-atrend.Rdata")

cf.f2d.w$Sex <- "w"
cf.f.w$Sex <- "w"
cf.f2d.m$Sex <- "m"
cf.f.m$Sex <- "m"
cf <- rbind(cf.s.w,cf.s.m,cf.p.w,cf.p.m,cf.f.w,cf.f.m,cf.f2d.w,cf.f2d.m)

ffname <- "nu65fit"
ffname <- paste(ffname,"canag",sep = "-")
fsavname <- paste(ffname,"Rdata", sep = ".")
fsavname
setwd(datdir)
save(cf, file = fsavname)


