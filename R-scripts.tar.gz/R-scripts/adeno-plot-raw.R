#----------------------------------------------
# adeno: add outpatients with N=0
# and streamline data set
# based on adenoma prevalence
# jck, 2021/09/16
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects 

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma" # project root directory
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))
statdir 
datdir 
setwd(datdir)
load(file = "adenoPG-20211103-raw.Rdata")

#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

pf <- adenoPG
levels(pf$sex)[levels(pf$sex)=="w"] <- "women"
levels(pf$sex)[levels(pf$sex)=="m"] <- "men"
#levels(pf$shape)[levels(pf$shape)=="none"] <- "adn. free"
summary(pf)

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
#myPalette <- c(cbbPalette[2],cbbPalette[6])
myPalette <- c(cbPalette[2],cbPalette[4],cbPalette[7],cbPalette[1])

#https://www.datanovia.com/en/blog/ggplot-log-scale-transformation/
#  scale_y_log10(name="No. of patients", breaks = trans_breaks("log10", function(x) 10^x),
#                labels = trans_format("log10", math_format(10^.x))) +

library(ggplot2)
library(scales)
library(forcats)
library(cowplot)
setwd(plotdir)

legend_title <- "Shape"
legend_labels <- levels(pf$shape)
legend_labels[4] <- "adn. free"
fp.1 <- ggplot() + 
  #ggtitle("Age & sex specific patient numbers, 2021/11/04") + 
  geom_bar(data = pf, aes(x=agecat, y=npat+1, fill=shape), stat="identity", position="dodge", width = 0.8) +
  #geom_bar(data = surv, aes(x=agecat, y=npat,fill=shape), stat="identity",position="dodge", width = 0.8) +
  #geom_text(aes(label = sprintf("%d", round(share*100, digits = 0))), position=position_dodge(width = 0.8), vjust=-0.2) +
  scale_fill_manual(legend_title,labels = legend_labels, values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(sex ~ .) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  #scale_y_continuous(name="No. of patients", trans = 'log10') +
  #scale_y_continuous(name="No. of patients", limits=c(1,10^4), breaks = c(1,10,100,1000,10000), trans = 'log10') +
  scale_y_log10(name="No. of patients", breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x))) +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12),
        axis.title.x=element_blank())
        #legend.position = "top",
        #legend.direction = "horizontal") 
#  + theme_bw()  # use a white background
print(fp.1)

#-----------------------------------------
# reproduce imposed prevalence and plot
#-----------------------------------------

pf.prev <- aggregate(pf$npat,list(pf$sex,pf$shape,pf$agecat),sum)
names(pf.prev) <- c("Sex","Shape","agecat","npat")
help1 <- split(pf.prev,pf.prev$Sex)
pf.w <- help1[[1]]
pf.m <- help1[[2]]
sum(pf.w$npat)
sum(pf.m$npat)

pf.ac.m <- aggregate(pf.m$npat,list(pf.m$agecat),sum)
pf.ac.w <- aggregate(pf.w$npat,list(pf.w$agecat),sum)

help2.m <- split(pf.m,pf.m$agecat)
help2.w <- split(pf.w,pf.w$agecat)

for(i in 1:7){
  help2.m[[i]]$nagrp <- pf.ac.m$x[i] 
  help2.w[[i]]$nagrp <- pf.ac.w$x[i] 
}

pf.p.m <- help2.m[[1]]
pf.p.w <- help2.w[[1]]
for(i in 2:7){
  pf.p.m <- rbind(pf.p.m,help2.m[[i]])
  pf.p.w <- rbind(pf.p.w,help2.w[[i]])
}
pf.p <- rbind(pf.p.m,pf.p.w)
pf.p$ppat <- pf.p$npat/pf.p$nagrp
pf.p$ppat[pf.p$Shape == "none"] <- 1 - pf.p$ppat[pf.p$Shape == "none"]
legend_labels[4] <- "all shapes" 
pf.p

fp.2 <- ggplot() + 
  #ggtitle("Age & sex specific prevalence, 2021/11/04") + 
  geom_bar(data = pf.p, aes(x=agecat, y = ppat*100, fill=Shape), stat="identity", position="dodge", width = 0.8) +
  scale_fill_manual(labels = legend_labels, values = myPalette) +
  #xlab("Age group (yr)") +
  facet_grid(Sex ~ .) + 
  scale_x_discrete(name="Age group (yr)", limits = levels(pf$agecat), breaks = levels(pf$agecat)) +
  #scale_y_continuous(name="Adenoma detection rate", labels = scales::percent_format(accuracy = 2L), limits=c(0,.4), breaks = seq(0,0.4,0.1)) +
  scale_y_continuous(name="Adenoma detection rate (%)", limits=c(0,40), breaks = seq(0,40,10)) +
  #scale_y_continuous(name="No. of patients", limits=c(1,3200), breaks = c(1,10,100,1000), trans = 'log10') +
  #scale_y_continuous(name="Rel. frequency", labels = scales::percent, limits=c(0,1.2), breaks = seq(0,1,0.5)) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12),
          #legend.position = c(.45,0.95),
          #legend.position = "top",
          #legend.direction = "horizontal"
          #legend.key.size = unit(1,"line"), 
          #legend.text=element_text(size=rel(0.9)
                                   )
#  + theme_bw()  # use a white background
print(fp.2)

#------------------------------------------------------------
# cowplot
#-----------------------------------------------------------
#plot_grid(fp.1, fp.2, labels = c('A', 'B'), label_size = 12)
plot_grid(fp.1, fp.2, labels = "AUTO", ncol = 1)


