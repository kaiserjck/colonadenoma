#----------------------------------------------
# test K2.app functions
# jck, 2021/09/01
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
# libraries
#library(gsl) # for hypergeometric function 2F1
library(hypergeo) # for hypergeometric function 2F1
#library(BMS) # for hypergeometric function 2F1
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(pardir)
#parDF <- read.csv ("temp/flat-noN0-all-m-3d-K1-std_parms.csv")

one_minus_azeta <- function (s1,alp,gam,age)
{
  dage <- age - s1
  
  bet <- alp-gam
  
  zaehler <- exp(gam*dage) - 1
  nenner <- alp*exp(gam*dage) - bet
  zet <- zaehler/nenner
  
  return (1-alp*zet)
}

# functions for exact K2
# integrated sum of p_n(s,t)
# interchange of summation and integration
sum_pn <- function(s1,age,alp,gam,rho,y0)
{
  nind <- seq(0,y0,1)
  agei <- vector()
  agei <- s1
  ndim <- length(agei)
  sumbi <- vector()
  sumbi <- unlist(lapply(1:ndim, function(i) sum(agei[i]*dnbinom(nind,rho,one_minus_azeta(agei[i],alp,gam,age)))))
  return (sumbi)
}

intsum_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  P_y0 <- integrate(sum_pn, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  
  return (t^2/2 - P_y0) # integrated p_1^(1)(s1,t)
}

# same as sum_pn
integ_one_minus_sum_pj_age_2F1 <- function(s1,age,alp,gam,rho,ymin)
{
  p_ymin <- dnbinom(ymin+1,rho,one_minus_azeta(s1,alp,gam,age))
  
  azeta <- 1 - one_minus_azeta(s1,alp,gam,age)
  hgf <- Re(hypergeo(1, 1+rho+ymin, 2+ymin, azeta, tol = 1e-6)) # real part of complex number
  
  return(s1*p_ymin*hgf) # same as 1-sum_pj: to be tested
}

# same as intsum_pn_K1
int2F1_pn_K2 <- function(t,alp,gam,rho,ymin)
{
  pn_K2 <- integrate(integ_one_minus_sum_pj_age_2F1, lower = 0, upper = t, age = t, alp, gam, rho, ymin)$value
  return (pn_K2) # integrated 1 - p_1^(1)(s1,t)
}

personal_deviance_sum <- function(X0,alp,gam,rho,df)
{
  ages <- df$ages
  y0 <- df$y0
  yl <- df$yl
  yh <- df$yh
  pno <- df$pno
  npat <- df$npat
  
  lnP0 <- -X0*intsum_pn_K2(ages,alp,gam,rho,y0)
  
  p_pat <- intsum_pn_K2(ages,alp,gam,rho,yl)
  p_pat_ot <- intsum_pn_K2(ages,alp,gam,rho,y0)
  if (yh > -1)
  {
    p_pat <- p_pat-intsum_pn_K2(ages,alp,gam,rho,yh)
    p_pat_ot <- p_pat_ot-intsum_pn_K2(ages,alp,gam,rho,yh)
  }
  p_pat <- X0*p_pat
  p_pat_ot <- X0*p_pat_ot
  
  sino <- 0
  if (pno > 0) {sino <- (pno-1)*log(p_pat_ot) + log(p_pat)} # pno = 0,1,2,5; 0 for "none" not used
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0)
  return(-2*lnlik)
  
}

personal_deviance_hgf <- function(X0,alp,gam,rho,df)
{
  ages <- df$ages
  y0 <- df$y0
  yl <- df$yl
  yh <- df$yh
  pno <- df$pno
  npat <- df$npat
  
  lnP0 <- -X0*int2F1_pn_K2(ages,alp,gam,rho,y0)
  
  p_pat <- int2F1_pn_K2(ages,alp,gam,rho,yl)
  p_pat_ot <- int2F1_pn_K2(ages,alp,gam,rho,y0)
  if (yh > -1)
  {
    p_pat <- p_pat-int2F1_pn_K2(ages,alp,gam,rho,yh)
    p_pat_ot <- p_pat_ot-int2F1_pn_K2(ages,alp,gam,rho,yh)
  }
  p_pat <- X0*p_pat
  p_pat_ot <- X0*p_pat_ot
  
  sino <- 0
  if (pno > 0) {sino <- (pno-1)*log(p_pat_ot) + log(p_pat)} # pno = 0,1,2,5; 0 for "none" not used
  
  # exact calculation may produce NaN for small p_pat_po
  #n2_4 <- c(2:4)
  #n0_4 <- c(0:4)
  #{
  #  if(pno == 1){
  #    sino <- log(p_pat)
  #  }
  #  else if (pno == 2){
  #    sino <- log(p_pat/p_pat_ot*sum(p_pat_ot^n2_4/factorial(n2_4)))
  #  }
  #  else if (pno == 5){
  #    print(p_pat_ot)
  #    print(exp(p_pat_ot))
  #    print(sum(p_pat_ot^n0_4/factorial(n0_4)))
  #    sino <- log(p_pat/p_pat_ot) + log(exp(p_pat_ot) - sum(p_pat_ot^n0_4/factorial(n0_4)))
  #    #sino <- log(p_pat/p_pat_ot*(exp(p_pat_ot) - sum(p_pat_ot^n0_4/factorial(n0_4))))
  #  }
  #}
  
  cat(sprintf(" DevENad: %g\n", -2*sum(npat*lnP0)))
  cat(sprintf(" DevSiNo: %g\n", -2*sum(npat*sino)))
  
  # full likelihood
  lnlik <- sum(npat*sino) + sum(npat*lnP0)
  return(-2*lnlik)  
}


#-----------------------------------
# parameters
#-----------------------------------
upar <- vector()
upar[1] <- 0.002
upar[2] <- 100
upar[3] <- 0.01
upar[4] <- 1e-4

X0 <- upar[1]
alp <- upar[2]
gam <- upar[3]
rho = upar[4]

#-----------------------------------------
# patient data
#-----------------------------------------
s1 <- 0
ages <- 61
y0 <- 50
yl <- 25600
yh <- -1
pno <- 5
npat <- 2
nvec <- seq(0,y0,1)

df <- data.frame(ages,y0,yl,yh,pno,npat)
df

#-----------------------------------------
# check of K2 functions
#-----------------------------------------

oma <- one_minus_azeta(s1,alp,gam,ages)
azeta <- 1 - oma
hgf <- Re(hypergeo(1, 1+rho+y0, 2+y0, azeta, tol = 1e-6)) # real part of complex number
pfunc <- s1*dnbinom(y0+1,rho,oma)*hgf
psum <- 1-sum_pn(s1,ages,alp,gam,rho,y0)
pfunc
psum
(pfunc - psum)/psum

pisum <- intsum_pn_K2(ages,alp,gam,rho,y0)
pifunc <- int2F1_pn_K2(ages,alp,gam,rho,y0)
pifunc
pisum
(pifunc - pisum)/pisum

pd_sum <- personal_deviance_sum(X0,alp,gam,rho,df)
pd_hgf <- personal_deviance_hgf(X0,alp,gam,rho,df)
pd_sum
pd_hgf
(pd_sum - pd_hgf)/pd_hgf
  
  



