#----------------------------------------------
# test Lerch function
# jck, 2021/06/09
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
library('VGAM') # Lerch function

#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(pardir)
setwd(spardir)
parDF <- read.csv ("prefmod/flat-all-all-m-K0-std_3d-cf_parms.csv")

upar <- vector()
upar <- as.numeric(parDF$parval)


# Cristoforo Simonetto
# corrected 2021/06/09
pn_K0_ler <- function (t,alp,gam,n) # n -> ymin
{
  ax <- alp*(exp(gam*t)-1)/(alp*exp(gam*t)-(alp-gam))
  return(ax^(1+n)*lerch(ax,1,1+n)/alp)
}

# K = 0 exact
# corrected 2021/06/09
ainteg_Gg_K0 <- function (s1, age, alpha, gamma, n)
{
  
  dage <- s1-age
  gfunc <- exp(gamma*dage)
  Gfunc <- alpha/gamma*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)
  return (f2*(f1^n))
}

pn_K0_int <- function (t,alp,gam,y0)
{
  ndim <- length(t)
  pnK1 <- vector()
  pnK1 <- unlist(lapply(1:ndim, 
                        function(i) 
                          integrate(ainteg_Gg_K0, lower = 0, upper = t[i], age = t[i], alp, gam, n = y0[i])$value))
  return (pnK1)
}

# K=0
sintegrand_Gg_K0 <- function (s1, age, alpha, gamma, n)
{
  
  dage <- s1-age
  gfunc <- exp(gamma*dage)
  Gfunc <- alpha/gamma*(1-gfunc)
  f1 <- 1/(1+gfunc/Gfunc)
  f2 <- 1/(Gfunc+gfunc)
  return(f2*(f1^n))
}

sintegrated_Gg_K0 <- function (t,alpha,gamma,y0)
{
  retarg <- integrate(sintegrand_Gg_K0, lower = 0, upper = t, age = t, alpha, gamma, n = y0)$value
  return (retarg)
}

fzeta <- function (s1, age, alpha, gamma)
{
  dage <- age-s1
  
  beta <- alpha-gamma
  
  zaehler <- exp(gamma*dage) - 1
  nenner <- alpha*exp(gamma*dage) - beta
  retarg <- zaehler/nenner
  
  return (retarg)
}

alp <- upar[2]
gam <- upar[3]
ages <- 65
y0 <- 50

sintegrated_Gg_K0(ages,alp,gam,y0)

azeta <- alp*fzeta(0,ages,alp,gam)
azeta
azeta^(1+y0)/alp*lerch(azeta,1,1+y0)

pn_K0_ler(ages,alp,gam,y0)
pn_K0_int(ages,alp,gam,y0)



