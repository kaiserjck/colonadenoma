#----------------------------------------------
# plot adeno psize analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="esize-agecat-flat-w-3d-K2-posize-atrend.Rdata")
f.3d.w <- scf

load(file="esize-agecat-flat-m-3d-K2-posize-std.Rdata")
f.3d.m <- scf

load(file="esize-agecat-sessile-w-2d-K2-posize-atrend.Rdata")
s.2d.w <- scf

load(file="esize-agecat-sessile-m-2d-K2-posize-atrend.Rdata")
s.2d.m <- scf

load(file="esize-agecat-peduncular-w-2d-K2-posize-atrend.Rdata")
p.2d.w <- scf

load(file="esize-agecat-peduncular-m-2d-K2-posize-std.Rdata")
p.2d.m <- scf

# model predictions with exact formula
load(file = "sizecm-age20_90-flat-w-3d-K2-posize-atrend-1000Ninf.Rdata")
f.w <- ecf

load(file = "sizecm-age20_90-flat-m-3d-K2-posize-std-1000Ninf.Rdata")
f.m <- ecf

load(file = "sizecm-age20_90-sessile-w-2d-K2-posize-atrend.Rdata")
s.w <- ecf

load(file = "sizecm-age20_90-sessile-m-2d-K2-posize-atrend.Rdata")
s.m <- ecf

load(file = "sizecm-age20_90-peduncular-w-2d-K2-posize-atrend.Rdata")
p.w <- ecf

load(file = "sizecm-age20_90-peduncular-m-2d-K2-posize-std.Rdata")
p.m <- ecf

# build and adjust pf
pf <- rbind(f.3d.w,f.3d.m,s.2d.w,s.2d.m,p.2d.w,p.2d.m)
pf$Sex[pf$Sex == "w"] <- "women"
pf$Sex[pf$Sex == "m"] <- "men"
pf$Source <- fct_rev(pf$Source)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("peduncular","flat","sessile"))
summary(pf)
str(pf)
setwd(plotdir)

pd <- position_dodge(width = 0.4)
fp.1 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_point(data = pf, aes(x=agecat, y=sizecm, color = Shape, shape = Source, group = Shape), size = 4, position = pd) +
  #geom_errorbar(data = pf, aes(x = agecat, ymax =sizecm.hi, ymin = sizecm.lo, color = Shape), width=.1, position = pd) +
  geom_linerange(data = pf, aes(x = agecat, y=sizecm, ymax =sizecm.hi, ymin = sizecm.lo, group = Shape), size = .75, position = pd) +
  #geom_pointrange(data = pf.unc, aes(x = agecat, y=sizecm, ymax =sizecm.hi, ymin = sizecm.lo), size = 0.1) +
  xlab("Age group (yr)") +
  #facet_wrap(Shape ~ Sex, scales = "free_y", ncol = 3) + 
  facet_grid(Sex ~ .) + 
  #scale_x_discrete(limits = levels(pf$Size), breaks = levels(pf$Size)) +
  scale_y_continuous(name="Mean adenoma size (cm)", limits = c(0.5,1.8), breaks = seq(0.6,1.6,0.2)) +
  scale_color_manual(values=cbPalette[c(7,2,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  #guides(shape="none",color="none") + 
  #theme(text = element_text(size=15),legend.position = c(.65,0.49))
  theme(text = element_text(size=15)) 
#  + theme_bw()  # use a white background
print(fp.1)

#-------------------------------------
# plot with age extrapolation marked
#--------------------------------------
pf <- subset(pf,Source != "MS")
pf <- droplevels(pf)

pf.2 <- rbind(f.w,f.m,s.w,s.m,p.w,p.m)
summary(pf.2)
str(pf.2)
pf.early <- subset(pf.2, age < 55)
pf.early <- data.frame(pf.early,"early")
nlast <- dim(pf.early)[2] 
names(pf.early)[nlast] <- "Period"
pf.late <- subset(pf.2, age > 54)
pf.late <- data.frame(pf.late,"late")
names(pf.late)[nlast] <- "Period"

pf.2 <- rbind(pf.early,pf.late)
pf.2$Sex <- fct_rev(pf.2$Sex)
pf.2$Shape <- fct_relevel(pf.2$Shape,c("peduncular","flat","sessile"))
summary(pf.2)

fp.2 <- ggplot() + 
  #ggtitle("flat, pref") +
  geom_point(data = pf, aes(x=age, y=sizecm, color = Shape, shape = Source, group = Shape), size = 4) +
  #geom_errorbar(data = pf, aes(x = age, ymax =sizecm.hi, ymin = sizecm.lo, color = Shape), width=.1, position = pd) +
  geom_linerange(data = pf, aes(x = age, y=sizecm, ymax =sizecm.hi, ymin = sizecm.lo, group = Shape), size = .75) +
  geom_line(data = pf.2, aes(x=age, y=sizecm, color = Shape, linetype = Period), size = 1) +
  #facet_wrap(Shape ~ Sex, scales = "free_y", ncol = 3) + 
  facet_grid(Sex ~ .) + 
  scale_x_continuous(name = "Age (yr)", limits = c(35,90), breaks = seq(40,90,10)) +
  scale_y_continuous(name="Mean adenoma size (cm)", limits = c(0.4,1.7), breaks = seq(0.4,1.6,0.2)) +
  scale_color_manual(values=cbPalette[c(7,2,4)]) +
  #scale_color_manual(values=cbPalette[c(2,3,7,4)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape="none", linetype = "none") + 
  theme(text = element_text(size=15),legend.position = c(.15,0.42)) 
#  + theme_bw()  # use a white background
print(fp.2)


