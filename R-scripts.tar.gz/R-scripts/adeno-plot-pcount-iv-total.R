#----------------------------------------------
# plot adeno pcount analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)
load(file="pcount-iiv-agroup-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.w <- pif

load(file="pcount-iiv-agroup-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.m <- pif

load(file="pcount-iiv-agroup-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
p.w <- pif

load(file="pcount-iiv-agroup-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
p.m <- pif

load(file="pcount-iiv-agroup-flat-all-w-3d-K2-dist-atrend.Rdata")
f.w <- pif

load(file="pcount-iiv-agroup-flat-all-m-3d-K2-dist-atrend.Rdata")
f.m <- pif

# build and adjust pf
pf <- rbind(s.w,s.m,p.w,p.m,f.w,f.m)
pf$Source <- fct_rev(pf$Source)
pf <- subset(pf, Source != "Miv")
pf <- droplevels(pf)

pf.w <- subset(pf, Source == "S" & Shape == "sessile" & Sex == "women")
pf.Npat.w <- aggregate(pf.w$Npat,list(pf.w$AgeGroup),sum)
pf.w <- subset(pf, Sex == "women")
help1 <- split(pf.w, pf.w$AgeGroup)
nlevels <- length(levels(pf.w$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- pf.Npat.w$x[i] 
}
tf.w <- help1[[1]]
for (i in 2:nlevels){
  tf.w <- rbind(tf.w,help1[[i]])
}

pf.m <- subset(pf, Source == "S" & Shape == "sessile" & Sex == "men")
pf.Npat.m <- aggregate(pf.m$Npat,list(pf.m$AgeGroup),sum)
pf.m <- subset(pf, Sex == "men")
help1 <- split(pf.m, pf.m$AgeGroup)
nlevels <- length(levels(pf.m$AgeGroup))
for(i in 1:nlevels){
  help1[[i]]$Npat_agrp <- pf.Npat.m$x[i] 
}
tf.m <- help1[[1]]
for (i in 2:nlevels){
  tf.m <- rbind(tf.m,help1[[i]])
}

tf <- rbind(tf.w,tf.m)
str(tf)
head(tf)
summary(tf)

ttf <- subset(tf, Shape == "sessile")
ttf <- droplevels(ttf)
#levels(ttf$Shape)[levels(ttf$Shape)=="sessile"] <- "total"
ttf$Shape <- "total"
str(ttf)
ttf$Npat <- tf$Npat[tf$Shape == "sessile"] + tf$Npat[tf$Shape == "flat"] + tf$Npat[tf$Shape == "peduncular"]
ttf$Npat[ttf$Count == "0"] <- ttf$Npat_agrp[ttf$Count == "0"] - ttf$Npat[ttf$Count == "1"] - ttf$Npat[ttf$Count == "2-4"] - ttf$Npat[ttf$Count == ">=5"]
ttf$pNcat <- tf$pNcat[tf$Shape == "sessile"] + tf$pNcat[tf$Shape == "flat"] + tf$pNcat[tf$Shape == "peduncular"]
ttf$pNcat[ttf$Count == "0"] <- 1 - ttf$pNcat[ttf$Count == "1"] - ttf$pNcat[ttf$Count == "2-4"] - ttf$pNcat[ttf$Count == ">=5"]
ttf$pNcat.lo <- tf$pNcat.lo[tf$Shape == "sessile"] + tf$pNcat.lo[tf$Shape == "flat"] + tf$pNcat.lo[tf$Shape == "peduncular"]
ttf$pNcat.lo[ttf$Count == "0"] <- 1 - ttf$pNcat.lo[ttf$Count == "1"] - ttf$pNcat.lo[ttf$Count == "2-4"] - ttf$pNcat.lo[ttf$Count == ">=5"]
ttf$pNcat.hi <- tf$pNcat.hi[tf$Shape == "sessile"] + tf$pNcat.hi[tf$Shape == "flat"] + tf$pNcat.hi[tf$Shape == "peduncular"]
ttf$pNcat.hi[ttf$Count == "0"] <- 1 - ttf$pNcat.hi[ttf$Count == "1"] - ttf$pNcat.hi[ttf$Count == "2-4"] - ttf$pNcat.hi[ttf$Count == ">=5"]
ttf$enad <- tf$enad[tf$Shape == "sessile"] + tf$enad[tf$Shape == "flat"] + tf$enad[tf$Shape == "peduncular"]
ttf$enad.lo <- tf$enad.lo[tf$Shape == "sessile"] + tf$enad.lo[tf$Shape == "flat"] + tf$enad.lo[tf$Shape == "peduncular"]
ttf$enad.hi <- tf$enad.hi[tf$Shape == "sessile"] + tf$enad.hi[tf$Shape == "flat"] + tf$enad.hi[tf$Shape == "peduncular"]

#--------------------------------------------------------------------------------------
# calculate share according to Poisson distribution, Poisson distribution is additive
#--------------------------------------------------------------------------------------
mdf <- subset(ttf, Source == "M") # model
mdf$pNcat[mdf$Count == "0"] <- dpois(0,mdf$enad[mdf$Count == "0"])
mdf$pNcat[mdf$Count == "1"] <- dpois(1,mdf$enad[mdf$Count == "1"])
mdf$pNcat[mdf$Count == "2-4"] <- dpois(2,mdf$enad[mdf$Count == "2-4"]) + dpois(3,mdf$enad[mdf$Count == "2-4"]) + dpois(4,mdf$enad[mdf$Count == "2-4"])
mdf$pNcat[mdf$Count == ">=5"] <- 1-(mdf$pNcat[mdf$Count == "0"] + mdf$pNcat[mdf$Count == "1"] + mdf$pNcat[mdf$Count == "2-4"])
mdf$pNcat[mdf$pNcat < 0] <- 1e-6

sdf <- subset(ttf, Source == "S") # screening

ttf <- rbind(sdf,mdf) # re-assemble

tf.plus <- rbind(tf,ttf)
tf.plus$Shape <- fct_relevel(tf.plus$Shape, c("total","sessile","peduncular","flat"))

#-----------------------------
# prepare plotting
#-----------------------------
head(ttf)
table(ttf$Shape)
pf <- ttf
summary(pf)
setwd(plotdir)

#pf.1 <- subset(pf, Sex == "men")
pf.1 <- pf

label_fill <- c("Screening","Model")
pf.1$Count <- fct_relevel(pf.1$Count,c("0","1","2-4",">=5"))
fp.1 <- ggplot(data = pf.1, aes(x=Count, y=pNcat*100, fill = Source)) + 
  ggtitle("all shapes") + 
  geom_bar(stat="identity", position="dodge", width = 0.8) +
  #geom_text(aes(x=Count, y=pNcat*100, label = sprintf("%d", round(pNcat*100, digits = 0))), position=position_dodge(width = 1), vjust=-0.2) +
  geom_text(aes(x=Count, y=pNcat*100, 
                             label = sprintf("%d", round(pNcat*100, digits = 0))), position=position_dodge(width = 0.9), vjust=-0.2) +
  geom_text(data = subset(pf.1,Source == "S"), aes(x = 3.6, y = 70, label = sprintf("Npat = %d", Npat_agrp))) +
  #geom_text(aes(x = 2.9, y = 0.7, label = sprintf("N = %d", Npat))) +
  #geom_errorbar(aes(ymin=share.lo, ymax=share.hi), width=.2, position=position_dodge(.8)) +
  scale_fill_manual(values = myPalette, labels = label_fill) +
  xlab("Adenoma count") +
  facet_grid(AgeGroup ~ Sex) + 
  #facet_grid(AgeGroup ~ .) + 
  #scale_x_discrete(limits = levels(pf$Size), breaks = levels(pf$Size)) +
  #scale_y_continuous(name="Share in age group (%)", labels = scales::percent, limits=c(0,1.1), breaks = seq(0,1,0.5)) +
  scale_y_continuous(name="Share in age group (%)", limits=c(0,115), breaks = seq(0,100,50)) +
  #scale_y_continuous(name="Share in age group (%)", trans = "log10") +
  #scale_color_manual(values=cbbPalette[3:5]) +
  #guides(fill=FALSE) + 
  theme(text = element_text(size=12), legend.position = "none", legend.title = element_blank()) 
#  + theme_bw()  # use a white background
print(fp.1)


legend_title <- "Source"
pf.2 <- subset(pf, Count == "0")
pf.2.s <- subset(pf.2, Source == "S")
fp.2 <- ggplot(data=pf.2, aes(y= 1-pNcat, x = AgeGroup, color=Source)) +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  #geom_bar(stat="identity", position = "fill", width = 0.8) + 
  geom_linerange(data = pf.2.s, aes(x = AgeGroup, y = 1-pNcat, ymin = 1-pNcat.lo, ymax = 1-pNcat.hi), color = cbPalette[1]) + 
  geom_point(size = 3) + 
  facet_grid (Sex ~ .) +
  scale_y_continuous(name="Prevalence") +
  scale_color_manual(values=cbPalette[c(1:3,8)]) +
  #scale_color_manual(legend_title, values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15), legend.position = c(0.2,0.9)) 
print(fp.2)
