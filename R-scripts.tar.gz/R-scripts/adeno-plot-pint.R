#----------------------------------------------
# plot extinction probability
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(statdir)
setwd("pext")

load(file="pint-a60-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.age60.w <- pif
load(file="pint-a60-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.age60.m <- pif

load(file="pint-a60-flat-all-w-3d-K2-dist-atrend.Rdata")
#pif$Shape <- "flat, 3d"
f.age60.3d.w <- pif
load(file="pint-a60-flat-all-m-3d-K2-dist-atrend.Rdata")
#pif$Shape <- "flat, 3d"
f.age60.3d.m <- pif
load(file="pint-a60-flat-all-w-2d-K2-dist-atrend.Rdata")
pif$Shape <- "flat, 2d"
f.age60.2d.w <- pif
load(file="pint-a60-flat-all-m-2d-K2-dist-atrend.Rdata")
pif$Shape <- "flat, 2d"
f.age60.2d.m <- pif

load(file="pint-a60-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
p.age60.w <- pif
load(file="pint-a60-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
p.age60.m <- pif

# build and adjust pf
# age group data
#pf <- rbind(s.age60.w,s.age60.m,f.age60.3d.w,f.age60.3d.m,f.age60.2d.w,f.age60.2d.m,p.age60.w,p.age60.m)
pf <- rbind(s.age60.w,s.age60.m,f.age60.3d.w,f.age60.3d.m,p.age60.w,p.age60.m)
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular","flat, 2d", "flat, 3d"))
pf <- droplevels(pf)
summary(pf)

setwd(plotdir)
fp.1 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = delt, y = pint*100, color = Shape), size = 1) + 
  facet_grid(out ~ Sex) +
  scale_x_continuous(name = "Waiting time (yr)", limits = c(0,20), breaks = seq(0,20,5)) +
  scale_y_continuous(name = "Probability (%)", limits = c(0,100), breaks = seq(0,100,25)) +
  scale_color_manual(values=cbPalette[c(4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  guides(shape=F, linetype = F) + 
  theme(text = element_text(size=15),legend.position = c(0.75,0.9)) 
print(fp.1)

fp.2 <- ggplot() + 
  #ggtitle(shp) +
  geom_line(data = pf, aes(x = delt, y = pint*100, color = Shape, linetype = out), size = 1) + 
  facet_grid(Shape ~ Sex) +
  scale_x_continuous(name = "Waiting time (yr)", limits = c(0,20), breaks = seq(0,20,5)) +
  scale_y_continuous(name = "Probability (%)", limits = c(0,100), breaks = seq(0,100,25)) +
  scale_color_manual(values=cbPalette[c(4,7,2)]) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  scale_linetype_manual(values = c("solid","longdash","dotdash","dotted")) +
  guides(shape=F,color=F) + 
  theme(text = element_text(size=15),legend.position = c(0.75,0.9)) 
print(fp.2)
