#----------------------------------------------
# plot adeno enad analysis
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)

#------------------------------------------------------------
# Hazard ratios from models
#------------------------------------------------------------
# rNeff = 0.5
load(file="HRind-flat-all-w-3d-K2-dist-atrend.Rdata")
f.w <- af

load(file="HRind-flat-all-m-3d-K2-dist-atrend.Rdata")
f.m <- af

load(file="HRind-flat-all-w-2d-K2-dist-atrend.Rdata")
f.w.2d<- af

load(file="HRind-flat-all-m-2d-K2-dist-atrend.Rdata")
f.m.2d <- af

load(file="HRind-sessile-all-w-2d-K2-dist-atrend.Rdata")
s.w <- af

load(file="HRind-sessile-all-m-2d-K2-dist-atrend.Rdata")
s.m <- af

load(file="HRind-peduncular-all-w-2d-K1-dist-atrend.Rdata")
p.w <- af

load(file="HRind-peduncular-all-m-2d-K1-dist-atrend.Rdata")
p.m <- af

#shp_flat <- f.w$Shape[1]

# build and adjust pf
#pf <- rbind(f.w,f.m,f.w.2d,f.m.2d,s.w,s.m,p.w,p.m)
pf <- rbind(f.w,f.m,s.w,s.m,p.w,p.m)
pf <- subset(pf, pf$age != 55)
#pf <- rbind(f.w,f.m,f.w.2d,f.m.2d)
levels(pf$Sex)[levels(pf$Sex)== "w"] <- "women"
levels(pf$Sex)[levels(pf$Sex)== "m"] <- "men"
pf$Sex <- fct_rev(pf$Sex)
pf$Shape <- fct_relevel(pf$Shape,c("peduncular","sessile","flat"))
#pf$Shape <- fct_relevel(pf$Shape,c("sessile", "peduncular","flat","flat,2d"))
pf <- droplevels(pf)
summary(pf)

#----------------------------------------------------------
# plotting
#----------------------------------------------------------
setwd(plotdir)
str(pf)

legend_title <- "Age at examination"
fp.1 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y = HRind, x = sizecm, linetype = as.character(age), color = Shape), size = 1.2) + 
  #geom_line(data = df.adj, aes(y= hr, x = ADR*100), size = 1.2) + 
  facet_grid (Sex ~ .) +
  scale_x_continuous(name = "Size (cm)", limits = c(0.25,1), breaks = seq(0.25,1,0.25)) +
  scale_y_continuous(name="Individual risk reduction ratio at age 75 yr", limits = c(2e-5,0.2), trans = "log10") +
  #scale_y_continuous(name="Hazard ratio at age 75 yr", limits = c(0,0.15), breaks = seq(0,0.15,0.05)) +
  scale_color_manual(values=cbPalette[c(7,4,2)]) +
  #scale_color_manual(values=cbPalette[c(7,4,2,3)]) +
  scale_linetype_manual(legend_title, values = c("dotdash", "solid"), labels = c("45 yr","65 yr")) +
  #geom_point(data = df.dor, aes(x = ADReff*100, y = HRdor), size = 4) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  #geom_linerange(data = df.dor, aes(x = ADReff*100, y = HRdor, ymin = HRlo, ymax = HRhi), size = 0.75) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  #guides(linetype = "none") + 
  #scale_color_manual(values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        #legend.position = c(0.15,0.55)
        legend.position = "top") 
print(fp.1)

#yd <- pf$HRpop*pf$E_0_2-pf$DeCell_0
#pf$HRpop2 <- pf$ymin/pf$E_0
fp.2 <- ggplot() +
  #ggtitle("Sessile adenoma (prox+dist)") + 
  geom_line(data = pf, aes(y = HRpop, x = sizecm, linetype = as.character(age), color = Shape), size = 1.2) +
  #geom_line(data = pf, aes(y = HRpop2, x = sizecm, linetype = as.character(age), color = Shape), size = 1.2) +
  #geom_line(data = df.adj, aes(y= hr, x = ADR*100), size = 1.2) + 
  facet_grid (Sex ~ .) +
  scale_x_continuous(name = "Size (cm)", limits = c(0.25,1), breaks = seq(0.25,1,0.25)) +
  #scale_y_continuous(name="Individual hazard ratio at age 75 yr", limits = c(2e-5,0.2), trans = "log10") +
  scale_y_continuous(name="Hazard ratio at age 75 yr", limits = c(0,30), breaks = seq(0,30,10)) +
  scale_color_manual(values=cbPalette[c(7,4,2)]) +
  #scale_color_manual(values=cbPalette[c(2,3,4,7)]) +
  scale_linetype_manual(legend_title, values = c("solid", "dotdash"), labels = c("45 yr","65 yr")) +
  #geom_point(data = df.dor, aes(x = ADReff*100, y = HRdor), size = 4) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  #geom_linerange(data = df.dor, aes(x = ADReff*100, y = HRdor, ymin = HRlo, ymax = HRhi), size = 0.75) +
  #scale_alpha_manual(values=c(0.2, 1)) +
  #scale_shape_manual(values = c(21, 16)) +
  #scale_linetype_manual(values = c("dashed", "solid")) +
  #guides(linetype = "none") + 
  #scale_color_manual(values=cbPalette[c(8,3,2,1)]) +
  theme(text = element_text(size=15),
        #axis.text.x=element_text(size=8),
        #legend.position = c(0.15,0.55)
        legend.position = "top") 
print(fp.2)

