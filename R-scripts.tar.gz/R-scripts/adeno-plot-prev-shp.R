#----------------------------------------------
# plot adeno prevalence
#----------------------------------------------
#--------------------------------------------------------------
rm( list=ls() )      # remove all the objects         
#--------------------------------------------------------------
#---------------------------------------------------
# plotting with gglot2
#---------------------------------------------------

# http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# The palette with grey:
cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# The palette with black:
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
myPalette <- c(cbPalette[1],cbbPalette[2],cbPalette[3],cbbPalette[6],cbPalette[5])
#myPalette <- c(cbbPalette[2],cbPalette[4],cbbPalette[7])

library(ggplot2)
library(scales)
library(forcats)
#-------------------------------------------
# directory structure
#-------------------------------------------
dir <- "~/imodel/colonlmu/adenoma"
source(paste(dir, "/stats/subscripts/subdir.R", sep = ""))

setwd(curvdir)

shp <- character()
#shp <- "sessile"
#shp <- "flat"
shp <- "peduncular"

{
  if (shp == "sessile"){
    load(file="prev-X0opt-agroup-sessile-all-w-2d-K2-dist-atrend.Rdata")
    pcf.w <- prf
    load(file="prev-X0opt-agroup-sessile-all-m-2d-K2-dist-atrend.Rdata")
    pcf.m <- prf
    load(file="prev-X0opt-age-sessile-all-w-2d-K2-dist-atrend.Rdata")
    ppf.w <- praf
    load(file="prev-X0opt-age-sessile-all-m-2d-K2-dist-atrend.Rdata")
    ppf.m <- praf
  }
  else if (shp == "flat"){
    load(file="prev-X0opt-agroup-flat-all-w-3d-K2-dist-atrend.Rdata")
    pcf.w <- prf
    load(file="prev-X0opt-agroup-flat-all-m-3d-K2-dist-atrend.Rdata")
    pcf.m <- prf
    load(file="prev-X0opt-age-flat-all-w-3d-K2-dist-atrend.Rdata")
    ppf.w <- praf
    load(file="prev-X0opt-age-flat-all-m-3d-K2-dist-atrend.Rdata")
    ppf.m <- praf   
  }
  else if (shp == "peduncular"){
    load(file="prev-X0opt-agroup-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
    pcf.w <- prf
    load(file="prev-X0opt-agroup-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
    pcf.m <- prf
    load(file="prev-X0opt-age-peduncular-all-w-2d-K1app-dist-atrend.Rdata")
    ppf.w <- praf
    load(file="prev-X0opt-age-peduncular-all-m-2d-K1app-dist-atrend.Rdata")
    ppf.m <- praf  
  }
}


# build and adjust pf
# age group data
pf.g <- rbind(pcf.w,pcf.m)
pf.g$Source <- fct_rev(pf.g$Source)
pf.g$Sex <- fct_rev(pf.g$Sex)
summary(pf.g)

# prev-age data
pf.a <- rbind(ppf.w,ppf.m)
pf.a$Sex <- fct_rev(pf.a$Sex)
summary(pf.a)


setwd(plotdir)
fp.1 <- ggplot() + 
  ggtitle(shp) +
  geom_point(data = pf.g, aes(x = age, y = pNcat, shape = Source), size = 3) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=enad.lo, ymax=enad.hi), width=0) +
  geom_line(data = pf.a, aes(x = age, y = pNcat, group = Source)) + 
  facet_grid(Sex ~ .) +
  scale_shape_manual(values = c(21, 16, 2)) +
  theme(text = element_text(size=12)) 
print(fp.1)

fp.2 <- ggplot() + 
  ggtitle(shp) +
  geom_point(data = pf.g, aes(x = age, y = 1-pNcat, shape = Source), size = 3) + 
  #geom_errorbar(data = pf.g, aes(x = age, ymin=pNcat.lo, ymax=pNcat.hi), width=0) +
  geom_line(data = pf.a, aes(x = ages, y = prev, group = Sex)) + 
  #geom_ribbon(data = pf.a, aes(x = ages, ymin = prev.lo, ymax = prev.hi, group = Sex), alpha = 0.1) + 
  facet_grid(Sex ~ .) +
  scale_shape_manual(values = c(21, 16)) +
  theme(text = element_text(size=12)) 
print(fp.2)

